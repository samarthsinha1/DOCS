package main

import "fmt"

func main(){
  element:=map[string]map[string]string{
    "H":map[string]string{
      "name":"Hydrogen",
      "state":"Gas",
    },
    "Ca":map[string]string{
      "name":"Calcium",
      "state":"Solid",
    },

  }
  fmt.Println("Enter element symbol:")
  var nm string;
  fmt.Scanln(&nm);
  if el,ok:=element[nm]
  ok{
  fmt.Printf("\n name is:%s",el["name"])
  fmt.Printf("\n State is:%s",el["state"])
}
}
