package MathPack

import "testing"

func TestAdd(t *testing.T){
  var v int
  v=Add(12,34)
  if v!=46{
    t.Error("Expected is 46,actual ",v)
  }
}
