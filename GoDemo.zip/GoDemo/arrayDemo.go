package main
import "fmt"
func main(){
  var arr[5] int;
  var arr1=[]float32{20.2,30.3,40.4,50.5,10.3,65.6}
  arr[0]=20
  arr[4]=80
  fmt.Printf("Array contents:%v",arr)
  fmt.Printf("\n float array contents:%v",arr1)
  var i int;
  for i=0;i<5;i++{
    fmt.Printf("\n %f",arr1[i])
  }
  for i,num:=range arr{
    fmt.Printf("\nindex value %d.......value=%d",i,num)
  }
  fmt.Printf("\n %d",len(arr1))
}
