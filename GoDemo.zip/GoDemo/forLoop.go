package main
import "fmt"

func main(){
var cnt,flag int
flag=1
for cnt=1;cnt<10;cnt++{
  fmt.Printf("%d",cnt)
  fmt.Printf("continue(1/0)")
  fmt.Scanf("%d"&flag)
  if flag==1
  continue
  else
  break

}
}
