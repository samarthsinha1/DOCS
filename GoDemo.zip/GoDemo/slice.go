package main

import "fmt"

func main(){
  var arr=[]int{1,2,3,4,5,6,7,8,9}
  slice1:=arr[1:4]
  slice2:=arr[3:8]

  fmt.Printf("slice 1 = %v ",slice1)
  fmt.Printf("\nslice 2 = %v",slice2)

  newSlice:=make([]float32,5,10)
  fmt.Printf("\nnewSlice:%v",newSlice)
  fmt.Printf("\nSize of newSlice:%d",len(newSlice))
  fmt.Printf("\nCapacity of newSlice:%d",cap(newSlice))

  sl1:=make([]int,3)
  copy(sl1,slice1)
  fmt.Printf("\nsl1:%v",sl1)
  sl2:=append(sl1,11,12)
  fmt.Printf("\nsl2:%v",sl2)
}
