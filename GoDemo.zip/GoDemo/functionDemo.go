package main
import "fmt"

func swapName(fname,lname string)(string,string){
  return lname,fname
}
/* variadic function*/
func addNums(args...int)int{
  var total int
  for _,val:=range args{
    total+=val
  }
  return total
}

func factorial(x int)int{
  if x==0{
    return 1
  }
  return x*factorial(x-1)
}

func f1(){
  fmt.Println("first function")
}

func f2(){
  fmt.Println("second Function")
}

func Divide(n1,n2 int)int{
  if n2==0{
    defer func(){
      errm:=recover()
      fmt.Println(errm)
    }()
      panic("divide by zero")
  }
return n1/n2
}
/*****************************************/
func main(){
  var first,last string;
  last,first=swapName("Peter","GoldSmith")
  fmt.Printf("Name:%s %s",last,first)

  fmt.Printf("\n Function with 3 args : %d",addNums(10,20,30))
  fmt.Printf("\n Function with 5 args : %d",addNums(10,20,30,40,50))
  enclose:=func(){
    fmt.Println("\nClosure Function in action")
  }
  defer f2();
  enclose();
  fmt.Printf("\n%d",factorial(5))

  f1();
  fmt.Println("When will this get executed?")
  fmt.Println(Divide(10,2))
}
