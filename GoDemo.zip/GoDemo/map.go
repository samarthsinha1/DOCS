package main

import "fmt"

func main(){
  studLst:=make(map[int]string)
  studLst[101]="Amit"
  studLst[102]="Seema"
  studLst[103]="Smita"
  studLst[104]="Joe"
  fmt.Println("Enter roll number to get name of the student")
  var rno int
  fmt.Scanln(&rno)
  fmt.Printf("name is :%s",studLst[rno])
}
