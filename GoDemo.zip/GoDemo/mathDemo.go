package main
import ("fmt"
        "MathPack")
func main(){
  fmt.Println(MathPack.Add(10,20))
  
  fmt.Println(MathPack.Multiply(40,20))
  fmt.Println(MathPack.Divide(100,20))
}
