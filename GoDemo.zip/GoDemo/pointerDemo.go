package main

import "fmt"

func main(){
  var num int
  var ptr *int
  num=100
  ptr=&num
  var nptr **int
  nptr=&ptr
  var xptr *int
  newptr:=new(int)
  newptr=&num
  fmt.Printf("\nvalue of num using pointer: %d",*ptr)
  fmt.Printf("\nvalue of num using pointer to pointer",**nptr)
  if xptr==nil{
    fmt.Println("\n No reference assigned to xptr pointer")
  }
  fmt.Printf("\n Value of num using new Pointer:%d",*newptr)
}
