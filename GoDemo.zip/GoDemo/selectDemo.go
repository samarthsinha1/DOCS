package main
import ("fmt"
        "time"
      )

      func main(){
        ch1:=make(chan string)
        ch2:=make(chan string)

        go func(){
          ch1<-"one"
          time.Sleep(10000)
        }()
        go func(){
          ch2<-"two"
          time.Sleep(10000)
        }()
        for i:=0;i<2;i++{
          select{
          case msg1:=<-ch1
          fmt.Println("Recieved",msg1)
        case msg2:=<-ch2
        fmt.Println("Recieved",msg2)
          }
        }
        var input string
        fmt.Scanln(&input)
      }
