package main
import "fmt"

func main(){
  var accNo,name,bal =1234,"Ravi",100.00
  var input,switchflag int
  switchflag=1
  fmt.Printf("\n the account info is...")
  fmt.Printf("\n Acc No %d",accNo)
  fmt.Printf("\n name = %s",name)
  fmt.Printf("\n Bal = %f",bal)
for switchflag==1{
fmt.Printf("1. change details \n  2.Withrawal  2.Deposit")
fmt.Scanln(&input)
switch(input){
case 1:
var flag string
flag="yes"
fmt.Printf("do you wish to change the details...(yes/no)")
fmt.Scanln(&flag)
if flag=="yes"{
  fmt.Printf("\nEnter Account num =")
  fmt.Scanln(&accNo)
  fmt.Printf("value accepted....")
  fmt.Printf("\nEnter name =")
  fmt.Scanln(&name)
    fmt.Printf("value accepted....")
  fmt.Printf("\nEnter bal =")
  fmt.Scanln(&bal)
    fmt.Printf("value accepted....")

  fmt.Printf("\n the CHANGED account info is...")
  fmt.Printf("\n Acc No %d",accNo)
  fmt.Printf("\n name = %s",name)
  fmt.Printf("\n Bal = %f",bal)

  fmt.Printf("do you wish to continue(1/0)")
  fmt.Scanln(&switchflag)
}
}

}


  }
