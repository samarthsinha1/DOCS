package main
import "fmt"

func main(){
  bankLst:=make(map[int]int)
  var flag int;
  var tempAccNo int;
  var bal int;
  fmt.Printf("Do you wish to enter the account details(0/1)")
  fmt.Scanln(&flag)
  for flag!=0{
    fmt.Printf("\nenter the account number")
    fmt.Scanln(&tempAccNo)
    fmt.Printf("\nenter the balance")
    fmt.Scanln(&bal)
    bankLst[tempAccNo]=bal
    fmt.Printf("\n Do you wish to enter more detail(0/1)")
    fmt.Scanln(&flag)
  }
  fmt.Printf("\n details entered")
  var acc int;
  fmt.Printf("\n enter the account number to be searched")
  fmt.Scanln(&acc)
  fmt.Printf("\nAvailable balance is :- %d",bankLst[acc])
}
