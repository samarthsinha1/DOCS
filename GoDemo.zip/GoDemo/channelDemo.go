package main
import (
  "fmt"
  "time"
)


func send(ch chan<- string){
  //ch=make(chan string)
  str:="hello"
  for i:=0;i<5;i++{
  ch<-str
  time.Sleep(10000)
  fmt.Println("\nsending...",str)
}
}
func recieve(ch<-chan string){
  for{
  //ch=make(chan string)
  msg:=<-ch
  fmt.Printf("\nRecieving:",msg)
  time.Sleep(10000)
}
}

func main(){

  ch1:=make(chan string)
  //ch2:=make(chan string)
  go send(ch1)
  go recieve(ch1)
  var input string;
  fmt.Scanln(&input)
}
