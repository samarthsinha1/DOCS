package main
import ("fmt"
        "strings"
)

func main(){
  var str string="Capgemini"
  fmt.Println(strings.ToUpper(str))
  fmt.Println(strings.ToLower(str))
  fmt.Println(strings.Index(str,"p"))
  fmt.Println(strings.Contains(str,"gemini"))
}
