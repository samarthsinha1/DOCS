package main
import "fmt"
import "math"
type Shape interface{
  area() float32
}
type Circle struct{
  radius float32
}
type Rect struct{
  length float32
  breadth float32
}
func (c Circle)area() float32{
  return math.Pi*c.radius*c.radius
}
func (r Rect)area() float32{
  return r.length*r.breadth
}
func getArea(sh Shape)float32{
  return sh.area()
}
func main(){
  var c1 Circle
  c1.radius=5
  fmt.Printf("Area of circle:%f",getArea(c1))
  var r1 Rect
  r1.length=5
  r1.breadth=7
  fmt.Printf("Area of Rectangle:%f",getArea(r1))
}
