package main
import "fmt"

func main(){
  var arr=[]int{10,20,30,40,50}
  var i int
  var aptr[5] *int
  for i=0;i<5;i++{
    aptr[i]=&arr[i]
  }
  for i=0;i<5;i++{
    fmt.Printf("\narr[%d]:%d",i,*aptr[i])
  }
}
