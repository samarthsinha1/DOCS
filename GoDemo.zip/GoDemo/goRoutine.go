package main
import ("fmt"
        "time")
func myLoop(str string){
  for i:=0;i<5;i++{
    fmt.Printf("\n %s:%d",str,i)
    time.Sleep(time.Second*2)
  }
}
func main(){
  go myLoop("Go Routine")
  go myLoop("Normal")

  fmt.Println("\nthis is the border")
  myLoop("third loop")
//  myLoop("third loop")
//  var input string
//  fmt.Scanln(&input)
}
