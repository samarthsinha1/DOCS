package main
import("fmt"
        "time"
        "sync")

func main(){
  var m=new(sync.Mutex)
  for i:=0;i<5;i++{
    go func(i int){
      m.Lock()
      fmt.Println("start")
      fmt.Println("value:",i)
      time.Sleep(time.Second*2)
      fmt.Println("End")
      m.Unlock()
    }(i)
  }
  var input string;
  fmt.Scanln(&input)
}
