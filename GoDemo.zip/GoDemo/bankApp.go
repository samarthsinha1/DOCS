package main

import "fmt"

func withdraw(withDrawAmt,bal int)int{



  if bal<withDrawAmt{

    defer func(){
      errm:=recover()
      fmt.Println(errm)
    }()
      panic("\ninsuffecient amt...")
      return bal
  }else{
    var updateBal int
 fmt.Println("\nwithdraw success")
  updateBal=bal-withDrawAmt
  return updateBal
}

}

/**************************************************/
func deposit(depositAmt,bal int)int{


  if depositAmt<=0{
    defer func(){
      errm:=recover()
      fmt.Println(errm)
    }()
      panic("\nincorrect amount....")
      return bal

  }else{
    var updateBal int
  fmt.Println("\ndeposit success")
  updateBal=bal+depositAmt
  return updateBal
}

}
/**************************************************/
func main(){
var choice int;
var amt int;
amt=1000
var flag int
flag=0
for flag!=1{
fmt.Println("\nselect the choice.....1.withdraw.......2.deposit")
fmt.Scanln(&choice)
switch(choice){
case 1:
 var withdraw1 int
 fmt.Printf("\n enter the amount to withraw")
 fmt.Scanln(&withdraw1)
 amt=withdraw(withdraw1,amt)    /*function call*/
 fmt.Printf("\navailable balance= %d",amt)
  break;
case 2:
  var deposit1 int
  fmt.Printf("\n enter the amount to deposit")
  fmt.Scanln(&deposit1)
  amt=deposit(deposit1,amt)  /*function call*/
  fmt.Printf("\navailable balance= %d ",amt)
  break;
default:fmt.Println("incorrect choice")
}
fmt.Printf("Exit??(0/1)")
fmt.Scanln(&flag)
}
}
