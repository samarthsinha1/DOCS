package main
import "fmt"
type Student struct{
  rollno int
  name string
  course string
  marks int
}
func PrintData(s Student){
  fmt.Printf("\nRollNo:%d",s.rollno)
  fmt.Printf("\nname:%s",s.name)
  fmt.Printf("\ncourse:%s",s.course)
  fmt.Printf("\nmarks:%d",s.marks)
}
func main(){

  var s1 Student
  s1.rollno=101
  s1.name="Tim"
  s1.course="Golang"
  s1.marks=80
  PrintData(s1)

}
