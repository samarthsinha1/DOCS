package main
import (
      "fmt"
      "os"
)

func main(){
  file,err:=os.Open("Sample.txt")
  if err!=nil{
    fmt.Println(err)
    return
  }
  defer file.Close()

  stat,err:=file.Stat()
/*  if err2!=nil{
    fmt.Println(err)
    return
  } */
  bs:=make([]byte,stat.Size())

  _,err=file.Read(bs)


  str:=string(bs)
  fmt.Println(str)
}
