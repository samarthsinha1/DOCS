package main

import "fmt"

func main()  {
  //var num1,num2,sum int
  var x,foo,msg=10,20.20,"hello"
  /*fmt.Println("enter the numbers")
  fmt.Scanf("%d %d",&num1,&num2)
  sum=num1+num2
  fmt.Printf("sum=%d",sum)
  */
  fmt.Printf("\n%s",msg)
  fmt.Printf("\n%d",x)
  fmt.Printf("\n%f",foo)

  fmt.Printf("\n%T",foo)
  fmt.Printf("\n%T",x)
  fmt.Printf("\n%T",msg)
}
