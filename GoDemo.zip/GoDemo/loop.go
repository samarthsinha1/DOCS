package main

import "fmt"

func main(){
  var cnt int
  cnt=1
  for cnt<10{
    fmt.Println("this is loop %d",cnt)
    cnt=cnt+1
}

}
