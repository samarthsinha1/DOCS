--24/01/2019(removing notrequired column in newMaterialSBAdmin table)
ALTER TABLE <SchemaName>.ong_sowcfg_SB_repairAndService 
DROP COLUMN unit_cost,
DROP COLUMN unit_quote_price,
DROP COLUMN total_cost,
DROP COLUMN total_quote_price,
DROP COLUMN repair_supplier,
DROP COLUMN price_category,
DROP COLUMN BOM_quantity;

--24/01/2019(adding required column in newMaterialSBAdmin table)
ALTER TABLE <SchemaName>.ong_sowcfg_SB_repairAndService
ADD COLUMN component_group VARCHAR,
ADD COLUMN machine_model VARCHAR,
ADD COLUMN module VARCHAR;

--23/01/2019 (enter the schema name of the AWS instance)
CREATE TABLE <SchemaName>.ong_sowcfg_SB_newMaterials (
	material_id SERIAL PRIMARY KEY,
	bulletin_sequence_id int4 NOT NULL,
	component_group Varchar NULL,
	componenet_code Varchar NULL,
	component_description Varchar NULL,
	quantity int4 NULL,
	machine_Model Varchar NULL,
	module Varchar NULL
)

--23/01/2019 (enter the schema name of the AWS instance)
CREATE TABLE <SchemaName>.ong_sowcfg_SB_operations (
            Operations_id SERIAL PRIMARY KEY,
            bulletin_sequence_id int4 NOT NULL,
            Operations_name Varchar NULL,
            labour_hours int4 NULL,
            labour_cost numeric(20,4) NULL,
            labour_price numeric(20,4) NULL,
            labour_quote_Price numeric(20,4) NULL,
            non_standard_operation_flag Varchar NULL,
            description Varchar NULL
)
--23/01/2019 (enter the schema name of the AWS instance)
CREATE TABLE <SchemaName>.ong_sowcfg_SB_repairAndService (
            repair_service_id SERIAL PRIMARY KEY,
            bulletin_sequence_id int4 NOT NULL,
            BOM_quantity int4 NULL,
            component_description Varchar NULL,
            component_code Varchar NULL,
            price_category Varchar NULL,
            quantity_repairs int4 NULL,
           repair_supplier Varchar NULL,
           repair_description Varchar NULL,
           unit_cost numeric(20,4) NULL,
           unit_quote_price numeric(20,4) NULL,
           total_cost numeric(20,4) NULL,
           total_quote_price numeric(20,4) NULL
)

--23/01/2019 (enter the schema name of the AWS instance)--"true" or "false" value will go for flag
ALTER TABLE <SchemaName>.ong_sowcfg_std_sb_lov 
ADD COLUMN is_new_SB_flag  VARCHAR;

-- 22/01/2019
ALTER TABLE prodorp.ong_sowcfg_trx_service_bulletin 
ADD COLUMN category VARCHAR;

-- 22/01/2019
ALTER TABLE prodorp.ong_sowcfg_std_sb_lov 
ADD COLUMN category VARCHAR;

