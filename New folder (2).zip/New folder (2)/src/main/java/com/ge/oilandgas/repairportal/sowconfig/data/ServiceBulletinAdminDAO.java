/*package com.ge.oilandgas.repairportal.sowconfig.data;

import com.ge.oilandgas.repairportal.sowconfig.entity.ServiceBulletinNewMaterials;
import com.ge.oilandgas.repairportal.sowconfig.entity.ServiceBulletinOperations;
import com.ge.oilandgas.repairportal.sowconfig.entity.ServiceBulletinRepairAndService;
import com.ge.oilandgas.repairportal.sowconfig.entity.ServiceBulletins;

public interface ServiceBulletinAdminDAO extends GenericDAO<ServiceBulletins, Long>{
//this is the interface
	
	ServiceBulletinNewMaterials saveSbNewMaterial(ServiceBulletinNewMaterials serviceBulletinNewMaterials);
	ServiceBulletinOperations saveSbOperation(ServiceBulletinOperations serviceBulletinOperations);
	ServiceBulletinRepairAndService saveSbRepairAndService(ServiceBulletinRepairAndService serviceBulletinRepairAndService);
	
}
*/