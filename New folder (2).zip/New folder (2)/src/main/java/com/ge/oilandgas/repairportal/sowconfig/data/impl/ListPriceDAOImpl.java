package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.oilandgas.repairportal.sowconfig.data.ListPriceDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.ListPriceRepository;
import com.ge.oilandgas.repairportal.sowconfig.entity.ListPrice;

@Component
public class ListPriceDAOImpl extends GenericCrudDAOImpl<ListPrice, Long> implements ListPriceDAO{

	@Autowired
	private ListPriceRepository listPriceRepository;

	public ListPriceDAOImpl(ListPriceRepository listPriceRepository) {
		this.listPriceRepository = listPriceRepository;
	}
	public ListPriceDAOImpl() {
		// TODO Auto-generated constructor stub
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public ListPriceRepository getRepository() {
		return listPriceRepository;
	}
	@Override
	public List<ListPrice> findListPriceByPriceListType(String priceListType) {
		
		return listPriceRepository.findByPriceListType(priceListType);
	}
	@Override
	public List<ListPrice> getListPriceMaterialPriceDetails(String partNumber, String newRepair) {
		return listPriceRepository.getListPriceMaterialPriceDetails(partNumber,newRepair);
	}
	@Override
	public List<ListPrice> getPartListWithOutSupplier(List<String> priceListTypeList, List<String> supplierTypeList,
			String partNumberString) {
		return listPriceRepository.getPartListWithOutSupplier(priceListTypeList,supplierTypeList,partNumberString.toLowerCase());
	}
	@Override
	public List<ListPrice> getPartListWithSupplier(List<String> priceListTypeList, List<String> supplierTypeList,
			String supplier, String partNumberString) {
		return listPriceRepository.getPartListWithSupplier(priceListTypeList,supplierTypeList,supplier,partNumberString.toLowerCase());
	}
	@Override
	public List<ListPrice> findListPriceByPriceListType(String priceListType, List<String> partNumerList) {
		 List<String> partNumerListLower = new ArrayList<>();
		 if(partNumerList!=null) {
			 for(String str : partNumerList) {
				 partNumerListLower.add(str.toLowerCase());
			 }
		 }
		return listPriceRepository.findByPriceListType(priceListType,partNumerListLower);
	}
	@Override
	public ListPrice getListPriceByPartNumber(String partNumber) {
		return listPriceRepository.getListPriceByPartNumber(partNumber);
	}

	
}
