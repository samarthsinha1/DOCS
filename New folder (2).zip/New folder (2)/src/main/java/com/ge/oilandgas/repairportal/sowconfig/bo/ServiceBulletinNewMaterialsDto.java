package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;


public class ServiceBulletinNewMaterialsDto implements Serializable{

	private Long materialId;
	private Long bulletinSeqId;
	private String componentGroup;
	private String componentCode;
	private String componentDescription;
	private Long quantity;
	private String machineModel;
	private String module;
	
	public Long getMaterialId() {
		return materialId;
	}
	public void setMaterialId(Long materialId) {
		this.materialId = materialId;
	}
	public Long getBulletinSeqId() {
		return bulletinSeqId;
	}
	public void setBulletinSeqId(Long bulletinSeqId) {
		this.bulletinSeqId = bulletinSeqId;
	}
	public String getComponentGroup() {
		return componentGroup;
	}
	public void setComponentGroup(String componentGroup) {
		this.componentGroup = componentGroup;
	}
	public String getComponentCode() {
		return componentCode;
	}
	public void setComponentCode(String componentCode) {
		this.componentCode = componentCode;
	}
	public String getComponentDescription() {
		return componentDescription;
	}
	public void setComponentDescription(String componentDescription) {
		this.componentDescription = componentDescription;
	}
	public Long getQuantity() {
		return quantity;
	}
	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}
	public String getMachineModel() {
		return machineModel;
	}
	public void setMachineModel(String machineModel) {
		this.machineModel = machineModel;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	@Override
	public String toString() {
		return "ServiceBulletinNewMaterialsDto [materialId=" + materialId + ", bulletinSeqId=" + bulletinSeqId
				+ ", componentGroup=" + componentGroup + ", componentCode=" + componentCode + ", componentDescription="
				+ componentDescription + ", quantity=" + quantity + ", machineModel=" + machineModel + ", module="
				+ module + "]";
	}
	
	
}
