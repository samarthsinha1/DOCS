package com.ge.oilandgas.repairportal.sowconfig.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ge.oilandgas.repairportal.sowconfig.entity.ReportFields;
import com.ge.oilandgas.repairportal.sowconfig.entity.ServiceBulletins;


@Repository
public interface ServiceBulletinsRepository  extends GenericCrudRepository<ServiceBulletins, Long> {
	
	@Query("SELECT s from ServiceBulletins s where s.id=?1")
	List<ServiceBulletins> findServiceBulletinsById(Long id);
	

}
