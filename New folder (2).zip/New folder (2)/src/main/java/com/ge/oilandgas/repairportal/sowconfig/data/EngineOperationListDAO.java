package com.ge.oilandgas.repairportal.sowconfig.data;

import java.util.List;


import com.ge.oilandgas.repairportal.sowconfig.entity.EngineOperationList;

public interface EngineOperationListDAO  extends GenericDAO<EngineOperationList, Long> {
	
	List<EngineOperationList> findEngineOperationList(String engine,String product);
	
	Long getLatestNumOperation(String engine,String product);
	
	Object[] getNumOperation(String engine,String product);

	List<EngineOperationList> findAllProductOperations(String product);


}
