package com.ge.oilandgas.repairportal.sowconfig.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ge.oilandgas.repairportal.sowconfig.entity.EngineOperationList;

@Repository
public interface EngineOperationListRepository extends GenericCrudRepository<EngineOperationList, Long>{

	@Query("SELECT s from EngineOperationList s where s.engine=?1 and s.plcProductType = ?2") 
	List<EngineOperationList> findEngineOperationList(String engine,String product);

	@Query("SELECT max(s.numOperation) from EngineOperationList s where s.engine=?1 and s.plcProductType = ?2")
	Long getLatestNumOperation(String engine,String product);
	
	@Query("SELECT s.numOperation,s.engine from EngineOperationList s where s.engine=?1 and s.plcProductType = ?2")
	Object[] getNumOperation(String engine,String product);

	@Query("SELECT s from EngineOperationList s where s.plcProductType = ?1  order by s.numOperation") 
	List<EngineOperationList> findAllProductOperations(String product);
	
}
