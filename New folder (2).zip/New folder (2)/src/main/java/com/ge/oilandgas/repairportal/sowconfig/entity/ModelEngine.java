package com.ge.oilandgas.repairportal.sowconfig.entity;

import java.util.LinkedList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name= "ong_sowcfg_trx_model_engine")
public class ModelEngine extends GenericEntity<Long>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@SequenceGenerator(name="SEQ_MODEL", sequenceName="ong_sowcfg_trx_model_engine_sequence_id")
	@GeneratedValue(generator="SEQ_MODEL", strategy=GenerationType.SEQUENCE)
	@Column(name="ENGINE_MODEL_SEQUENCE_ID")
	private Long id;
	
	@Column(name="MODEL")
	private String model;
	
	@Column(name="ENGINE")
	private String engine;
	
	@Column(name="checked")
	private String engineChecked;
	
	@Column(name="additional_comment")
	private String additionalComment;
	
	@OneToMany(cascade = CascadeType.ALL,
			fetch = FetchType.EAGER, orphanRemoval=true)
	@JoinColumn(name="engine_model_sequence_id",referencedColumnName="engine_model_sequence_id", nullable=false)
	@OrderBy
	private List<Modules> moduleList = new LinkedList<>();
	
	@OneToMany(cascade = CascadeType.ALL,
			fetch = FetchType.EAGER, orphanRemoval=true)
	@JoinColumn(name="engine_model_sequence_id",referencedColumnName="engine_model_sequence_id", nullable=false)
	@OrderBy
	private List<EngineOperations> engineOperationsList = new LinkedList<>();
	
	@OneToMany(cascade = CascadeType.ALL,
			fetch = FetchType.EAGER, orphanRemoval=true)
	@JoinColumn(name="engine_model_sequence_id",referencedColumnName="engine_model_sequence_id", nullable=false)
	@OrderBy
	private List<EngineMaterials> engineMaterialsList = new LinkedList<>();
	
	@OneToMany(cascade = CascadeType.ALL,
			fetch = FetchType.EAGER, orphanRemoval=true)
	@JoinColumn(name="engine_model_sequence_id",referencedColumnName="engine_model_sequence_id", nullable=false)
	@OrderBy
	private List<EngineMaterialRepair> engineMaterialRepairList = new LinkedList<>();
	
	
	
	public List<EngineMaterialRepair> getEngineMaterialRepairList() {
		return engineMaterialRepairList;
	}

	public void setEngineMaterialRepairList(List<EngineMaterialRepair> engineMaterialRepairList) {
		this.engineMaterialRepairList = engineMaterialRepairList;
	}

	public List<EngineMaterials> getEngineMaterialsList() {
		return engineMaterialsList;
	}

	public void setEngineMaterialsList(List<EngineMaterials> engineMaterialsList) {
		this.engineMaterialsList = engineMaterialsList;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getEngine() {
		return engine;
	}

	public void setEngine(String engine) {
		this.engine = engine;
	}

	@Override
	public Long getId() {
		return id;
	}

	@Override
	public void setId(Long id) {
		this.id=id;
	}
	

	public String getEngineChecked() {
		return engineChecked;
	}

	public void setEngineChecked(String engineChecked) {
		this.engineChecked = engineChecked;
	}

	public List<Modules> getModuleList() {
		return moduleList;
	}

	public void setModuleList(List<Modules> moduleList) {
		this.moduleList = moduleList;
	}

	public List<EngineOperations> getEngineOperationsList() {
		return engineOperationsList;
	}

	public void setEngineOperationsList(List<EngineOperations> engineOperationsList) {
		this.engineOperationsList = engineOperationsList;
	}

	public String getAdditionalComment() {
		return additionalComment;
	}

	public void setAdditionalComment(String additionalComment) {
		this.additionalComment = additionalComment;
	}	
	
}
