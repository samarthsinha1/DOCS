package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import com.ge.oilandgas.repairportal.sowconfig.bo.UserProfilesDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.UserRolesDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.UserSubRoleDto;
import com.ge.oilandgas.repairportal.sowconfig.data.UserProfileDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.EngineInfoRepository;
import com.ge.oilandgas.repairportal.sowconfig.entity.UserSubRole;

@Component
public class UserProfileDAOImpl  extends GenericCrudDAOImpl<UserSubRole, Long> implements UserProfileDAO {

	@Autowired
	EngineInfoRepository engineInfoRepository;
	@Autowired
	private JdbcTemplate jdbcTemplate;
 
	public UserProfileDAOImpl() {
		super();

	}
 
	 public UserProfileDAOImpl(EngineInfoRepository engineInfoRepository) {
	        this.engineInfoRepository = engineInfoRepository;
	    }
	    

		@SuppressWarnings("unchecked")
		@Override
	    public EngineInfoRepository getRepository() {
	        return engineInfoRepository;
	    }


	public List<UserProfilesDto> getUserInfo(Integer sso) {
		String query="select oop.user_sso,oop.user_first_name,oop.user_last_name,oop.user_middle_name,oop.user_email,oop.user_phone,oor.user_role,(select description from ong_orp_lookup_values where lookup_type='ONG_ORP_USER_ROLE_LIST' and lookup_code=oor.user_role) as user_role_des from ong_orp_user_profiles oop,ong_orp_user_roles oor where oop.user_sso=oor.user_sso AND oop.user_sso= ? order by oor.user_role";
	return jdbcTemplate.query(query, new Integer[] { sso },
    			new RowMapper<UserProfilesDto>() {
			public UserProfilesDto mapRow(ResultSet rs, int rowNum) throws SQLException {
				List<UserRolesDto> roleList = new ArrayList<>();
				UserProfilesDto userProfilesDto=new UserProfilesDto();
				userProfilesDto.setUserSso(rs.getString("user_sso"));
				userProfilesDto.setUserFirstName(rs.getString("user_first_name"));
				userProfilesDto.setUserLastName(rs.getString("user_last_name"));
				if(rs.getString("user_middle_name")==null){
					userProfilesDto.setUserMiddleName("");
				}else
				{
					userProfilesDto.setUserMiddleName(rs.getString("user_middle_name"));
				}
				userProfilesDto.setUserEmail(rs.getString("user_email"));
				userProfilesDto.setUserPhone(rs.getString("user_phone"));		
			
					do{	
						UserRolesDto userRolesDto=new UserRolesDto();
						userRolesDto.setUserRoleDes(rs.getString("user_role_des"));
						userRolesDto.setUserRole(rs.getString("user_role"));
						roleList.add(userRolesDto);
				}while(rs.next());
				userProfilesDto.setRole(roleList);
				return userProfilesDto;
				}
			});
		
		
	}
	
	@Override
	public List<UserSubRoleDto> getUserSubRole(Integer sso) {
		final List<UserSubRoleDto> returnList = new ArrayList<UserSubRoleDto>();
		String query="select subrole.user_role,subrole.user_sub_role,subrole.user_sso, (select description from ong_orp_lookup_values where lookup_type='ONG_ORP_USER_SUB_ROLE_LIST' and lookup_code=subrole.user_sub_role) as user_sub_role_des from ong_orp_user_sub_roles subrole where subrole.user_sso = ?";
		this.jdbcTemplate.query(query,new Integer[] { sso },
				new ResultSetExtractor<Object>() {
					@Override
					public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
						while (rs.next()) {
							UserSubRoleDto userSubRoleDto=new UserSubRoleDto();
							userSubRoleDto.setUserRole(rs.getString("user_role"));
							userSubRoleDto.setUserSubRole(rs.getString("user_sub_role"));
							userSubRoleDto.setUserSso(rs.getInt("user_sso"));
							userSubRoleDto.setUserSubRoleDescription(rs.getString("user_sub_role_des"));
							returnList.add(userSubRoleDto);
						}
						return null;
					}
				});
    	return returnList;
	}

}



