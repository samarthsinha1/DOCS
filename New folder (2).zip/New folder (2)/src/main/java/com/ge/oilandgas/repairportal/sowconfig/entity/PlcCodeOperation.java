package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name= "ong_sowcfg_trx_plc_code_operation")
public class PlcCodeOperation extends GenericEntity<Long>{

	private static final long serialVersionUID = 1L;
	@Id
	@SequenceGenerator(name="SEQ_PLC_CODE_OPERATION", sequenceName="ong_sowcfg_trx_plc_code_operation_sequence_id")
	@GeneratedValue(generator="SEQ_PLC_CODE_OPERATION", strategy=GenerationType.SEQUENCE)
	 @Column(name="plc_code_id")
	 private Long id; 

	 @Column(name="configured_sow")
	 private String configuredSow;
	 
	 @Column(name="sow_rev")
	 private Float sowRevisionNumber;
	 
	 @Column(name="plc_product_type")
	 private String plcProductType;
	 
	 @Column(name="plc_model")
	 private String plcModel;
	 
	 @Column(name="plc_module")
	 private String plcModule;
	 
	 @Column(name="plc_engine")
	 private String plcEngine;
	 
	 @Column(name="plc_operation_type")
	 private String plcOperationType;
	 
	 @Column(name="plc_code_routing")
	 private String plcCodeRouting;
	 
	 @Column(name="plc")
	 private String plc;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getConfiguredSow() {
		return configuredSow;
	}

	public void setConfiguredSow(String configuredSow) {
		this.configuredSow = configuredSow;
	}
	
	public Float getSowRevisionNumber() {
		return sowRevisionNumber;
	}

	public void setSowRevisionNumber(Float sowRevisionNumber) {
		this.sowRevisionNumber = sowRevisionNumber;
	}

	public String getPlcProductType() {
		return plcProductType;
	}

	public void setPlcProductType(String plcProductType) {
		this.plcProductType = plcProductType;
	}

	public String getPlcModel() {
		return plcModel;
	}

	public void setPlcModel(String plcModel) {
		this.plcModel = plcModel;
	}

	public String getPlcOperationType() {
		return plcOperationType;
	}

	public void setPlcOperationType(String plcOperationType) {
		this.plcOperationType = plcOperationType;
	}

	public String getPlcCodeRouting() {
		return plcCodeRouting;
	}

	public void setPlcCodeRouting(String plcCodeRouting) {
		this.plcCodeRouting = plcCodeRouting;
	}

	public String getPlc() {
		return plc;
	}

	public void setPlc(String plc) {
		this.plc = plc;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getPlcModule() {
		return plcModule;
	}

	public void setPlcModule(String plcModule) {
		this.plcModule = plcModule;
	}

	public String getPlcEngine() {
		return plcEngine;
	}

	public void setPlcEngine(String plcEngine) {
		this.plcEngine = plcEngine;
	}
	

}
