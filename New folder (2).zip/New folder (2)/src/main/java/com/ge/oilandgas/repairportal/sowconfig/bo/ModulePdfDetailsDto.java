package com.ge.oilandgas.repairportal.sowconfig.bo;

public class ModulePdfDetailsDto {
	private String module;
	private String fallOut;
	private Double labor;
	private Double materials;
	private Double specialServices;	
	private Double totalPrice;
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public Double getLabor() {
		return labor;
	}
	public void setLabor(Double labor) {
		this.labor = labor;
	}
	public Double getMaterials() {
		return materials;
	}
	public void setMaterials(Double materials) {
		this.materials = materials;
	}
	public Double getSpecialServices() {
		return specialServices;
	}
	public void setSpecialServices(Double specialServices) {
		this.specialServices = specialServices;
	}
	public Double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public String getFallOut() {
		return fallOut;
	}
	public void setFallOut(String fallOut) {
		this.fallOut = fallOut;
	}
	
	
}
