package com.ge.oilandgas.repairportal.sowconfig.data.repository;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.ge.oilandgas.repairportal.sowconfig.entity.CommercialView;

@Repository
public interface CommercialViewRepository extends GenericCrudRepository<CommercialView, Long> {
	
	@Query("SELECT s from CommercialView s where s.engineInfoId=?1")
	List<CommercialView> findCommercialViewByEngineInfoId(Long engine_info_id);

}
