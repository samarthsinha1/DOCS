package com.ge.oilandgas.repairportal.sowconfig.bo;

public class SowMasterMaterialDtoForUI {
	private String product;
    private String model;
    private String engine;
    private String module;
    private String sowIndex;
    private String partNumber;
	private String nomenclature;
    private Long bomQty;
    private String priceCategory;
    private String serviceRendered;
    private Float fallOut;
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getEngine() {
		return engine;
	}
	public void setEngine(String engine) {
		this.engine = engine;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	
	public String getSowIndex() {
		return sowIndex;
	}
	public void setSowIndex(String sowIndex) {
		this.sowIndex = sowIndex;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getNomenclature() {
		return nomenclature;
	}
	public void setNomenclature(String nomenclature) {
		this.nomenclature = nomenclature;
	}
	public Long getBomQty() {
		return bomQty;
	}
	public void setBomQty(Long bomQty) {
		this.bomQty = bomQty;
	}
	public String getPriceCategory() {
		return priceCategory;
	}
	public void setPriceCategory(String priceCategory) {
		this.priceCategory = priceCategory;
	}
	public String getServiceRendered() {
		return serviceRendered;
	}
	public void setServiceRendered(String serviceRendered) {
		this.serviceRendered = serviceRendered;
	}
	public Float getFallOut() {
		return fallOut;
	}
	public void setFallOut(Float fallOut) {
		this.fallOut = fallOut;
	}
   
    
}
