package com.ge.oilandgas.repairportal.sowconfig.bo;

public class SummaryByModulePdfHeaderDto {

	private String customerName;
	private String opptyId;
	private String opptyRev;
	private String opptyType;
	private String opptyDate;
	private String model;
	private String serialNumber;
	private String type;
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getOpptyId() {
		return opptyId;
	}
	public void setOpptyId(String opptyId) {
		this.opptyId = opptyId;
	}
	public String getOpptyRev() {
		return opptyRev;
	}
	public void setOpptyRev(String opptyRev) {
		this.opptyRev = opptyRev;
	}
	public String getOpptyType() {
		return opptyType;
	}
	public void setOpptyType(String opptyType) {
		this.opptyType = opptyType;
	}
	public String getOpptyDate() {
		return opptyDate;
	}
	public void setOpptyDate(String opptyDate) {
		this.opptyDate = opptyDate;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
}
