package com.ge.oilandgas.repairportal.sowconfig.data.repository;

import java.util.List;
import java.util.Set;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ge.oilandgas.repairportal.sowconfig.bo.EngineInfoSowSetDto;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineInfo;
import com.ge.oilandgas.repairportal.sowconfig.entity.UserSubRole;

@Repository
public interface EngineInfoRepository extends GenericCrudRepository<EngineInfo, Long> {
	
	@Query("SELECT s from EngineInfo s where s.model = ?1 and s.product = ?2 and s.scopeType= ?3")
	EngineInfo findByModel(String model,String product,String scopeType,String versionName);
	
	@Query("SELECT s FROM EngineInfo s where s.componentSequenceId= ?1 and s.model = ?2 and s.product= ?3")
	EngineInfo findByComponentSequenceId(Long componentSequenceId,String model, String product);
		
	@Query("SELECT s from EngineInfo s where s.componentSequenceId = ?1 and s.model= ?2 and s.product= ?3 and s.sowDocRev= ?4")
	EngineInfo getEngineInfoDetails(Long componentSequenceId, String model, String product, float version);

	@Query("SELECT s.sowDocRev,s.status FROM EngineInfo s where s.componentSequenceId= ?1 and s.model = ?2 and s.product= ?3")
	Object[] getVersionStatusList(Long componentSequenceId, String model, String product);

	@Query("SELECT distinct(s.docName) FROM EngineInfo s where s.docType= ?1 and s.model = ?2 and s.product= ?3 order by s.docName desc")
	Set<String> getDocNameList(String docType, String model, String product);

	@Query("SELECT max(s.sowDocRev) from EngineInfo s where s.componentSequenceId = ?1 and s.product= ?2 and s.model= ?3")
	Float getLatestSowVersion(Long componentSequenceId, String product, String model);
	
	@Query("SELECT max(s.componentSequenceId) from EngineInfo s")
	Long getLatestComponentId();
		
	@Query("delete from EngineInfo s where s.id =?1")
	void deleteEngineInfo(Long id);
	
	@Query("SELECT s from EngineInfo s where s.docType = ?1 and s.docName = ?2 and s.product = ?3 and s.model = ?4 and s.sowDocRev = ?5 and s.status='COMPLETED' ")
	EngineInfo getEngineInfoDetails(String docType, String docName, String product, String model, float version);

	@Query("SELECT distinct(s.docName) FROM EngineInfo s where s.docType= ?1 and s.model = ?2 and s.product= ?3 and s.status='COMPLETED' order by s.docName desc")
	Set<String> getCompletedDocNameList(String docType, String model, String product);

	@Query("SELECT max(s.sowDocRev) from EngineInfo s where s.docType = ?1 and s.docName = ?2 and s.product = ?3 and s.model = ?4 and s.status='COMPLETED'")
	float getLatestCompletedSowVersion(String docType, String docName, String product, String model);

	@Query("SELECT max(s.sowDocRev) from EngineInfo s where s.docType = ?1 and s.docName = ?2 and s.product = ?3 and s.model = ?4")
	Float getLatestSowVersion(String docType, String docName, String product, String model);

	@Query("SELECT s.docName FROM EngineInfo s where s.docType= ?1 and s.product = ?2")
	Set<String> getDocNames(String docType, String product);
	
	@Query("SELECT s.status,s.sowDocRev FROM EngineInfo s where s.product = ?1 and s.model= ?2 and s.docName = ?3")
	Object[] getNextStatusAndRevisionsList(String product, String model, String docName);

	@Query("SELECT s from EngineInfoSowSet s")
	List<EngineInfoSowSetDto> getAllSowSet();
	
	
	@Query("SELECT s FROM UserSubRole s where s.userRole in ?1 and s.userSso = ?2")
	List<UserSubRole> getUserSubRole(List<String> userRoleList,Integer sso);

}
