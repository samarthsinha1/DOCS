package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.*;


/**
 * Entity implementation class for Entity: ListPrice
 *
 */
@Entity
@Table(name= "ong_sowcfg_std_list_price_material_lov")
public class ListPrice extends GenericEntity<Long> {

	private static final long serialVersionUID = 1L;
	@Id
	@SequenceGenerator(name="SEQ_LIST_PRICE_MATERIAL", sequenceName="ong_sowcfg_std_list_price_material_lov_sequence_id")
	@GeneratedValue(generator="SEQ_LIST_PRICE_MATERIAL", strategy=GenerationType.SEQUENCE)
	 @Column(name="list_price_id")
	 private Long id; 
	
	 @Column(name="source")
	 private String source;
	 
	 @Column(name="price_list_type")
	 private String priceListType;
	 
	 @Column(name="supplier_type")
	 private String supplierType;
	 
	 @Column(name="part_number")
	 private String partNumber;
	 
	 @Column(name="part_number_description")
	 private String partNumberDescription;
	 
	 @Column(name="service_rendered")
	 private String serviceRendered;
	 
	 @Column(name="supplier")
	 private String supplier;
	 
	 @Column(name="organization")
	 private String organization;
	 
	 @Column(name="plant")
	 private String plant;
	 
	 @Column(name="family")
	 private String family;
	 
	 @Column(name="family_type")
	 private String familyType;
	 
	 @Column(name="unit_cost")
	 private float unitCost;
	 
	 @Column(name="unit_cost_currency")
	 private String unitCostCurrency;
	 
	 @Column(name="unit_price")
	 private float unitPrice;
	 
	 @Column(name="unit_price_currency")
	 private String unitPriceCurrency;
	 
	 @Column(name="price_category")
	 private String priceCategory;
	 
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}

	public String getPriceListType() {
		return priceListType;
	}
	public void setPriceListType(String priceListType) {
		this.priceListType = priceListType;
	}
	public String getSupplierType() {
		return supplierType;
	}
	public void setSupplierType(String supplierType) {
		this.supplierType = supplierType;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public String getPartNumberDescription() {
		return partNumberDescription;
	}
	public void setPartNumberDescription(String partNumberDescription) {
		this.partNumberDescription = partNumberDescription;
	}
	public String getServiceRendered() {
		return serviceRendered;
	}
	public void setServiceRendered(String serviceRendered) {
		this.serviceRendered = serviceRendered;
	}
	public String getSupplier() {
		return supplier;
	}
	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}
	public String getOrganization() {
		return organization;
	}
	public void setOrganization(String organization) {
		this.organization = organization;
	}
	public String getPlant() {
		return plant;
	}
	public void setPlant(String plant) {
		this.plant = plant;
	}
	public String getFamily() {
		return family;
	}
	public void setFamily(String family) {
		this.family = family;
	}
	public String getFamilyType() {
		return familyType;
	}
	public void setFamilyType(String familyType) {
		this.familyType = familyType;
	}
	public float getUnitCost() {
		return unitCost;
	}
	public void setUnitCost(float unitCost) {
		this.unitCost = unitCost;
	}
	public String getUnitCostCurrency() {
		return unitCostCurrency;
	}
	public void setUnitCostCurrency(String unitCostCurrency) {
		this.unitCostCurrency = unitCostCurrency;
	}
	public float getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(float unitPrice) {
		this.unitPrice = unitPrice;
	}
	public String getUnitPriceCurrency() {
		return unitPriceCurrency;
	}
	public void setUnitPriceCurrency(String unitPriceCurrency) {
		this.unitPriceCurrency = unitPriceCurrency;
	}
	public String getPriceCategory() {
		return priceCategory;
	}
	public void setPriceCategory(String priceCategory) {
		this.priceCategory = priceCategory;
	}

    
	 
}
