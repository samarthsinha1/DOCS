package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.util.ArrayList;
import java.util.List;

public class PartNumberListDto {
List<String> partNumbers=new ArrayList<>();

public List<String> getPartNumbers() {
	return partNumbers;
}

public void setPartNumbers(List<String> partNumbers) {
	this.partNumbers = partNumbers;
}

}
