package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineInfoForAllSowDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineInfoSowSetDto;
import com.ge.oilandgas.repairportal.sowconfig.data.EngineInfoDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.EngineInfoRepository;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineInfo;

@Component
public class EngineInfoDAOImpl extends GenericCrudDAOImpl<EngineInfo, Long> implements EngineInfoDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(EngineInfoDAOImpl.class);
	@Autowired
	private EngineInfoRepository engineInfoRepository;
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private final String DELETE_SOW_SQL = "delete from ong_sowcfg_trx_engine_model_info where info_sequence_id = ?";

	private final String ALL_ENGINEINFO_SQL = "SELECT s.info_sequence_id,s.doc_name,s.std_doc_rev,s.sow_doc_rev,s.model,p.product,s.CUSTOMER_NAME,"
			+ "s.SERIAL_NUMBER,s.CREATION_DATE,s.status,s.oppty_id,s.oppty_rev,s.sow_description,s.proposal_type, u.user_first_name,u.user_last_name,u.user_middle_name from "
			+ "ong_sowcfg_trx_engine_model_info s left outer join ong_orp_user_profiles u on s.CREATED_BY = u.user_sso left outer join "
			+ "ong_sowcfg_std_product_lov p on s.product = p.plc_product_type order by s.info_sequence_id";
	
	private final String SOW_SET_SQL ="select distinct ooss.sow_id,ooss.sow_set_code,ooss.sow_name,ooss.mandatory_flag from ONG_ORP_SOW_SET ooss where ooss.sow_set_code='A'";


    public EngineInfoDAOImpl(EngineInfoRepository engineInfoRepository) {
        this.engineInfoRepository = engineInfoRepository;
    }
    public EngineInfoDAOImpl() {
       super();
    }
    

    @SuppressWarnings("unchecked")
	@Override
    public EngineInfoRepository getRepository() {
        return engineInfoRepository;
    }


    @Override
	public EngineInfo findByModel(String model,String product,String scopeType,String versionName) {
		
		LOGGER.debug("Class::EngineInfoDAOImpl, Method::findByModel::model"+model);
		
		return engineInfoRepository.findByModel(model, product, scopeType, versionName);
	}

	@Override
	public EngineInfo findOne(Long id) {
		return engineInfoRepository.findOne(id);
	}
	
	@Override
	public EngineInfo createEngine(EngineInfo engineInfo) {
		return engineInfoRepository.save(engineInfo);
	}

	@Override
	public EngineInfo findByComponentSequenceId(Long componentSequenceId, String model, String product) {
		return engineInfoRepository.findByComponentSequenceId(componentSequenceId,model,product);
	}

	@Override
	public EngineInfo update(EngineInfo entity) {
		return super.update(entity);
	}

	@Override
	public EngineInfo getEngineInfoDetails(Long componentSequenceId,String model, String product, float version) {
		return engineInfoRepository.getEngineInfoDetails(componentSequenceId,model,product,version);
	}

	@Override
	public Object[] getVersionStatusList(Long componentSequenceId, String model, String product) {
		return engineInfoRepository.getVersionStatusList(componentSequenceId,model,product);
	}

	@Override
	public Float getLatestSowVersion(Long componentSequenceId,  String product, String model) {
		return engineInfoRepository.getLatestSowVersion(componentSequenceId, product,model);
	}
	@Override
	public Long getLatestComponentId() {
		return engineInfoRepository.getLatestComponentId();
	}
	
	public  List<EngineInfoForAllSowDto> getAllEngineInfo() {
		List<EngineInfoForAllSowDto> returnList = new ArrayList<>();
		returnList =jdbcTemplate.query(ALL_ENGINEINFO_SQL,
    			new RowMapper<EngineInfoForAllSowDto>() {
				public EngineInfoForAllSowDto mapRow(ResultSet rs, int rowNum) 	throws SQLException {
						EngineInfoForAllSowDto engineInfoForAllSowDto = new EngineInfoForAllSowDto();
						engineInfoForAllSowDto.setId(rs.getLong("info_sequence_id"));
						engineInfoForAllSowDto.setDocName(rs.getString("doc_name"));
						engineInfoForAllSowDto.setStdDocRev(rs.getFloat("std_doc_rev"));
						engineInfoForAllSowDto.setSowDocRev(rs.getFloat("sow_doc_rev"));
						engineInfoForAllSowDto.setModel(rs.getString("model"));
						engineInfoForAllSowDto.setProduct(rs.getString("product"));
						engineInfoForAllSowDto.setCustomerName(rs.getString("CUSTOMER_NAME"));
						engineInfoForAllSowDto.setSerialNumber(rs.getString("SERIAL_NUMBER"));
						engineInfoForAllSowDto.setCreationDate(rs.getTimestamp("CREATION_DATE"));
						engineInfoForAllSowDto.setStatus(rs.getString("status"));
						engineInfoForAllSowDto.setOpptyId(rs.getString("oppty_id"));
						engineInfoForAllSowDto.setOpptyRev(rs.getFloat("oppty_rev"));
						//engineInfoForAllSowDto.setOpptyType(rs.getString(""));
						engineInfoForAllSowDto.setSowDescription(rs.getString("sow_description"));
						engineInfoForAllSowDto.setProposalType(rs.getString("proposal_type"));
						engineInfoForAllSowDto.setUserFirstName(rs.getString("user_first_name") != null ? rs.getString("user_first_name") :"");
						engineInfoForAllSowDto.setUserLastName(rs.getString("user_last_name") != null ? rs.getString("user_last_name")  : "");
						engineInfoForAllSowDto.setUserMiddleName(rs.getString("user_middle_name") != null ? rs.getString("user_middle_name")   : "");
						return engineInfoForAllSowDto;
						}
     	});
		return  returnList;
	}
	
	@Override
	public Set<String> getDocNameList(String docType, String model, String product) {
		return engineInfoRepository.getDocNameList(docType,model,product);
	}
	@Override
	public void deleteEngineInfo(Long id) {
		List<Object[]> arg = new ArrayList<>();
		Object[] obj = new Object[1];
		obj[0] = id;
		arg.add(obj);
		jdbcTemplate.batchUpdate(DELETE_SOW_SQL,arg);
	}
	@Override
	public EngineInfo getEngineInfoDetails(String docType, String docName, String product, String model,
			float version) {
		return engineInfoRepository.getEngineInfoDetails(docType,docName,product, model, version);
	}
	@Override
	public Set<String> getCompletedDocNameList(String docType, String model, String product) {
		return engineInfoRepository.getCompletedDocNameList(docType,model,product);
	}
	@Override
	public float getLatestCompletedSowVersion(String docType, String docName, String product, String model) {
		return engineInfoRepository.getLatestCompletedSowVersion(docType,docName,product,model);
	}
	@Override
	public Float getLatestSowVersion(String docType, String docName, String product, String model) {
		return engineInfoRepository.getLatestSowVersion(docType,docName,product,model);
	}
	@Override
	public Set<String> getDocNames(String docType, String product) {
		return engineInfoRepository.getDocNames(docType,product);
	}
	@Override
	public Object[] getNextStatusAndRevisionsList(String product, String model, String docName) {
		return engineInfoRepository.getNextStatusAndRevisionsList(product,model,docName);
	}
	@Override
	public List<EngineInfoSowSetDto> getAllSowSet() {
		List<EngineInfoSowSetDto> returnList = new ArrayList<>();
		returnList =jdbcTemplate.query(SOW_SET_SQL,
    		new RowMapper<EngineInfoSowSetDto>() {
			public EngineInfoSowSetDto mapRow(ResultSet rs, int rowNum) 	throws SQLException {
				EngineInfoSowSetDto engineInfoSowSetDto = new EngineInfoSowSetDto();
				engineInfoSowSetDto.setId(rs.getLong("sow_id"));
				engineInfoSowSetDto.setSowSetCode(rs.getString("sow_set_code"));
				engineInfoSowSetDto.setSowName(rs.getString("sow_name"));
				engineInfoSowSetDto.setMandatoryFlag(rs.getString("mandatory_flag"));
				return engineInfoSowSetDto;
			}
     	});
		return  returnList;
	}
	
	
}
