package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EngineMaterialsDto extends AuditDataDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	private long engineModelSequenceId;
	private int bomQuantity;
	private Float fallout;
	private String nomenclature;
	private String partNumber;
	private int quantity;
	private String materialType;
	private List<ListPriceSuppliersDto> supplierList=new ArrayList<>();
	private String supplier;
	private String supplierType;
	private float cost;
	private float price;
	private float quotePrice;
	private float baseQuotePrice;
	private String priceCategory;
	private List<ListPriceServicesRenderedDto> serviceRenderedList= new ArrayList<>();
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public long getEngineModelSequenceId() {
		return engineModelSequenceId;
	}
	public void setEngineModelSequenceId(long engineModelSequenceId) {
		this.engineModelSequenceId = engineModelSequenceId;
	}
	
	public int getBomQuantity() {
		return bomQuantity;
	}
	public void bomValue(int bomQuantity) {
		this.bomQuantity = bomQuantity;
	}
	public String getNomenclature() {
		return nomenclature;
	}
	public void setNomenclature(String nomenclature) {
		this.nomenclature = nomenclature;
	}
	public String getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getMaterialType() {
		return materialType;
	}
	public void setMaterialType(String materialType) {
		this.materialType = materialType;
	}
	

	public List<ListPriceSuppliersDto> getSupplierList() {
		return supplierList;
	}
	public void setSupplierList(List<ListPriceSuppliersDto> supplierList) {
		this.supplierList = supplierList;
	}
	
	public List<ListPriceServicesRenderedDto> getServiceRenderedList() {
		return serviceRenderedList;
	}
	public void setServiceRenderedList(List<ListPriceServicesRenderedDto> serviceRenderedList) {
		this.serviceRenderedList = serviceRenderedList;
	}
	public String getSupplier() {
		return supplier;
	}
	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}
	
	public Float getFallout() {
		return fallout;
	}
	public void setFallout(Float fallout) {
		this.fallout = fallout;
	}
	public float getCost() {
		return cost;
	}
	public void setCost(float cost) {
		this.cost = cost;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public float getQuotePrice() {
		return quotePrice;
	}
	public void setQuotePrice(float quotePrice) {
		this.quotePrice = quotePrice;
	}
	public void setBomQuantity(int bomQuantity) {
		this.bomQuantity = bomQuantity;
	}
	
	public String getPriceCategory() {
		return priceCategory;
	}
	public void setPriceCategory(String priceCategory) {
		this.priceCategory = priceCategory;
	}
		
	public float getBaseQuotePrice() {
		return baseQuotePrice;
	}
	public void setBaseQuotePrice(float baseQuotePrice) {
		this.baseQuotePrice = baseQuotePrice;
	}
	
	public String getSupplierType() {
		return supplierType;
	}
	public void setSupplierType(String supplierType) {
		this.supplierType = supplierType;
	}
	@Override
	public String toString() {
		return "EngineMaterialsDto [id=" + id + ", engineModelSequenceId=" + engineModelSequenceId + ", bomQuantity="
				+ bomQuantity + ", fallout=" + fallout + ", nomenclature=" + nomenclature + ", partNumber=" + partNumber
				+ ", quantity=" + quantity + ", materialType=" + materialType + ", supplierList=" + supplierList
				+ ", supplier=" + supplier + ", cost=" + cost + ", price=" + price + ", quotePrice=" + quotePrice + "]";
	}
	
}
