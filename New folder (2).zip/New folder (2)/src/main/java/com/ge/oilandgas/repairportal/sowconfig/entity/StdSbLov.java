package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "ong_sowcfg_std_sb_lov")
public class StdSbLov extends GenericEntity<Long>{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="std_sb_id")
	private Long id;
	
	@Column(name="sb_id")
	private String sbId;
	
	@Column(name="sb_title")
	private String title;
	
	@Column(name="sow_sb_description")
	private String sbDescription;
	
	@Column(name="category")
	private String category;
	
	@Column(name="is_new_sb_flag")
	private String isNewSbFlag;
	
	@Column(name="sb_number")
	private String sbNumber;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSbDescription() {
		return sbDescription;
	}

	public void setSbDescription(String sbDescription) {
		this.sbDescription = sbDescription;
	}

	public String getSbId() {
		return sbId;
	}

	public void setSbId(String sbId) {
		this.sbId = sbId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getIsNewSbFlag() {
		return isNewSbFlag;
	}

	public void setIsNewSbFlag(String isNewSbFlag) {
		this.isNewSbFlag = isNewSbFlag;
	}

	public String getSbNumber() {
		return sbNumber;
	}

	public void setSbNumber(String sbNumber) {
		this.sbNumber = sbNumber;
	}

	
}
