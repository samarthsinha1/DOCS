package com.ge.oilandgas.repairportal.sowconfig.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ge.oilandgas.repairportal.sowconfig.entity.StdSbLov;

@Repository
public interface StdSbLovRepository extends GenericCrudRepository<StdSbLov, Long>{

	@Query("SELECT s from StdSbLov s")
	List<StdSbLov> getStdSbLov();
	
}


