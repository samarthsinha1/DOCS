package com.ge.oilandgas.repairportal.sowconfig.manager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.http.HttpHost;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.ge.oilandgas.repairportal.sowconfig.bo.EngineInfoDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineInfoForAllSowDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineInfoSowSetDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineMaterialRepairDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineMaterialsDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineOperationListDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineOperationsDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ListPriceDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ListPriceServicesRenderedDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ListPriceSuppliersDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.MasterMaterialLovTempDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ModelEngineDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ModuleMaterialRepairDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ModuleMaterialsDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ModuleOperationListDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ModuleOperationsDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ModulesDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseStatusDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ServiceBulletinsDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.UserProfilesDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.UserRolesDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.UserSubRoleDto;
import com.ge.oilandgas.repairportal.sowconfig.common.EntityBoMapper;
import com.ge.oilandgas.repairportal.sowconfig.data.EngineInfoDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.EngineModuleDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.EngineOperationListDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.ListPriceDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.ModuleOperationListDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.NonStdTempMaterialsDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.PlcCodeOperationDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.RepairSupplierDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.SowMasterMaterialDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.UserProfileDAO;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineInfo;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineModule;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineOperationList;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineOperations;
import com.ge.oilandgas.repairportal.sowconfig.entity.ListPrice;
import com.ge.oilandgas.repairportal.sowconfig.entity.MasterMaterialLovTemp;
import com.ge.oilandgas.repairportal.sowconfig.entity.ModelEngine;
import com.ge.oilandgas.repairportal.sowconfig.entity.ModuleOperationList;
import com.ge.oilandgas.repairportal.sowconfig.entity.ModuleOperations;
import com.ge.oilandgas.repairportal.sowconfig.entity.Modules;
import com.ge.oilandgas.repairportal.sowconfig.entity.PlcCodeOperation;
import com.ge.oilandgas.repairportal.sowconfig.entity.ProductLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.RepairSupplier;
import com.ge.oilandgas.repairportal.sowconfig.entity.SowMasterMaterial;
import com.ge.oilandgas.repairportal.sowconfig.utils.IrpSowConstants;

@Service
/*@Transactional(propagation = Propagation.SUPPORTS,
        readOnly = true)*/ 
public class SowConfigManager {

	private static final String NOSTD = "NOSTD";

	private static final String SUCCESS = "Success";

	private static final String DRAFT = "DRAFT";

	private static final String COMPLETED = "COMPLETED";

	private static final String SOW = "SOW";

	private static final String TRUE = "true";

	private static final String CREATE = "create";

	private static final String UPDATE = "update";

	private static final String HTTP_PROXY_EM_HEALTH_GE_COM = "http-proxy.em.health.ge.com";

	private static final String LOCAL = "local";
	
	private static final String ONE_ZERO_STRING = "0";
	
	private static final String TWO_ZERO_STRING = "00";

	@Value("${spring.profiles.active}")
	private String profile;
	
	@Value("${irp.admin.url}")
	private String irpAdminUrl;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SowConfigManager.class);
	@Autowired
	private EntityBoMapper entityBoMapper;
	@Autowired
	private EngineInfoDAO engineInfoDAO;
	@Autowired
	private EngineModuleDAO engineModuleDAO;
	@Autowired
	private SowMasterMaterialDAO sowMasterMaterialDAO;
	@Autowired
	PlcCodeOperationDAO plcCodeOperationDAO;
	@Autowired
	private ListPriceDAO listPriceDAO;
	@Autowired
	ModuleOperationListDAO moduleOperationListDAO;
	@Autowired
	EngineOperationListDAO engineOperationListDAO;
	@Autowired
	NonStdTempMaterialsDAO nonStdTempMaterialsDAO;
	@Autowired
	RepairSupplierDAO repairSupplierDAO;

	@Autowired
	UserProfileDAO userProfileDAO;
			
	
	private RestTemplate getRestTemplate() {
		HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
		String profileStatus = LOCAL;
		if (profile.equalsIgnoreCase(profileStatus)) {
		HttpHost myProxy = new HttpHost(HTTP_PROXY_EM_HEALTH_GE_COM, 88);
		HttpClientBuilder clientBuilder = HttpClientBuilder.create();
		clientBuilder.setProxy(myProxy);
		HttpClient httpClient = clientBuilder.build();
		factory.setHttpClient(httpClient);

		} else {
		HttpClientBuilder clientBuilder = HttpClientBuilder.create();
		HttpClient httpClient = clientBuilder.build();
		factory.setHttpClient(httpClient);

		}

		return new RestTemplate(factory);
		} 
	/**
     * Retrieves Engine Info by model
     * @param model
     * @return
     */
	public ResponseTemplateDto<EngineInfoDto> getEngineInfo(Long componentSequenceId,String model,String product) {
		LOGGER.debug("Class::sowconfigManager, Method::getsEngineInfo::ENTER");
		ResponseTemplateDto<EngineInfoDto> response = new ResponseTemplateDto<>();
		try{
			LOGGER.debug("Class::sowconfigManager, Method::getsEngineInfo::model"+model);
			Float latestVersion = engineInfoDAO.getLatestSowVersion(componentSequenceId,product,model);
			EngineInfoDto engineInfoDto = null;
			if(latestVersion != null ){
				EngineInfo engineInfo = engineInfoDAO.getEngineInfoDetails(componentSequenceId,model,product, latestVersion);
				engineInfoDto = entityBoMapper.map(engineInfo, EngineInfoDto.class);
				engineInfoDto.setExisting(true);
			}else{
				engineInfoDto = new EngineInfoDto();
				engineInfoDto.setComponentSequenceId(componentSequenceId);
				engineInfoDto.setModel(model);
				engineInfoDto.setProduct(product);
				engineInfoDto.setExisting(false);
			}
			LOGGER.debug("Class::sowconfigManager, Method::getsEngineInfo::engineInfo");
			response.setData(engineInfoDto);
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Class::sowconfigManager, Method::getsEngineInfo::Exception happened :: ",e);
			response.setSuccess(false);
			response.setStatusMsg("Error retrieving engineInfo for componentSequenceId= "+componentSequenceId);
		}
		LOGGER.debug("Class::sowconfigManager, Method::getsEngineInfo::EXIT");
		return response;
		
	}
	
	/**
	 * @param componentSequenceId
	 * @param model
	 * @param product
	 * @param version
	 * @return
	 */
	public ResponseTemplateDto<EngineInfoDto> getEngineInfoDetails(Long componentSequenceId,String model,String product, float version) {
		LOGGER.debug("Class::sowconfigManager, Method::getEngineInfoDetails::ENTER");
		ResponseTemplateDto<EngineInfoDto> response = new ResponseTemplateDto<>();
		try{
			EngineInfo engineInfo = engineInfoDAO.getEngineInfoDetails(componentSequenceId,model,product, version);
			EngineInfoDto engineInfoDto = entityBoMapper.map(engineInfo, EngineInfoDto.class);
			response.setData(engineInfoDto);
		} catch (Exception e) {
			LOGGER.error("Class::sowconfigManager, Method::getEngineInfoDetails::Exception happened :: ",e);
			response.setSuccess(false);
			response.setStatusMsg("Error retrieving getEngineInfoDetails for componentSequenceId= "+componentSequenceId);
		}
		LOGGER.debug("Class::sowconfigManager, Method::getEngineInfoDetails::Exit");
		return response;
		
	}

	/**
	 * @param docType
	 * @param docName
	 * @param model
	 * @param product
	 * @param eventType
	 * @return
	 */
	public ResponseTemplateDto<EngineInfoDto> getEngineInfoDetailsFromMaster(String docType, String docName, String model, String product, String eventType) {
		ResponseTemplateDto<EngineInfoDto> response = new ResponseTemplateDto<>();
		try{
			LOGGER.debug("Class::sowconfigManager, Method::getEngineInfoDetailsFromMaster::start");
			EngineInfoDto engineInfoDto = null;
			//setting doc name and versions
			//for Std template docname will be always SOW001 and version 0
			if(IrpSowConstants.STD_TEMPLATE.equalsIgnoreCase(docType)) {
				RestTemplate restTemplate = getRestTemplate();
				String res = restTemplate.getForObject(irpAdminUrl +"/getEngineInfoDetails/"+docType+"/"+docName+"/"+product+"/"+model,  String.class);
				ObjectMapper mapper = new ObjectMapper();
				engineInfoDto =  mapper.readValue(res, EngineInfoDto.class);
				resetAllIds(engineInfoDto);
				engineInfoDto.setDocType(IrpSowConstants.SOW_CONFIG);
				engineInfoDto.setStdDocName(engineInfoDto.getDocName());
				engineInfoDto.setDocName(null);
				
			}else if(IrpSowConstants.SOW_CONFIG.equalsIgnoreCase(docType)) {
				float latestCompletedSowVersion = engineInfoDAO.getLatestCompletedSowVersion(docType,docName, product, model);
				EngineInfo engineInfo = engineInfoDAO.getEngineInfoDetails(docType,docName, product, model,latestCompletedSowVersion);
				if(UPDATE.equalsIgnoreCase(eventType)) {
					engineInfo.setSowDocRev(null);
				}else if(CREATE.equalsIgnoreCase(eventType)) {
					engineInfo.setDocName(null);
					engineInfo.setSowDocRev(null);
					engineInfo.setStdDocName(null);
				}
				engineInfo.setStatus(null);
				if(TRUE.equalsIgnoreCase(engineInfo.getAdminUploaded())) {
					List<EngineModule> engineModuleList = engineModuleDAO.findEngineModule(engineInfo.getProduct());
					setDefaultEnginesAndModules(engineInfo,engineModuleList);
				}
				engineInfoDto = entityBoMapper.map(engineInfo, EngineInfoDto.class);
				setEngineAndModuleOperationDetails(engineInfoDto);
				resetAllIds(engineInfoDto);
			}	
			setEngineAndModuleOperationOptions(engineInfoDto);
			setMaterialPriceCategorySupplierAndServiceRendered(engineInfoDto,docName);
			response.setData(engineInfoDto);
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Class::sowconfigManager, Method::getEngineInfoDetailsFromMaster::Exception happened :: ",e);
			response.setSuccess(false);
			response.setStatusMsg("Error retrieving getEngineInfoDetailsFromMaster");
		}
		LOGGER.debug("Class::sowconfigManager, Method::getEngineInfoDetailsFromMaster::End");
		return response;
	}
	
	/**
	 * @param engineInfoDto
	 */
	private void setMaterialPriceCategorySupplierAndServiceRendered(EngineInfoDto engineInfoDto,String docName) {
		LOGGER.debug("Class::sowconfigManager, Method::setMaterialPriceCategorySupplierAndServicerendered::start");
		List<ModelEngineDto> modelEngineList = engineInfoDto.getModelEngineList();
		List<ListPrice> listPricesNew = listPriceDAO.findListPriceByPriceListType("NEW");
		List<ListPrice> listPricesOss = listPriceDAO.findListPriceByPriceListType("OSS");
		Map<String,ListPriceDto> listPriceMapNew = createListPriceMap(listPricesNew);
		Map<String,ListPriceDto> listPriceMapOss = createListPriceMap(listPricesOss);
		List<RepairSupplier> genericRepairSupplierList = repairSupplierDAO.findAllRS();
		List<MasterMaterialLovTemp> tempMaterialsList = null;
		if(docName != null ){
			tempMaterialsList = nonStdTempMaterialsDAO.getAllUserCreatedMaterials(docName);
			List<MasterMaterialLovTempDto> tempMaterialsDtoList = entityBoMapper.map(tempMaterialsList, MasterMaterialLovTempDto.class);
			engineInfoDto.setMasterMaterialLovTempDtoList(tempMaterialsDtoList);
		}
		if(modelEngineList != null) {
			for(ModelEngineDto modelEngine : modelEngineList) {
				List<SowMasterMaterial> sowMasterMaterialList = null;
				List<EngineMaterialsDto> engineMaterialsList =  modelEngine.getEngineMaterialsList();
				List<SowMasterMaterial> ggTestEngineMaterialList = sowMasterMaterialDAO.getGGTestEngineMaterialList(engineInfoDto.getProduct(), engineInfoDto.getModel(), modelEngine.getEngine(),"Depot Test");
				if(engineMaterialsList != null && engineMaterialsList.size() >0) {
					 sowMasterMaterialList= sowMasterMaterialDAO.getAllMaterialByEngine(engineInfoDto.getProduct(), engineInfoDto.getModel(), modelEngine.getEngine());
					 for(EngineMaterialsDto engineMaterials : engineMaterialsList) {
						if(sowMasterMaterialList != null) {
							for(SowMasterMaterial sowMasterMaterial : sowMasterMaterialList ) {
								if("N".equalsIgnoreCase(sowMasterMaterial.getNewRepair()) && engineMaterials.getPartNumber().trim().equalsIgnoreCase(sowMasterMaterial.getPartNumber().trim())) {
										engineMaterials.setPriceCategory(sowMasterMaterial.getPriceCategory());
									}
								}
						}
						if(ggTestEngineMaterialList != null) {
							for(SowMasterMaterial ggTestEngineMaterial : ggTestEngineMaterialList ) {
								if(ggTestEngineMaterial.getEngine()!= null && ggTestEngineMaterial.getEngine().equalsIgnoreCase(modelEngine.getEngine()) && 
										engineMaterials.getPartNumber().trim().equalsIgnoreCase(ggTestEngineMaterial.getPartNumber().trim())) {
									engineMaterials.setPriceCategory(ggTestEngineMaterial.getPriceCategory());
								}
							}
						}
						if(engineMaterials.getPartNumber() != null && listPriceMapNew.get(engineMaterials.getPartNumber().toUpperCase()) != null) {
							engineMaterials.setSupplierList(listPriceMapNew.get(engineMaterials.getPartNumber().toUpperCase()).getSupplierList());
							engineMaterials.setServiceRenderedList(listPriceMapNew.get(engineMaterials.getPartNumber().toUpperCase()).getServiceRenderedList());
							//clear and service rendered for NEW material
							List<ListPriceSuppliersDto> supplierList = engineMaterials.getSupplierList();
							for(ListPriceSuppliersDto listPriceSuppliersDto : supplierList) {
								listPriceSuppliersDto.setServiceRendered(null);
							}
							List<ListPriceServicesRenderedDto> serviceRenderedList = engineMaterials.getServiceRenderedList();
							for(ListPriceServicesRenderedDto listPriceServicesRenderedDto : serviceRenderedList) {
								listPriceServicesRenderedDto.setSupplier(null);
							}
							
						}
						if(tempMaterialsList != null) {
							for(MasterMaterialLovTemp temp : tempMaterialsList) {
								if(modelEngine.getEngine().equalsIgnoreCase(temp.getEngine()) && temp.getModule() == null) {
									if(engineMaterials.getPartNumber().trim().equalsIgnoreCase(temp.getPartNumber().trim())) {
										if(engineMaterials.getSupplierList() == null || engineMaterials.getSupplierList().size() == 0) {
											List<ListPriceSuppliersDto> supplierList = new ArrayList<>();
											for(RepairSupplier supplier : genericRepairSupplierList) {
												ListPriceSuppliersDto listPriceSuppliersDto = new ListPriceSuppliersDto();
												listPriceSuppliersDto.setSupplier(supplier.getSupplier());
												listPriceSuppliersDto.setSupplierType(supplier.getSupplierType());
												supplierList.add(listPriceSuppliersDto);
											}
											engineMaterials.setSupplierList(supplierList);
											engineMaterials.setPriceCategory(temp.getPriceCategory());
										}else{
											engineMaterials.setPriceCategory(temp.getPriceCategory());
										}
											
									}
								}
							}
						}
						
					 }
				}
				List<EngineMaterialRepairDto> engineMaterialRepairDtos = modelEngine.getEngineMaterialRepairList();
				if(engineMaterialRepairDtos != null) {
					for(EngineMaterialRepairDto engineMaterialRepairDto : engineMaterialRepairDtos) {
						for(SowMasterMaterial ggTestEngineMaterial : ggTestEngineMaterialList ) {
							if(ggTestEngineMaterial.getEngine()!= null && ggTestEngineMaterial.getEngine().equalsIgnoreCase(modelEngine.getEngine()) && 
									engineMaterialRepairDto.getPartNumber().trim().equalsIgnoreCase(ggTestEngineMaterial.getPartNumber().trim())) {
								engineMaterialRepairDto.setPriceCategory(ggTestEngineMaterial.getPriceCategory());
							}
						}
						
						if(sowMasterMaterialList != null) {
							for(SowMasterMaterial sowMasterMaterial : sowMasterMaterialList ) {
								if("R".equalsIgnoreCase(sowMasterMaterial.getNewRepair()) && engineMaterialRepairDto.getPartNumber().trim().equalsIgnoreCase(sowMasterMaterial.getPartNumber().trim())) {
									engineMaterialRepairDto.setPriceCategory(sowMasterMaterial.getPriceCategory());
									}
								}
						}
						
						if(engineMaterialRepairDto.getPartNumber() != null && listPriceMapOss.get(engineMaterialRepairDto.getPartNumber().toUpperCase()) != null) {
							engineMaterialRepairDto.setSupplierList(listPriceMapOss.get(engineMaterialRepairDto.getPartNumber().toUpperCase()).getSupplierList());
							engineMaterialRepairDto.setServiceRenderedList(listPriceMapOss.get(engineMaterialRepairDto.getPartNumber().toUpperCase()).getServiceRenderedList());
						}
						
						if(tempMaterialsList != null) {
							for(MasterMaterialLovTemp temp : tempMaterialsList) {
								if(modelEngine.getEngine().equalsIgnoreCase(temp.getEngine()) && temp.getModule() == null) {
									if(engineMaterialRepairDto.getPartNumber().trim().equalsIgnoreCase(temp.getPartNumber().trim())) {
										if(engineMaterialRepairDto.getSupplierList() == null || engineMaterialRepairDto.getSupplierList().size() == 0) {
											List<ListPriceSuppliersDto> supplierList = new ArrayList<>();
											for(RepairSupplier supplier : genericRepairSupplierList) {
												ListPriceSuppliersDto listPriceSuppliersDto = new ListPriceSuppliersDto();
												listPriceSuppliersDto.setSupplier(supplier.getSupplier());
												listPriceSuppliersDto.setSupplierType(supplier.getSupplierType());
												supplierList.add(listPriceSuppliersDto);
											}
											engineMaterialRepairDto.setSupplierList(supplierList);
											engineMaterialRepairDto.setPriceCategory(temp.getPriceCategory());
										}else{
											engineMaterialRepairDto.setPriceCategory(temp.getPriceCategory());
										}
									}
								}
							}
						}
					}
				}
				
			  List<ModulesDto> moduleList = modelEngine.getModuleList();
				if(moduleList != null) {
					Set<String> moduleNames = new HashSet<>();
					for(ModulesDto modules : moduleList) {
						moduleNames.add(modules.getModule());
					}
				    
				    List<SowMasterMaterial> ggTestMaterialList = sowMasterMaterialDAO.getGGTestModuleMaterialList(engineInfoDto.getProduct(), engineInfoDto.getModel(), modelEngine.getEngine(),"Depot Test");
					
					for(ModulesDto modules : moduleList) {
						sowMasterMaterialList= sowMasterMaterialDAO.getAllMaterialByModule(engineInfoDto.getProduct(), engineInfoDto.getModel(), modelEngine.getEngine(),modules.getModule());
						List<ModuleMaterialsDto> moduleMaterialsList = modules.getModuleMaterialsList();
						if(moduleMaterialsList != null && sowMasterMaterialList != null) {
							for(ModuleMaterialsDto moduleMaterials : moduleMaterialsList) {
								for(SowMasterMaterial sowMasterMaterial : sowMasterMaterialList ) {
									if("N".equalsIgnoreCase(sowMasterMaterial.getNewRepair()) && moduleMaterials.getPartNumber().trim().equalsIgnoreCase(sowMasterMaterial.getPartNumber().trim())) {
										moduleMaterials.setPriceCategory(sowMasterMaterial.getPriceCategory());
									}
								}
								if(ggTestMaterialList != null) {
									for(SowMasterMaterial ggTestMaterial : ggTestMaterialList ) {
										if(ggTestMaterial.getModule() != null && ggTestMaterial.getModule().equalsIgnoreCase(modules.getModule()) &&
												moduleMaterials.getPartNumber().trim().equalsIgnoreCase(ggTestMaterial.getPartNumber().trim())) {
											moduleMaterials.setPriceCategory(ggTestMaterial.getPriceCategory());
										}
									}
								}
								
								if(moduleMaterials.getPartNumber() != null && listPriceMapNew.get(moduleMaterials.getPartNumber().toUpperCase()) != null) {
									moduleMaterials.setSupplierList(listPriceMapNew.get(moduleMaterials.getPartNumber().toUpperCase()).getSupplierList());
									moduleMaterials.setServiceRenderedList(listPriceMapNew.get(moduleMaterials.getPartNumber().toUpperCase()).getServiceRenderedList());
									//clear Supplier and Service rendered for NEW material
									List<ListPriceSuppliersDto> supplierList = moduleMaterials.getSupplierList();
									for(ListPriceSuppliersDto listPriceSuppliersDto : supplierList) {
										listPriceSuppliersDto.setServiceRendered(null);
									}
									List<ListPriceServicesRenderedDto> serviceRenderedList = moduleMaterials.getServiceRenderedList();
									for(ListPriceServicesRenderedDto listPriceServicesRenderedDto : serviceRenderedList) {
										listPriceServicesRenderedDto.setSupplier(null);
									}
								}
								
								if(tempMaterialsList != null) {
									for(MasterMaterialLovTemp temp : tempMaterialsList) {
										if(modelEngine.getEngine().equalsIgnoreCase(temp.getEngine()) && temp.getModule() != null && temp.getModule().equalsIgnoreCase(modules.getModule())) {
											if(moduleMaterials.getPartNumber().trim().equalsIgnoreCase(temp.getPartNumber().trim())) {
												if(moduleMaterials.getSupplierList() == null || moduleMaterials.getSupplierList().size() == 0) {
													List<ListPriceSuppliersDto> supplierList = new ArrayList<>();
													for(RepairSupplier supplier : genericRepairSupplierList) {
														ListPriceSuppliersDto listPriceSuppliersDto = new ListPriceSuppliersDto();
														listPriceSuppliersDto.setSupplier(supplier.getSupplier());
														listPriceSuppliersDto.setSupplierType(supplier.getSupplierType());
														supplierList.add(listPriceSuppliersDto);
													}
													moduleMaterials.setSupplierList(supplierList);
													moduleMaterials.setPriceCategory(temp.getPriceCategory());
												}else{
													moduleMaterials.setPriceCategory(temp.getPriceCategory());
												}
											}
										}
									}
								}
							}
						}
						List<ModuleMaterialRepairDto> moduleMaterialsRepairList = modules.getModuleMaterialsRepairList();
						if(moduleMaterialsRepairList != null && ggTestMaterialList != null) {
							for(ModuleMaterialRepairDto moduleMaterialRepairDto : moduleMaterialsRepairList) {
								for(SowMasterMaterial ggTestMaterial : ggTestMaterialList ) {
									if(ggTestMaterial.getModule() != null && ggTestMaterial.getModule().equalsIgnoreCase(modules.getModule()) &&
											moduleMaterialRepairDto.getPartNumber().trim().equalsIgnoreCase(ggTestMaterial.getPartNumber().trim())) {
										moduleMaterialRepairDto.setPriceCategory(ggTestMaterial.getPriceCategory());
									}
								}
								
								if(sowMasterMaterialList != null) {
									for(SowMasterMaterial sowMasterMaterial : sowMasterMaterialList ) {
										if("R".equalsIgnoreCase(sowMasterMaterial.getNewRepair()) && moduleMaterialRepairDto.getPartNumber().trim().equalsIgnoreCase(sowMasterMaterial.getPartNumber().trim())) {
											moduleMaterialRepairDto.setPriceCategory(sowMasterMaterial.getPriceCategory());
											}
										}
								}
								
								
								if(moduleMaterialRepairDto.getPartNumber() != null && listPriceMapOss.get(moduleMaterialRepairDto.getPartNumber().toUpperCase()) != null) {
									moduleMaterialRepairDto.setSupplierList(listPriceMapOss.get(moduleMaterialRepairDto.getPartNumber().toUpperCase()).getSupplierList());
									moduleMaterialRepairDto.setServiceRenderedList(listPriceMapOss.get(moduleMaterialRepairDto.getPartNumber().toUpperCase()).getServiceRenderedList());
								}
								
								if(tempMaterialsList != null) {
									for(MasterMaterialLovTemp temp : tempMaterialsList) {
										if(modelEngine.getEngine().equalsIgnoreCase(temp.getEngine()) && temp.getModule() != null && temp.getModule().equalsIgnoreCase(modules.getModule())) {
											if(moduleMaterialRepairDto.getPartNumber().trim().equalsIgnoreCase(temp.getPartNumber().trim())) {
												if(moduleMaterialRepairDto.getSupplierList() == null || moduleMaterialRepairDto.getSupplierList().size() == 0) {
													List<ListPriceSuppliersDto> supplierList = new ArrayList<>();
													for(RepairSupplier supplier : genericRepairSupplierList) {
														ListPriceSuppliersDto listPriceSuppliersDto = new ListPriceSuppliersDto();
														listPriceSuppliersDto.setSupplier(supplier.getSupplier());
														listPriceSuppliersDto.setSupplierType(supplier.getSupplierType());
														supplierList.add(listPriceSuppliersDto);
														}
													moduleMaterialRepairDto.setSupplierList(supplierList);
													moduleMaterialRepairDto.setPriceCategory(temp.getPriceCategory());
												}else{
													moduleMaterialRepairDto.setPriceCategory(temp.getPriceCategory());
												}
											}
										}
									}
								}
							}
						}
					}
					
				}
			}	
		}
		LOGGER.debug("Class::sowconfigManager, Method::setMaterialPriceCategorySupplierAndServicerendered::End");
	}
	
	/**
	 * @param docName
	 * @return
	 */
	private String getNextDocName(String docName,String product) {
		String response = "";
		ProductLov productLov = sowMasterMaterialDAO.getProductDetails(product);
		String prefix = productLov.getPrefixCounter()!=null ? productLov.getPrefixCounter() : SOW;
		if(docName != null) {
			String[] temp = docName.split(prefix);
			int maxVersion = Integer.valueOf(temp[1]);
			maxVersion = maxVersion +1;
			if((maxVersion / 10 >= 1) && (maxVersion / 10 <10)) {
				response = prefix+ONE_ZERO_STRING+maxVersion;
			}else if(maxVersion / 10 >=10) {
				response = prefix+maxVersion;
			}else if(maxVersion / 10 < 1) {
				response = prefix+TWO_ZERO_STRING+maxVersion;
			}
		}
		return response;
	}
	/**
	 * @param docType
	 * @param model
	 * @param product
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public ResponseTemplateDto<List<String>> getDocNameListFromMaster(String docType, String model, String product) {
		LOGGER.debug("Class::sowconfigManager, Method::getDocNameListFromMaster::Start");
		ResponseTemplateDto<List<String>> response = new ResponseTemplateDto<>();
		try{ 
			if(IrpSowConstants.STD_TEMPLATE.equalsIgnoreCase(docType)) {
				RestTemplate restTemplate = getRestTemplate();
				String res = restTemplate.getForObject(irpAdminUrl +"/getDocNameList/"+docType+"/"+product+"/"+model,  String.class);
				ObjectMapper mapper = new ObjectMapper();
				List<String> list = mapper.readValue(res, List.class);
				response.setData(list);
			}else if(IrpSowConstants.SOW_CONFIG.equalsIgnoreCase(docType)) {
				Set<String> list = engineInfoDAO.getCompletedDocNameList(docType,model,product);
				List<String> returnList = sortDocNameList(product,list);
				response.setData(returnList);
			}
		} catch (Exception e) {
			LOGGER.error("Class::sowconfigManager, Method::getDocNameListFromMaster::Exception happened :: ",e);
			response.setSuccess(false);
			response.setStatusMsg("Error retrieving getDocNameListFromMaster for componentSequenceId= ");
		}	
		LOGGER.debug("Class::sowconfigManager, Method::getDocNameListFromMaster::Exit");
		return response;
	}
	
	/**
	 * @param product
	 * @param list
	 * @return
	 */
	private List<String> sortDocNameList(String productPtrefix, Set<String> list) {
		String prefix = productPtrefix!=null ? productPtrefix : SOW;
		List<String> returnList = new ArrayList<>();
		Set<Integer> docNames = new TreeSet<>();
		if(list != null) {
				for(String docName :list) {
					String[] docNameStrings = docName.split(prefix);
					try {
						Integer docNameCount = Integer.parseInt(docNameStrings[1]);
						docNames.add(docNameCount);
					}catch(Exception ex) {
						
					}
				}
				for(Integer temp :docNames) {
					String tempSow = "";
					if((temp / 10 >= 1) && (temp / 10 <10)) {
						tempSow = prefix+ONE_ZERO_STRING+temp;
					}else if(temp / 10 >=10) {
						tempSow = prefix+temp;
					}else if(temp / 10 < 1) {
						tempSow = prefix+TWO_ZERO_STRING+temp;
					}
					returnList.add(tempSow);
				}
			Collections.reverse(returnList);
		}
		return returnList;
	}
	/*@Transactional(
            propagation = Propagation.REQUIRED,
            readOnly = false)*/
	/**
	 * @param engineInfoDto
	 * @return
	 */
	public ResponseTemplateDto<EngineInfoDto> saveEngineInfo(EngineInfoDto engineInfoDto) {
		LOGGER.debug("Class::sowconfigManager, Method::createModel::ENTER");
		ResponseTemplateDto<EngineInfoDto> response = new ResponseTemplateDto<>();
		try{
			EngineInfo engineInfo = null;
			if(engineInfoDto.getId() != null) {
				if(StringUtils.isEmpty(engineInfoDto.getStatus()) || DRAFT.equalsIgnoreCase(engineInfoDto.getStatus())) {
					engineInfo = entityBoMapper.map(engineInfoDto, EngineInfo.class);
					engineInfo.setStatus(DRAFT);
					engineInfo.setLastUpdateDate(new Date());
					engineInfo.setSowSelection(changeSowSelectionListToString(engineInfoDto.getSowSelectionList()));
					engineInfo.setAdminUploaded("FALSE");
					engineInfo = engineInfoDAO.update(engineInfo);
				}else if(COMPLETED.equalsIgnoreCase(engineInfoDto.getStatus())) {
					Object[] list = engineInfoDAO.getNextStatusAndRevisionsList(engineInfoDto.getProduct(),engineInfoDto.getModel(),engineInfoDto.getDocName());
					if(list != null && list.length >0) {
						for(Object obj :list) {
							Object[] temp = (Object[])obj;
							String status = (String)temp[0];
							float rev = (float)temp[1];
							if(DRAFT.equalsIgnoreCase(status)) {
								response.setData(engineInfoDto);
								response.setSuccess(false);
								response.setStatusMsg("Already exist revision #"+ Math.round(rev)+" in status DRAFT ");
								return response;
							}
						}
					}
					resetAllIds(engineInfoDto);
					engineInfo = entityBoMapper.map(engineInfoDto, EngineInfo.class);
					float latestVersion = engineInfoDAO.getLatestSowVersion(engineInfoDto.getDocType(),engineInfoDto.getDocName(), engineInfoDto.getProduct(), engineInfoDto.getModel());
					engineInfo.setSowDocRev(latestVersion+1);
					engineInfo.setStatus(DRAFT);
					engineInfo.setSowSelection(changeSowSelectionListToString(engineInfoDto.getSowSelectionList()));
					engineInfo.setAdminUploaded("FALSE");
					engineInfo = engineInfoDAO.save(engineInfo);
				}
			}else{
				if(StringUtils.isEmpty(engineInfoDto.getDocName())) {
					Set<String> maxDocNameList = engineInfoDAO.getDocNames(engineInfoDto.getDocType(),engineInfoDto.getProduct());
					String maxDocName = getMaxDocNameFromList(maxDocNameList,engineInfoDto.getProduct());
					populateDocName(engineInfoDto, maxDocName);
					engineInfoDto.setSowDocRev((float)0);
				}else{
					if(engineInfoDto.getSowDocRev() == null) {
						Object[] list = engineInfoDAO.getNextStatusAndRevisionsList(engineInfoDto.getProduct(),engineInfoDto.getModel(),engineInfoDto.getDocName());
						if(list != null && list.length >0) {
							for(Object obj :list) {
								Object[] temp = (Object[])obj;
								String status = (String)temp[0];
								float rev = (float)temp[1];
								if(DRAFT.equalsIgnoreCase(status)) {
									response.setData(engineInfoDto);
									response.setSuccess(false);
									response.setStatusMsg("Already exist revision #"+ Math.round(rev)+" in status DRAFT ");
									return response;
								}
							}
						}
						float latestVersion = engineInfoDAO.getLatestSowVersion(engineInfoDto.getDocType(),engineInfoDto.getDocName(), engineInfoDto.getProduct(), engineInfoDto.getModel());
						engineInfoDto.setSowDocRev(latestVersion+1);	
					}
				}
				engineInfo = entityBoMapper.map(engineInfoDto, EngineInfo.class);
				engineInfo.setStatus(DRAFT);
				engineInfo.setSowSelection(changeSowSelectionListToString(engineInfoDto.getSowSelectionList()));
				engineInfo.setAdminUploaded("FALSE");
				engineInfo = engineInfoDAO.save(engineInfo);
			}
			saveNonStdTempMaterials(engineInfoDto);
			engineInfoDto=entityBoMapper.map(engineInfo, EngineInfoDto.class);
			setMaterialPriceCategorySupplierAndServiceRendered(engineInfoDto,engineInfoDto.getDocName());
			setEngineAndModuleOperationOptions(engineInfoDto);
			engineInfoDto.setSowSelectionList(changeSowSelectionToString(engineInfo != null ? engineInfo.getSowSelection() : null));
			response.setData(engineInfoDto);
			response.setSuccess(true);
			response.setStatusMsg(SUCCESS);
		}catch (Exception e) {
			LOGGER.error("Error while Saving SOW " , e);
			response.setSuccess(false);
			response.setStatusMsg("Error while Saving SOW :: " +e.getMessage());
		}
		return response;
	}
	
	
	/*@Transactional(
            propagation = Propagation.REQUIRED,
            readOnly = false)*/
	/**
	 * @param engineInfoDto
	 * @return
	 */
	public ResponseTemplateDto<EngineInfoDto> submitEngineInfo(EngineInfoDto engineInfoDto) {
		LOGGER.debug("Class::sowconfigManager, Method::submitEngineInfo::ENTER");
		ResponseTemplateDto<EngineInfoDto> response = new ResponseTemplateDto<>();
		try{
			EngineInfo engineInfo = null;
			if(engineInfoDto.getId() != null) {
				if(StringUtils.isEmpty(engineInfoDto.getStatus()) || DRAFT.equalsIgnoreCase(engineInfoDto.getStatus())) {
					engineInfo = entityBoMapper.map(engineInfoDto, EngineInfo.class);
					engineInfo.setStatus(COMPLETED);
					engineInfo.setLastUpdateDate(new Date());
					engineInfo.setSowSelection(changeSowSelectionListToString(engineInfoDto.getSowSelectionList()));
					engineInfo = engineInfoAllDataUpdate(engineInfo,engineInfoDto);
				}else if(COMPLETED.equalsIgnoreCase(engineInfoDto.getStatus())) {
					Object[] list = engineInfoDAO.getNextStatusAndRevisionsList(engineInfoDto.getProduct(),engineInfoDto.getModel(),engineInfoDto.getDocName());
					if(list != null && list.length >0) {
						for(Object obj :list) {
							Object[] temp = (Object[])obj;
							String status = (String)temp[0];
							float rev = (float)temp[1];
							if(DRAFT.equalsIgnoreCase(status)) {
								response.setData(engineInfoDto);
								response.setSuccess(false);
								response.setStatusMsg("Already exist revision #"+ Math.round(rev)+" in status DRAFT ");
								return response;
							}
						}
					}
					resetAllIds(engineInfoDto);
					engineInfo = entityBoMapper.map(engineInfoDto, EngineInfo.class);
					float latestVersion = engineInfoDAO.getLatestSowVersion(engineInfoDto.getDocType(),engineInfoDto.getDocName(), engineInfoDto.getProduct(), engineInfoDto.getModel());
					engineInfo.setSowDocRev(latestVersion+1);
					engineInfo.setStatus(COMPLETED);
					engineInfo.setSowSelection(changeSowSelectionListToString(engineInfoDto.getSowSelectionList()));
					engineInfo = engineInfoAllDataSave(engineInfo,engineInfoDto);
				}
			}else{
				if(StringUtils.isEmpty(engineInfoDto.getDocName())) {
					Set<String> maxDocNameList = engineInfoDAO.getDocNames(engineInfoDto.getDocType(),engineInfoDto.getProduct());
					String maxDocName = getMaxDocNameFromList(maxDocNameList,engineInfoDto.getProduct());
					populateDocName(engineInfoDto, maxDocName);
					engineInfoDto.setSowDocRev((float)0);
				}else{
					if(engineInfoDto.getSowDocRev() == null) {
						Object[] list = engineInfoDAO.getNextStatusAndRevisionsList(engineInfoDto.getProduct(),engineInfoDto.getModel(),engineInfoDto.getDocName());
						if(list != null && list.length >0) {
							for(Object obj :list) {
								Object[] temp = (Object[])obj;
								String status = (String)temp[0];
								float rev = (float)temp[1];
								if(DRAFT.equalsIgnoreCase(status)) {
									response.setData(engineInfoDto);
									response.setSuccess(false);
									response.setStatusMsg("Already exist revision #"+ Math.round(rev)+" in status DRAFT ");
									return response;
								}
							}
						}
						float latestVersion = engineInfoDAO.getLatestSowVersion(engineInfoDto.getDocType(),engineInfoDto.getDocName(), engineInfoDto.getProduct(), engineInfoDto.getModel());
						engineInfoDto.setSowDocRev(latestVersion+1);
					}
				}
				engineInfo = entityBoMapper.map(engineInfoDto, EngineInfo.class);
				engineInfo.setStatus(COMPLETED);
				engineInfo.setSowSelection(changeSowSelectionListToString(engineInfoDto.getSowSelectionList()));
				engineInfo = engineInfoAllDataSave(engineInfo,engineInfoDto);
			}
			saveSubmitNonStdMaterials(engineInfoDto);
			engineInfoDto=entityBoMapper.map(engineInfo, EngineInfoDto.class);
			setMaterialPriceCategorySupplierAndServiceRendered(engineInfoDto,engineInfoDto.getDocName());
			setEngineAndModuleOperationDetails(engineInfoDto);
			engineInfoDto.setSowSelectionList(changeSowSelectionToString(engineInfo != null ? engineInfo.getSowSelection() : null));
			//engineInfo.setAdminUploaded("FALSE");
			response.setData(engineInfoDto);
			response.setSuccess(true);
			response.setStatusMsg(SUCCESS);
		}catch (Exception e) {
			LOGGER.error("Error while submitting SOW  " , e);
			response.setSuccess(false);
			response.setStatusMsg("Error submitting SOW :: " +e.getMessage());
		}
		return response;
	}
	
	/**
	 * @param engineInfoDto
	 */
	private void resetAllIds(EngineInfoDto engineInfoDto) {
		engineInfoDto.setId(null);
		List<ServiceBulletinsDto> serviceBulletinsList = engineInfoDto.getServiceBulletinList();
		List<ModelEngineDto> modelEngineList = engineInfoDto.getModelEngineList();
		if(serviceBulletinsList != null) {
			for(ServiceBulletinsDto serviceBulletins : serviceBulletinsList) {
				serviceBulletins.setId(null);
			}
		}
		if(modelEngineList != null) {
			for(ModelEngineDto modelEngine : modelEngineList) {
				modelEngine.setId(null);
				List<EngineMaterialRepairDto> engineMaterialRepairList = modelEngine.getEngineMaterialRepairList();
				List<EngineMaterialsDto> engineMaterialsList =  modelEngine.getEngineMaterialsList();
				List<EngineOperationsDto> engineOperationsList = modelEngine.getEngineOperationsList();
				if(engineMaterialRepairList != null) {
					for(EngineMaterialRepairDto engineMaterialRepair : engineMaterialRepairList) {
						engineMaterialRepair.setId(null);
					}
				}
				if(engineMaterialsList != null) {
					for(EngineMaterialsDto engineMaterials : engineMaterialsList) {
						engineMaterials.setId(null);
					}
				}
				if(engineOperationsList != null) {
					for(EngineOperationsDto engineOperations : engineOperationsList) {
						engineOperations.setId(null);
					}
				}
				
				List<ModulesDto> moduleList = modelEngine.getModuleList();
				if(moduleList != null) {
					for(ModulesDto modules : moduleList) {
						modules.setId(null);
						List<ModuleMaterialsDto> moduleMaterialsList = modules.getModuleMaterialsList();
						List<ModuleMaterialRepairDto> moduleMaterialsRepairList = modules.getModuleMaterialsRepairList();
						List<ModuleOperationsDto> moduleOperationsList = modules.getModuleOperationsList();
						if(moduleMaterialsList != null) {
							for(ModuleMaterialsDto moduleMaterials : moduleMaterialsList) {
								moduleMaterials.setId(null);
							}
						}
						if(moduleMaterialsRepairList != null) {
							for(ModuleMaterialRepairDto moduleMaterialRepair : moduleMaterialsRepairList) {
								moduleMaterialRepair.setId(null);
							}
						}
						if(moduleOperationsList != null) {
							for(ModuleOperationsDto moduleOperations : moduleOperationsList) {
								moduleOperations.setId(null);
							}
						}
					}
				}
			}	
		}
	}
	
		
	public ResponseTemplateDto<List<EngineInfoForAllSowDto>> getAllEngineInfo() {
		LOGGER.debug("Start Class::sowconfigManager, Method::getAllEngineInfo");
		ResponseTemplateDto<List<EngineInfoForAllSowDto>> response = new ResponseTemplateDto<>();
		try{
			List<EngineInfoForAllSowDto> returnList = new ArrayList<>();
			List<String> returnDocNameList = new ArrayList<>();
			List<EngineInfoForAllSowDto> engineInfoForAllSowDtoList = engineInfoDAO.getAllEngineInfo();
			Map<String,List<EngineInfoForAllSowDto>> engineInfoForAllSowDtoMap = createEngineInfoForAllSowDtoMap(engineInfoForAllSowDtoList);
			Set<String> engineInfoForAllSowDtoKeySet = engineInfoForAllSowDtoMap.keySet();
			Set<String> productPrefixList = new TreeSet<>();
			List<ProductLov> productList = sowMasterMaterialDAO.getProductList();
			if(productList != null) {
				for(ProductLov productLov : productList) {
					if(productLov.getPrefixCounter() != null) {
						productPrefixList.add(productLov.getPrefixCounter());
					}
				}
			}
			for(String productPrefix : productPrefixList) {
				List<String> sortedDocNameList = sortDocNameList(productPrefix,engineInfoForAllSowDtoKeySet); 
				for(String sow : sortedDocNameList) {
					if(engineInfoForAllSowDtoMap.get(sow) != null) {
						returnList.addAll(engineInfoForAllSowDtoMap.get(sow));
					}
				}
				returnDocNameList.addAll(sortedDocNameList);
			}
			for(String initialDocName : engineInfoForAllSowDtoKeySet) {
				if(!returnDocNameList.contains(initialDocName)) {
					returnList.addAll(engineInfoForAllSowDtoMap.get(initialDocName));
				}
			}
			LOGGER.debug("Class::sowconfigManager, Method::getsEngineInfo::engineInfo");
			response.setData(returnList);
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Error retrieving getAllEngineInfo :: ",e);
			response.setSuccess(false);
			response.setStatusMsg("Error retrieving getAllEngineInfo");
		}
		LOGGER.debug("End Class::sowconfigManager, Method::getAllEngineInfo");
		return response;
	}
	
	/**
	 * @param id
	 * @return
	 */
	public ResponseTemplateDto<EngineInfoDto> getEngineInfoById(Long id) {
		LOGGER.debug("Start Class::sowconfigManager, Method::getEngineInfoById");
		ResponseTemplateDto<EngineInfoDto> response = new ResponseTemplateDto<>();
		try{
			EngineInfo engineInfo = engineInfoDAO.findOne(id);
			if(TRUE.equalsIgnoreCase(engineInfo.getAdminUploaded())) {
				List<EngineModule> engineModuleList = engineModuleDAO.findEngineModule(engineInfo.getProduct());
				setDefaultEnginesAndModulesForUploadedSow(engineInfo,engineModuleList);
			}
			EngineInfoDto engineInfoDto = entityBoMapper.map(engineInfo, EngineInfoDto.class);
			if(engineInfoDto != null) {
				setMaterialPriceCategorySupplierAndServiceRendered(engineInfoDto,engineInfoDto.getDocName());
				engineInfoDto.setSowSelectionList(changeSowSelectionToString(engineInfo.getSowSelection()));
				setEngineAndModuleOperationDetails(engineInfoDto);
				handleNonStdMaterial(engineInfo.getDocName(), engineInfoDto, false);
			}else{
				response.setSuccess(false);
				response.setStatusMsg("No SOW for :: "+id);
				return response;
			}
			response.setData(engineInfoDto);
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Error retrieving getEngineInfoById :: "+id,e);
			response.setSuccess(false);
			response.setStatusMsg("Error retrieving getEngineInfoById for :: "+id);
		}
		LOGGER.debug("End Class::sowconfigManager, Method::getEngineInfoById");
		return response;
	}
		
	
	/**
	 * @param id
	 * @return
	 */
	public ResponseStatusDto deleteEngineInfo(Long id,String docName) {
		LOGGER.debug("Start Class::sowconfigManager, Method::deleteEngineInfo");
		ResponseStatusDto response = new ResponseStatusDto();
		try{
			engineInfoDAO.deleteEngineInfo(id);
			//delete temp materials also.
			if(docName != null) {
				List<MasterMaterialLovTemp> nonStdList = nonStdTempMaterialsDAO.getAllUserCreatedMaterials(docName);
				nonStdTempMaterialsDAO.delete(nonStdList);
			}
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Error retrieving deleteEngineInfo :: "+id,e);
			response.setSuccess(false);
			response.setStatusMsg("Error retrieving deleteEngineInfo for :: "+id);
		}
		LOGGER.debug("End Class::sowconfigManager, Method::deleteEngineInfo");
		return response;
	}
	/**
	 * @param id
	 * @return
	 */
	public ResponseTemplateDto<EngineInfoDto> copyEngineInfo(Long id) {
		LOGGER.debug("Start Class::sowconfigManager, Method::copyEngineInfo");
		ResponseTemplateDto<EngineInfoDto> response = new ResponseTemplateDto<>();
		try{
			EngineInfo engineInfo = engineInfoDAO.findOne(id);
			EngineInfoDto engineInfoDto = entityBoMapper.map(engineInfo, EngineInfoDto.class);
			if(TRUE.equalsIgnoreCase(engineInfo.getAdminUploaded())) {
				List<EngineModule> engineModuleList = engineModuleDAO.findEngineModule(engineInfoDto.getProduct());
				setDefaultEnginesAndModulesForUploadedSow(engineInfo,engineModuleList);
			}
			setEngineAndModuleOperationOptions(engineInfoDto);
			if(engineInfoDto != null) {
				engineInfoDto.setDocName(null);
				engineInfoDto.setSowDocRev(null);
				engineInfoDto.setStatus(null);
				resetAllIds(engineInfoDto);
				engineInfoDto.setSowSelectionList(changeSowSelectionToString(engineInfo.getSowSelection()));
				setEngineAndModuleOperationDetails(engineInfoDto);
				setMaterialPriceCategorySupplierAndServiceRendered(engineInfoDto,engineInfo.getDocName());
				handleNonStdMaterial(engineInfo.getDocName(), engineInfoDto, true);
			}
			response.setData(engineInfoDto);
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Error while copyEngineInfo :: "+id,e);
			response.setSuccess(false);
			response.setStatusMsg("Error while copyEngineInfo for :: "+id);
		}
		LOGGER.debug("End Class::sowconfigManager, Method::copyEngineInfo");
		return response;
	}
	
		
	/**
	 * @param engineInfo
	 * @param engineModuleList
	 */
	private void setDefaultEnginesAndModules(EngineInfo engineInfo, List<EngineModule> engineModuleList) {
		LOGGER.debug("Class::sowconfigManager, Method::setDefaultEnginesAndModules::ENTER");
		List<ModelEngine> modelEngineList = engineInfo.getModelEngineList();
		Map<String,Integer> lastAddedModuleDetails = new HashMap<>();
		List<String> manuallyAddedEngine = new ArrayList<>();
		for(EngineModule engineModule : engineModuleList) {
			boolean isEngineSame = false;
			for(ModelEngine modelEngine : modelEngineList) {
				if(modelEngine.getEngine().equalsIgnoreCase(engineModule.getEngine())) {
					if(!manuallyAddedEngine.contains(engineModule.getEngine())) {
						modelEngine.setEngineChecked(TRUE);
					}
					isEngineSame = true;
					List<Modules> moduleList = modelEngine.getModuleList();
					boolean isModuleSame = false;
					int modulePosition = -1;
					if(moduleList != null) {
						for(int count =0 ; count< moduleList.size();count++) {
							if(moduleList.get(count).getModule().equalsIgnoreCase(engineModule.getModuleCode())) {
								moduleList.get(count).setModuleChecked(TRUE);
								isModuleSame = true;
								modulePosition = count;
								break;
							}
						}
					}
					if(!isModuleSame) {
						Modules newModules = new Modules();
						newModules.setEngine(engineModule.getEngine());
						newModules.setModule(engineModule.getModuleCode());
						newModules.setModuleChecked("false");
						if(moduleList == null) {
							moduleList = new ArrayList<>();
						}
						moduleList.add(newModules);
						modulePosition = moduleList.size()-1;
					}
					
					int lastPostion =-1;
					if(lastAddedModuleDetails!= null && lastAddedModuleDetails.size() > 0) {
						lastPostion = lastAddedModuleDetails.get(modelEngine.getEngine()) != null ?lastAddedModuleDetails.get(modelEngine.getEngine()) :-1;
					}
				   	Modules tempModules = moduleList.get(lastPostion+1);
					moduleList.set(lastPostion+1, moduleList.get(modulePosition));
					moduleList.set(modulePosition,tempModules);
					if(lastPostion != -1) {
						lastAddedModuleDetails.put(modelEngine.getEngine(),lastAddedModuleDetails.get(modelEngine.getEngine())+1);
					}else{
						lastAddedModuleDetails.put(modelEngine.getEngine(),0);
					}
					}
			}
			if(!isEngineSame) {
				ModelEngine newModelEngine =  new ModelEngine();
				newModelEngine.setEngine(engineModule.getEngine());
				newModelEngine.setEngineChecked("false");
				List<Modules> moduleList = new ArrayList<>();
				Modules newModules = new Modules();
				newModules.setEngine(engineModule.getEngine());
				newModules.setModule(engineModule.getModuleCode());
				newModules.setModuleChecked("false");
				moduleList.add(newModules);
				newModelEngine.setModuleList(moduleList);
				manuallyAddedEngine.add(engineModule.getEngine());
				modelEngineList.add(newModelEngine);
			}
		}
		List<String> engineList = new ArrayList<>();
		for(EngineModule engineModule : engineModuleList) {
			if(!engineList.contains(engineModule.getEngine())) {
				engineList.add(engineModule.getEngine());
			}
		}
		List<ModelEngine> tempList = new ArrayList<>();
		for(String engine:engineList) {
			for(ModelEngine modelEngine : modelEngineList) {
				if(engine.equalsIgnoreCase(modelEngine.getEngine())) {
					tempList.add(modelEngine);
				}
			}
		}
		engineInfo.setModelEngineList(tempList);
		LOGGER.debug("Class::sowconfigManager, Method::setDefaultEnginesAndModules::EXIT");
	}
	
	/**
	 * @param engineInfo
	 * @param engineModuleList
	 */
	private void setDefaultEnginesAndModulesForUploadedSow(EngineInfo engineInfo, List<EngineModule> engineModuleList) {
		LOGGER.debug("Class::sowconfigManager, Method::setDefaultEnginesAndModulesForUploadedSow::ENTER");
		List<ModelEngine> modelEngineList = engineInfo.getModelEngineList();
		Map<String,Integer> lastAddedModuleDetails = new HashMap<>();
		List<String> manuallyAddedEngine = new ArrayList<>();
		for(EngineModule engineModule : engineModuleList) {
			boolean isEngineSame = false;
			for(ModelEngine modelEngine : modelEngineList) {
				if(modelEngine.getEngine().equalsIgnoreCase(engineModule.getEngine())) {
					isEngineSame = true;
					List<Modules> moduleList = modelEngine.getModuleList();
					boolean isModuleSame = false;
					int modulePosition = -1;
					if(moduleList != null) {
						for(int count =0 ; count< moduleList.size();count++) {
							if(moduleList.get(count).getModule().equalsIgnoreCase(engineModule.getModuleCode())) {
								isModuleSame = true;
								modulePosition = count;
								break;
							}
						}
					}
					if(!isModuleSame) {
						Modules newModules = new Modules();
						newModules.setEngine(engineModule.getEngine());
						newModules.setModule(engineModule.getModuleCode());
						newModules.setModuleChecked("false");
						if(moduleList == null) {
							moduleList = new ArrayList<>();
						}
						moduleList.add(newModules);
						modulePosition = moduleList.size()-1;
					}
					
					int lastPostion =-1;
					if(lastAddedModuleDetails!= null && lastAddedModuleDetails.size() > 0) {
						lastPostion = lastAddedModuleDetails.get(modelEngine.getEngine()) != null ?lastAddedModuleDetails.get(modelEngine.getEngine()) :-1;
					}
				   	Modules tempModules = moduleList.get(lastPostion+1);
					moduleList.set(lastPostion+1, moduleList.get(modulePosition));
					moduleList.set(modulePosition,tempModules);
					if(lastPostion != -1) {
						lastAddedModuleDetails.put(modelEngine.getEngine(),lastAddedModuleDetails.get(modelEngine.getEngine())+1);
					}else{
						lastAddedModuleDetails.put(modelEngine.getEngine(),0);
					}
					}
			}
			if(!isEngineSame) {
				ModelEngine newModelEngine =  new ModelEngine();
				newModelEngine.setEngine(engineModule.getEngine());
				newModelEngine.setEngineChecked("false");
				List<Modules> moduleList = new ArrayList<>();
				Modules newModules = new Modules();
				newModules.setEngine(engineModule.getEngine());
				newModules.setModule(engineModule.getModuleCode());
				newModules.setModuleChecked("false");
				moduleList.add(newModules);
				newModelEngine.setModuleList(moduleList);
				manuallyAddedEngine.add(engineModule.getEngine());
				modelEngineList.add(newModelEngine);
			}
		}
		List<String> engineList = new ArrayList<>();
		for(EngineModule engineModule : engineModuleList) {
			if(!engineList.contains(engineModule.getEngine())) {
				engineList.add(engineModule.getEngine());
			}
		}
		
		List<ModelEngine> tempList = new ArrayList<>();
		for(String engine:engineList) {
			for(ModelEngine modelEngine : modelEngineList) {
				if(engine.equalsIgnoreCase(modelEngine.getEngine())) {
					tempList.add(modelEngine);
				}
			}
		}
		engineInfo.setModelEngineList(tempList);
		LOGGER.debug("Class::sowconfigManager, Method::setDefaultEnginesAndModulesForUploadedSow::EXIT");
	}
	
	/**
	 * @param id
	 * @return
	 */
	public ResponseTemplateDto<EngineInfoDto> updateEngineInfo(Long id) {
		LOGGER.debug("Start Class::sowconfigManager, Method::updateEngineInfo");
		ResponseTemplateDto<EngineInfoDto> response = new ResponseTemplateDto<>();
		try{
			EngineInfo engineInfo = engineInfoDAO.findOne(id);
			EngineInfoDto engineInfoDto = entityBoMapper.map(engineInfo, EngineInfoDto.class);
			if(TRUE.equalsIgnoreCase(engineInfo.getAdminUploaded())) {
				List<EngineModule> engineModuleList = engineModuleDAO.findEngineModule(engineInfoDto.getProduct());
				setDefaultEnginesAndModulesForUploadedSow(engineInfo,engineModuleList);
			}
			setEngineAndModuleOperationOptions(engineInfoDto);
			if(engineInfoDto != null && COMPLETED.equalsIgnoreCase(engineInfoDto.getStatus())) {
				engineInfoDto.setSowDocRev(null);
				engineInfoDto.setStatus(null);
				resetAllIds(engineInfoDto);
				response.setData(engineInfoDto);
				response.setSuccess(true);
				handleNonStdMaterial(engineInfo.getDocName(), engineInfoDto, true);
			}if(engineInfoDto != null && DRAFT.equalsIgnoreCase(engineInfoDto.getStatus())) {
				response.setData(engineInfoDto);
				response.setSuccess(true);
				handleNonStdMaterial(engineInfo.getDocName(), engineInfoDto, false);
			}else if(engineInfoDto == null) {
				response.setSuccess(false);
				response.setStatusMsg("No SOW record for :: "+id);
			}
			if(engineInfoDto != null) {
				engineInfoDto.setSowSelectionList(changeSowSelectionToString(engineInfo != null ? engineInfo.getSowSelection() : null));
				setEngineAndModuleOperationDetails(engineInfoDto);
				setMaterialPriceCategorySupplierAndServiceRendered(engineInfoDto,engineInfo.getDocName());
			}
		} catch (Exception e) {
			LOGGER.error("Error while updateEngineInfo :: "+id,e);
			response.setSuccess(false);
			response.setStatusMsg("Error while updateEngineInfo for :: "+id);
		}
		LOGGER.debug("End Class::sowconfigManager, Method::updateEngineInfo");
		return response;
	}
	
	private List<String> changeSowSelectionToString(String sowSelection) {
		List<String> returnList = new ArrayList<String>();
		if(sowSelection != null) {
			String[] sowArray = sowSelection.split(",");
			for(String sow : sowArray) {
				returnList.add(sow);
			}
		}
		return returnList;
	}
	
	private static String changeSowSelectionListToString(List<String> sowSelectionList) {
		String returnString = null;
		if(sowSelectionList != null ) {
			for(String sow : sowSelectionList) {
				if(returnString != null) {
					returnString = returnString+","+sow;
				}else{
					returnString = sow;
				}
			}
		}
		return returnString;
	}
	public ResponseTemplateDto<List<EngineInfoSowSetDto>> getAllSowSet() {
		LOGGER.debug("Start Class::sowconfigManager, Method::getAllSowSet");
		ResponseTemplateDto<List<EngineInfoSowSetDto>> response = new ResponseTemplateDto<>();
		List<EngineInfoSowSetDto> returnList = new ArrayList<>();
		try{
			List<EngineInfoSowSetDto> sowSet = engineInfoDAO.getAllSowSet();
			Set<String> sowNameSet = new HashSet<>();
			if(sowSet != null) {
				for(EngineInfoSowSetDto engineInfoSowSetDto : sowSet) {
					if(!sowNameSet.contains(engineInfoSowSetDto.getSowName())) {
						returnList.add(engineInfoSowSetDto);
						sowNameSet.add(engineInfoSowSetDto.getSowName());
					}
				}
			}
			response.setData(returnList);
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Error while getAllSowSet :: ",e);
			response.setSuccess(false);
			response.setStatusMsg("Error while calling getAllSowSet");
		}
		LOGGER.debug("End Class::sowconfigManager, Method::getAllSowSet");
		return response;
		
	}
	
	/**
	 * @param engineInfo
	 * @param engineInfoDto
	 * @return
	 */
	private EngineInfo engineInfoAllDataSave(EngineInfo engineInfo,EngineInfoDto engineInfoDto) {
		engineInfo.setAdminUploaded("FALSE");
		engineInfo = engineInfoDAO.save(engineInfo);
		saveNonStdOperations(engineInfoDto);
		savePlcCodeOperations(engineInfo);
		return engineInfo;
	}
	
	/**
	 * @param engineInfo
	 * @param engineInfoDto
	 * @return
	 */
	private EngineInfo engineInfoAllDataUpdate(EngineInfo engineInfo,EngineInfoDto engineInfoDto) {
		engineInfo = engineInfoDAO.update(engineInfo);
		saveNonStdOperations(engineInfoDto);
		savePlcCodeOperations(engineInfo);
		return engineInfo;
	}
	
	/**
	 * @param engineInfoDto
	 */
	private void setEngineAndModuleOperationDetails(EngineInfoDto engineInfoDto) {
		List<EngineOperationList> allEngineOperationList = engineOperationListDAO.findAllProductOperations(engineInfoDto.getProduct());
		List<ModuleOperationList> allModuleOperationList= moduleOperationListDAO.findAllProductOperations(engineInfoDto.getProduct());
		List<EngineOperationListDto> allEngineOperationDtoList=entityBoMapper.map(allEngineOperationList,EngineOperationListDto.class);
		List<ModuleOperationListDto> allModuleOperationListDto=entityBoMapper.map(allModuleOperationList,ModuleOperationListDto.class);
		Map<String,List<EngineOperationListDto>> engineOperationListMap = createEngineOperationListMap(allEngineOperationDtoList);
		Map<String,List<ModuleOperationListDto>> moduleOperationListMap = createModuleOperationListMap(allModuleOperationListDto);
		for(ModelEngineDto engineDto : engineInfoDto.getModelEngineList()){
			engineDto.setEngineOperationOptions(engineOperationListMap.get(engineDto.getEngine()));
			List<EngineOperationsDto> engineOperations = engineDto.getEngineOperationsList();
			List<String> lovOperationsList = createLovEngineOperationsList(engineOperationListMap.get(engineDto.getEngine()));
			List<EngineOperationListDto> engineNonStdOperationsList = new ArrayList<>();
			for(EngineOperationsDto engineOperationsDto :engineOperations) {
				if(!lovOperationsList.contains(engineOperationsDto.getOperations())) {
					EngineOperationListDto temp = new EngineOperationListDto();
					temp.setOperationName(engineOperationsDto.getOperations());
					temp.setPlcCodeRouting(NOSTD);
					temp.setEngine(engineDto.getEngine());
					temp.setOperationType(engineOperationsDto.getOperationType());
					temp.setNumOperation(engineOperationsDto.getNumOperation());
					engineNonStdOperationsList.add(temp);
				}
			}
			engineDto.setEngineNonStdOperationsList(engineNonStdOperationsList);
			for(ModulesDto modulesDto : engineDto.getModuleList()){
				modulesDto.setModuleOperationOptions(moduleOperationListMap.get(modulesDto.getModule()));
				List<String> lovModuleOperationsList = createLovModuleOperationsList(moduleOperationListMap.get(modulesDto.getModule()));
				List<ModuleOperationListDto> moduleNonStdOperationsList = new ArrayList<>();
				List<ModuleOperationsDto> moduleOperations = modulesDto.getModuleOperationsList();
				for(ModuleOperationsDto moduleOperationsDto :moduleOperations) {
					if(!lovModuleOperationsList.contains(moduleOperationsDto.getOperations())) {
						ModuleOperationListDto temp = new ModuleOperationListDto();
						temp.setOperationName(moduleOperationsDto.getOperations());
						temp.setPlcCodeRouting(NOSTD);
						temp.setEngine(engineDto.getEngine());
						temp.setOperationType(moduleOperationsDto.getOperationType());
						temp.setNumOperation(moduleOperationsDto.getNumOperation());
						moduleNonStdOperationsList.add(temp);
					}
				}
				modulesDto.setModuleNonStdOperationsList(moduleNonStdOperationsList);
			}
		}
	}
	
	/**
	 * @param engineInfoDto
	 */
	private void setEngineAndModuleOperationOptions(EngineInfoDto engineInfoDto) {
		List<EngineOperationList> allEngineOperationList = engineOperationListDAO.findAllProductOperations(engineInfoDto.getProduct());
		List<ModuleOperationList> allModuleOperationList= moduleOperationListDAO.findAllProductOperations(engineInfoDto.getProduct());
		List<EngineOperationListDto> allEngineOperationDtoList=entityBoMapper.map(allEngineOperationList,EngineOperationListDto.class);
		List<ModuleOperationListDto> allModuleOperationListDto=entityBoMapper.map(allModuleOperationList,ModuleOperationListDto.class);
		Map<String,List<EngineOperationListDto>> engineOperationListMap = createEngineOperationListMap(allEngineOperationDtoList);
		Map<String,List<ModuleOperationListDto>> moduleOperationListMap = createModuleOperationListMap(allModuleOperationListDto);
		for(ModelEngineDto engineDto : engineInfoDto.getModelEngineList()){
			engineDto.setEngineOperationOptions(engineOperationListMap.get(engineDto.getEngine()));
			for(ModulesDto modulesDto : engineDto.getModuleList()){
				modulesDto.setModuleOperationOptions(moduleOperationListMap.get(modulesDto.getModule()));
			}
		}
	}
	/**
	 * @param list
	 * @return
	 */
	private List<String> createLovModuleOperationsList(List<ModuleOperationListDto> list) {
		List<String> returnList = new ArrayList<>();
		if(list != null) {
			for(ModuleOperationListDto temp : list) {
				returnList.add(temp.getOperationName());
			}
		}
		return returnList;
	}
	/**
	 * @param engineOperations
	 * @return
	 */
	private List<String> createLovEngineOperationsList(List<EngineOperationListDto> engineOperations) {
		List<String> returnList = new ArrayList<>();
		if(engineOperations != null) {
			for(EngineOperationListDto temp : engineOperations) {
				returnList.add(temp.getOperationName());
			}
		}
		return returnList;
	}
	/**
	 * @param moduleOperationList
	 * @return
	 */
	private Map<String, List<ModuleOperationListDto>> createModuleOperationListMap(List<ModuleOperationListDto> moduleOperationList) {
		Map<String,List<ModuleOperationListDto>> moduleOperationListMap = new HashMap<>();
		for(ModuleOperationListDto temp : moduleOperationList) {
			if(moduleOperationListMap.get(temp.getModule()) != null) {
				List<ModuleOperationListDto> tempList = moduleOperationListMap.get(temp.getModule());
				tempList.add(temp);
			}else{
				List<ModuleOperationListDto> tempList = new ArrayList<>();
				tempList.add(temp);
				moduleOperationListMap.put(temp.getModule(), tempList);
			}
		}
		return moduleOperationListMap;
	}
	/**
	 * @param engineOperationList
	 * @return
	 */
	private Map<String, List<EngineOperationListDto>> createEngineOperationListMap(List<EngineOperationListDto> engineOperationList) {
		Map<String,List<EngineOperationListDto>> engineOperationListMap = new HashMap<>();
		for(EngineOperationListDto temp : engineOperationList) {
			if(engineOperationListMap.get(temp.getEngine()) != null) {
				List<EngineOperationListDto> tempList = engineOperationListMap.get(temp.getEngine());
				tempList.add(temp);
			}else{
				List<EngineOperationListDto> tempList = new ArrayList<>();
				tempList.add(temp);
				engineOperationListMap.put(temp.getEngine(), tempList);
			}
		}
		return engineOperationListMap;
	}
	/**
	 * @param engineInfo
	 */
	private void savePlcCodeOperations(EngineInfo engineInfo) {
		LOGGER.debug("Start Class::sowconfigManager, Method::savePlcCodeOperations");
		List<EngineModule> engineModuleList= engineModuleDAO.findEngineModule(engineInfo.getProduct());
		List<EngineLov> engineLovList= sowMasterMaterialDAO.getEngineLovList(engineInfo.getProduct());	
		Map<String,EngineModule> engineModuleMap = createEngineModuleMap(engineModuleList);
		Map<String,EngineLov> engineLovMap = createEngineLovMap(engineLovList);
		String plcModelCode = sowMasterMaterialDAO.getPlcModelCode(engineInfo.getProduct(), engineInfo.getModel());
		List<ModelEngine> modelEngineList = engineInfo.getModelEngineList();
		List<EngineOperationList> engineOperationList = plcCodeOperationDAO.getAllEngineOperationList(engineInfo.getProduct());
		List<ModuleOperationList> moduleOperationList = plcCodeOperationDAO.getAllModuleOperationList(engineInfo.getProduct());
		Map<String,EngineOperationList> engineOperationMap = createEngineOperationMap(engineOperationList);
		Map<String,ModuleOperationList> moduleOperationMap = createModuleOperationMap(moduleOperationList);
		if(modelEngineList != null) {
			for(ModelEngine modelEngine : modelEngineList) {
				if(TRUE.equalsIgnoreCase(modelEngine.getEngineChecked()))  {
					List<PlcCodeOperation> plcCodeOperationList = new ArrayList<>();
					List<EngineOperations> engineOperationsList = modelEngine.getEngineOperationsList();
					if(engineOperationsList != null) {
						for(EngineOperations engineOperations : engineOperationsList) {
							PlcCodeOperation plcCodeOperation = new PlcCodeOperation();
							plcCodeOperation.setConfiguredSow(engineInfo.getDocName());
							plcCodeOperation.setSowRevisionNumber(engineInfo.getSowDocRev());
							plcCodeOperation.setPlcProductType(engineInfo.getProduct());
							plcCodeOperation.setPlcModel(plcModelCode);
							plcCodeOperation.setPlcEngine(engineLovMap.get(modelEngine.getEngine()).getPlcEngineCode());
							if(engineOperations.getOperations() != null && engineOperationMap.get(modelEngine.getEngine() + engineOperations.getOperations()) != null) {
								plcCodeOperation.setPlcOperationType(engineOperationMap.get(modelEngine.getEngine() + engineOperations.getOperations()).getOperationType());
								plcCodeOperation.setPlcCodeRouting(engineOperationMap.get(modelEngine.getEngine() + engineOperations.getOperations()).getPlcCodeRouting());
							}
							String plcOperationType = plcCodeOperation.getPlcOperationType() != null ? plcCodeOperation.getPlcOperationType() : "";
							String plcCodeRouting = plcCodeOperation.getPlcCodeRouting() != null ? plcCodeOperation.getPlcCodeRouting() : "";
							plcCodeOperation.setPlc(plcCodeOperation.getPlcProductType() +  plcCodeOperation.getPlcModel() + plcCodeOperation.getPlcEngine()+ plcOperationType + plcCodeRouting);
							plcCodeOperation.setCreatedBy(engineInfo.getCreatedBy());
							plcCodeOperation.setLastUpdatedBy(engineInfo.getCreatedBy());
							plcCodeOperationList.add(plcCodeOperation);
						}
					}
					
					List<Modules> moduleList = modelEngine.getModuleList();
					if(moduleList != null) {
						for(Modules modules : moduleList) {
							if(TRUE.equalsIgnoreCase(modules.getModuleChecked()))  {
								List<ModuleOperations> moduleOperationsList = modules.getModuleOperationsList();
								if(moduleOperationsList != null) {
									for(ModuleOperations moduleOperations : moduleOperationsList) {
										PlcCodeOperation plcCodeOperation = new PlcCodeOperation();
										plcCodeOperation.setConfiguredSow(engineInfo.getDocName());
										plcCodeOperation.setSowRevisionNumber(engineInfo.getSowDocRev());
										plcCodeOperation.setPlcProductType(engineInfo.getProduct());
										plcCodeOperation.setPlcModel(plcModelCode);
										plcCodeOperation.setPlcEngine(engineLovMap.get(modelEngine.getEngine()).getPlcEngineCode());
										plcCodeOperation.setPlcModule(engineModuleMap.get(modules.getModule()).getPlcModule());
										if(moduleOperations.getOperations() != null && moduleOperationMap.get(modules.getModule() + moduleOperations.getOperations()) != null) {
											plcCodeOperation.setPlcOperationType(moduleOperationMap.get(modules.getModule() + moduleOperations.getOperations()).getOperationType());
											plcCodeOperation.setPlcCodeRouting(moduleOperationMap.get(modules.getModule() + moduleOperations.getOperations()).getPlcCodeRouting());
										}
										String plcOperationType = plcCodeOperation.getPlcOperationType() != null ? plcCodeOperation.getPlcOperationType() : "";
										String plcCodeRouting = plcCodeOperation.getPlcCodeRouting() != null ? plcCodeOperation.getPlcCodeRouting() : "";
										plcCodeOperation.setPlc(plcCodeOperation.getPlcProductType() +  plcCodeOperation.getPlcModel() + plcCodeOperation.getPlcEngine()+plcCodeOperation.getPlcModule()+ plcOperationType + plcCodeRouting);
										plcCodeOperation.setCreatedBy(engineInfo.getCreatedBy());
										plcCodeOperation.setLastUpdatedBy(engineInfo.getCreatedBy());
										plcCodeOperationList.add(plcCodeOperation);
									}
								}
							}
						}
					}
					if(plcCodeOperationList.size() >0) {
						plcCodeOperationDAO.save(plcCodeOperationList);
					}
				}
			}	
		}
		LOGGER.debug("Exit Class::sowconfigManager, Method::savePlcCodeOperations");
	}
	
	/**
	 * @param engineLovList
	 * @return
	 */
	private Map<String, EngineLov> createEngineLovMap(List<EngineLov> engineLovList) {
		Map<String,EngineLov> returnMap = new HashMap<>();
		for(EngineLov engineLov : engineLovList) {
			returnMap.put(engineLov.getEngine(), engineLov);
		}
		return returnMap;
	}
	/**
	 * @param engineModuleList
	 * @return
	 */
	private Map<String, EngineModule> createEngineModuleMap(List<EngineModule> engineModuleList) {
		Map<String,EngineModule> returnMap = new HashMap<>();
		for(EngineModule engineModule : engineModuleList) {
			returnMap.put(engineModule.getModuleCode(), engineModule);
		}
		return returnMap;
	}
	
	/**
	 * @param moduleOperationList
	 * @return
	 */
	private Map<String, ModuleOperationList> createModuleOperationMap(List<ModuleOperationList> moduleOperationList) {
		Map<String,ModuleOperationList> returnMap = new HashMap<>();
		for(ModuleOperationList moduleOperation : moduleOperationList) {
			returnMap.put(moduleOperation.getModule()+moduleOperation.getOperationName(), moduleOperation);
		}
		return returnMap;
	}
	/**
	 * @param engineOperationList
	 * @return
	 */
	private Map<String, EngineOperationList> createEngineOperationMap(List<EngineOperationList> engineOperationList) {
		Map<String,EngineOperationList> returnMap = new HashMap<>();
		for(EngineOperationList engineOperation : engineOperationList) {
			returnMap.put(engineOperation.getEngine()+engineOperation.getOperationName(), engineOperation);
		}
		return returnMap;
	}
	public ResponseTemplateDto<List<ListPriceDto>> getAllNewPriceList(List<String> partNumerList) {
		LOGGER.debug("Start Class::sowconfigManager, Method::getAllNewPriceList");
		ResponseTemplateDto<List<ListPriceDto>> response = new ResponseTemplateDto<>();
		try {
			List<ListPriceDto> returnList = null;
			List<ListPrice> listPricesNew = listPriceDAO.findListPriceByPriceListType("NEW",partNumerList);
			Map<String,ListPriceDto> listPriceMap = createListPriceMap(listPricesNew);
			returnList =  new ArrayList<>(listPriceMap.values()); 
			response.setStatusMsg(SUCCESS);
			response.setData(returnList);
		} catch (Exception e) {
			LOGGER.error("Class::sowconfigManager, Method::getAllNewPriceList::Exception happened :: ",e);
			response.setSuccess(false);
			response.setStatusMsg("Error retrieving getAllNewPriceList");
		}
		LOGGER.debug("Exit Class::sowconfigManager, Method::getAllNewPriceList");
		return response; 
	}
	
	/**
	 * @return
	 */
	public ResponseTemplateDto<List<ListPriceDto>> getAllRepairPriceList(List<String> partNumerList) {
		LOGGER.debug("Start Class::sowconfigManager, Method::getAllRepairPriceList");
		ResponseTemplateDto<List<ListPriceDto>> response = new ResponseTemplateDto<>();
		try {
			List<ListPriceDto> returnList = null;
			List<ListPrice> listPricesOss = listPriceDAO.findListPriceByPriceListType("OSS",partNumerList);
			Map<String,ListPriceDto> listPriceMap = createListPriceMap(listPricesOss);
			returnList =  new ArrayList<>(listPriceMap.values()); 
			response.setStatusMsg(SUCCESS);
			response.setData(returnList);
		} catch (Exception e) {
			LOGGER.error("Class::sowconfigManager, Method::getAllRepairPriceList::Exception happened :: ",e);
			response.setSuccess(false);
			response.setStatusMsg("Error retrieving getAllRepairPriceList");
		}
		LOGGER.debug("Exit Class::sowconfigManager, Method::getAllRepairPriceList");
		return response; 
	}
	
	/**
	 * @param listPriceList
	 * @return
	 */
	private Map<String, ListPriceDto> createListPriceMap(List<ListPrice> listPriceList) {
		LOGGER.debug("Start Class::sowconfigManager, Method::createListPriceMap");
		Map<String, ListPriceDto> returnMap = new HashMap<>();
		for(ListPrice listPrice : listPriceList) {
			if(returnMap.get(listPrice.getPartNumber().toUpperCase()) != null) {
				ListPriceDto listPriceDto = returnMap.get(listPrice.getPartNumber().toUpperCase()); 
				if(listPriceDto != null) {
						ListPriceSuppliersDto listPriceSuppliersDto = new ListPriceSuppliersDto();
					    listPriceSuppliersDto.setSupplier(listPrice.getSupplier());
						listPriceSuppliersDto.setSupplierType(listPrice.getSupplierType());
						listPriceSuppliersDto.setUnitCost(listPrice.getUnitCost());
						listPriceSuppliersDto.setUnitPrice(listPrice.getUnitPrice());
						listPriceSuppliersDto.setServiceRendered(listPrice.getServiceRendered());
						listPriceDto.getSupplierList().add(listPriceSuppliersDto);
						ListPriceServicesRenderedDto listPriceServicesRenderedDto = new ListPriceServicesRenderedDto();
						listPriceServicesRenderedDto.setPriceListType(listPrice.getPriceListType());
						listPriceServicesRenderedDto.setServiceRendered(listPrice.getServiceRendered());
						listPriceServicesRenderedDto.setSupplier(listPrice.getSupplier());
						listPriceDto.getServiceRenderedList().add(listPriceServicesRenderedDto);
				}
				
			}else{
				ListPriceDto listPriceDto = new ListPriceDto();
				List<ListPriceSuppliersDto> supplierList = new ArrayList<>();
				List<ListPriceServicesRenderedDto> serviceRenderedList = new ArrayList<>();
				listPriceDto.setPartNumber(listPrice.getPartNumber());
				ListPriceSuppliersDto listPriceSuppliersDto = new ListPriceSuppliersDto();
				ListPriceServicesRenderedDto listPriceServicesRenderedDto = new ListPriceServicesRenderedDto();
				listPriceSuppliersDto.setSupplier(listPrice.getSupplier());
				listPriceSuppliersDto.setSupplierType(listPrice.getSupplierType());
				listPriceSuppliersDto.setUnitCost(listPrice.getUnitCost());
				listPriceSuppliersDto.setUnitPrice(listPrice.getUnitPrice());
				listPriceSuppliersDto.setServiceRendered(listPrice.getServiceRendered());
				listPriceServicesRenderedDto.setPriceListType(listPrice.getPriceListType());
				listPriceServicesRenderedDto.setServiceRendered(listPrice.getServiceRendered());
				listPriceServicesRenderedDto.setSupplier(listPrice.getSupplier());
				serviceRenderedList.add(listPriceServicesRenderedDto);
				supplierList.add(listPriceSuppliersDto);
				listPriceDto.setServiceRenderedList(serviceRenderedList);
				listPriceDto.setSupplierList(supplierList);
				returnMap.put(listPrice.getPartNumber().toUpperCase(), listPriceDto);
			}
		}
		LOGGER.debug("Exit Class::sowconfigManager, Method::createListPriceMap");
		return returnMap;
	}
	
	private void saveNonStdOperations(EngineInfoDto engineInfoDto) {
		LOGGER.debug("Start Class::sowconfigManager, Method::saveNonStdOperationsAndMaterials");
		List<ModelEngineDto> modelEngineList = engineInfoDto.getModelEngineList();
		List<EngineOperationListDto> engineOperationDtoList = new ArrayList<>();
		List<ModuleOperationListDto> moduleOperationDtoList = new ArrayList<>();
		if(modelEngineList != null) {
			for(ModelEngineDto modelEngineDto : modelEngineList) {
				if("true".equalsIgnoreCase(modelEngineDto.getEngineChecked())) {
					 List<EngineOperationListDto> engineNonStdOperationsList = modelEngineDto.getEngineNonStdOperationsList();
					 engineOperationDtoList.addAll(engineNonStdOperationsList);
					 List<ModulesDto> moduleList = modelEngineDto.getModuleList();
						if(moduleList != null) {
							for(ModulesDto modules : moduleList) {
								if("true".equalsIgnoreCase(modules.getModuleChecked())) {
									List<ModuleOperationListDto> moduleNonStdOperationsList = modules.getModuleNonStdOperationsList();
									moduleOperationDtoList.addAll(moduleNonStdOperationsList);
								}
							}
						}
				}
			}
		}
		List<EngineOperationList> engineOperationList = entityBoMapper.map(engineOperationDtoList, EngineOperationList.class);
		List<ModuleOperationList> moduleOperationList =  entityBoMapper.map(moduleOperationDtoList, ModuleOperationList.class);
		for(EngineOperationList temp : engineOperationList ) {
			temp.setStdOperation(NOSTD);
			temp.setPlcCodeRouting(NOSTD);
			temp.setCreatedBy(engineInfoDto.getLastUpdatedBy());
			temp.setLastUpdatedBy(engineInfoDto.getLastUpdatedBy());
		}
		
		for(ModuleOperationList temp1 : moduleOperationList ) {
			temp1.setStdOperation(NOSTD);
			temp1.setPlcCodeRouting(NOSTD);
			temp1.setCreatedBy(engineInfoDto.getLastUpdatedBy());
			temp1.setLastUpdatedBy(engineInfoDto.getLastUpdatedBy());
		}
		moduleOperationListDAO.save(moduleOperationList);
		engineOperationListDAO.save(engineOperationList);
		LOGGER.debug("Exit Class::sowconfigManager, Method::saveNonStdOperationsAndMaterials");	
	}
	

	
	/**
	 * @param maxDocNameList
	 * @param product
	 * @return
	 */
	private String getMaxDocNameFromList(Set<String> maxDocNameList, String product) {
		//get product details from DB
		ProductLov productLov = sowMasterMaterialDAO.getProductDetails(product);
		String prefix = productLov.getPrefixCounter()!=null ? productLov.getPrefixCounter() : SOW;
		String response = null;
		long maxNumber = 0;
		if(maxDocNameList != null && maxDocNameList.size() >0 ) {
				for(String sow : maxDocNameList) {
					String[] temp = sow.split(prefix);
					long maxVersion = Integer.valueOf(temp[1]);
					if(maxVersion > maxNumber) {
						maxNumber = maxVersion;
					}
				}
				if((maxNumber / 10 >= 1) && (maxNumber / 10 <10)) {
					response = prefix+ONE_ZERO_STRING+maxNumber;
				}else if(maxNumber / 10 >=10) {
					response = prefix+maxNumber;
				}else if(maxNumber / 10 < 1) {
					response = prefix+TWO_ZERO_STRING+maxNumber;
				}
		}
		return response;
	}
	
	/**
	 * @param engineInfoForAllSowDtoList
	 * @return
	 */
	private Map<String, List<EngineInfoForAllSowDto>> createEngineInfoForAllSowDtoMap(List<EngineInfoForAllSowDto> engineInfoForAllSowDtoList) {
		Map<String, List<EngineInfoForAllSowDto>> returnMap = new HashMap<>();
		for(EngineInfoForAllSowDto engineInfoForAllSowDto : engineInfoForAllSowDtoList) {
			String docName = engineInfoForAllSowDto.getDocName();
			if(returnMap.get(docName) != null) {
				List<EngineInfoForAllSowDto> tempList = returnMap.get(docName);
				tempList.add(engineInfoForAllSowDto);
			}else{
				List<EngineInfoForAllSowDto> tempList = new ArrayList<>();
				tempList.add(engineInfoForAllSowDto);
				returnMap.put(docName, tempList);
			}
		}
		return returnMap;
	}
	
	/**
	 * @param engineInfoDto
	 */
	private void saveNonStdTempMaterials(EngineInfoDto engineInfoDto) {
		 List<MasterMaterialLovTempDto> nonStdDtoList = engineInfoDto.getMasterMaterialLovTempDtoList();
		 List<MasterMaterialLovTempDto> addList = new ArrayList<>();
		 List<MasterMaterialLovTempDto> deleteList = new ArrayList<>();
		 if(nonStdDtoList != null && nonStdDtoList.size() > 0) {
			 for(MasterMaterialLovTempDto temp : nonStdDtoList) {
				 if(temp.getId() != null && "true".equalsIgnoreCase(temp.getMaterialDeleted())) {
					 deleteList.add(temp);
				 }else if(temp.getId() == null) {
					 temp.setDocName(engineInfoDto.getDocName());
					 addList.add(temp);
				 }
			 }
			 List<MasterMaterialLovTemp> nonStdAddList =  entityBoMapper.map(addList, MasterMaterialLovTemp.class);
			 List<MasterMaterialLovTemp> nonStdDeleteList =  entityBoMapper.map(deleteList, MasterMaterialLovTemp.class);
			 nonStdTempMaterialsDAO.save(nonStdAddList);
			 for(MasterMaterialLovTemp temp : nonStdDeleteList) {
				 nonStdTempMaterialsDAO.delete(temp.getId());
			 }
		 }
		 nonStdDtoList = entityBoMapper.map(addList, MasterMaterialLovTempDto.class);
		 engineInfoDto.setMasterMaterialLovTempDtoList(nonStdDtoList);
	}
	

	/**
	 * @param engineInfoDto
	 */
	private void saveSubmitNonStdMaterials(EngineInfoDto engineInfoDto) {
		List<MasterMaterialLovTemp> addedList = new ArrayList<>();
		List<MasterMaterialLovTemp> nonStdList = nonStdTempMaterialsDAO.getAllUserCreatedMaterials(engineInfoDto.getDocName());
		List<MasterMaterialLovTempDto> nonStdDtoList = engineInfoDto.getMasterMaterialLovTempDtoList(); 
		Map<String,List<MasterMaterialLovTemp>> nonStdListMap = createNonStdDtoListMap(nonStdList);
		if(nonStdDtoList != null && nonStdDtoList.size() > 0) {
			 List<MasterMaterialLovTemp> nonStdTempList =  entityBoMapper.map(nonStdDtoList, MasterMaterialLovTemp.class);
			 if(nonStdTempList != null) {
				 for(MasterMaterialLovTemp temp : nonStdTempList) {
					 if("false".equalsIgnoreCase(temp.getMaterialDeleted())) {
						String partNumber = temp.getPartNumber();
						if(partNumber != null && nonStdListMap.get(partNumber) != null) {
							List<MasterMaterialLovTemp> tempList = nonStdListMap.get(partNumber);
							tempList.add(temp);
						}else if(partNumber != null && nonStdListMap.get(partNumber) == null) {
							List<MasterMaterialLovTemp> tempList = new ArrayList<>();
							tempList.add(temp);
							nonStdListMap.put(partNumber, tempList);
						}
					 }
				 }
			 }
		 }
		List<ModelEngineDto> modelEngineList = engineInfoDto.getModelEngineList();
			if(modelEngineList != null) {
			for(ModelEngineDto modelEngine : modelEngineList) {
				if("true".equalsIgnoreCase(modelEngine.getEngineChecked())) {
				List<EngineMaterialsDto> engineMaterialsList =  modelEngine.getEngineMaterialsList();
				if(engineMaterialsList != null) {
					for(EngineMaterialsDto engineMaterials : engineMaterialsList) {
						if(engineMaterials.getPartNumber() != null ) {
							List<MasterMaterialLovTemp> tempMaterialList = nonStdListMap.get(engineMaterials.getPartNumber());
							if(tempMaterialList != null) {
								for(MasterMaterialLovTemp tempMaterial : tempMaterialList) {
									if(tempMaterial.getEngine().equalsIgnoreCase(modelEngine.getEngine()) && tempMaterial.getModule() == null && "N".equalsIgnoreCase(tempMaterial.getNewRepair()) ) {
											addedList.add(tempMaterial);
									}
								}
							}
						}
					}
				}
				List<EngineMaterialRepairDto> engineMaterialRepairList = modelEngine.getEngineMaterialRepairList();
				if(engineMaterialRepairList != null) {
					for(EngineMaterialRepairDto engineMaterialRepair : engineMaterialRepairList) {
						if(engineMaterialRepair.getPartNumber() != null ) {
							List<MasterMaterialLovTemp> tempMaterialList = nonStdListMap.get(engineMaterialRepair.getPartNumber());
							if(tempMaterialList != null) {
								for(MasterMaterialLovTemp tempMaterial : tempMaterialList) {
									if(tempMaterial.getEngine().equalsIgnoreCase(modelEngine.getEngine()) && tempMaterial.getModule() == null && "R".equalsIgnoreCase(tempMaterial.getNewRepair())) {
										addedList.add(tempMaterial);
									}
								}
							}
						}
					}
				}
				
				List<ModulesDto> moduleList = modelEngine.getModuleList();
				if(moduleList != null) {
					for(ModulesDto modules : moduleList) {
						if("true".equalsIgnoreCase(modules.getModuleChecked())) {
						List<ModuleMaterialsDto> moduleMaterialsList = modules.getModuleMaterialsList();
						if(moduleMaterialsList != null) {
							for(ModuleMaterialsDto moduleMaterials : moduleMaterialsList) {
								if(moduleMaterials.getPartNumber() != null ) {
									List<MasterMaterialLovTemp> tempMaterialList = nonStdListMap.get(moduleMaterials.getPartNumber());
									if(tempMaterialList != null) {
										for(MasterMaterialLovTemp tempMaterial : tempMaterialList) {
											if(tempMaterial.getEngine().equalsIgnoreCase(modelEngine.getEngine()) && tempMaterial.getModule() != null  && tempMaterial.getModule().equalsIgnoreCase(modules.getModule()) && "N".equalsIgnoreCase(tempMaterial.getNewRepair())) {
												addedList.add(tempMaterial);
											}
										}
									}
								}
							}
						}
						List<ModuleMaterialRepairDto> moduleMaterialsRepairList = modules.getModuleMaterialsRepairList();
						if(moduleMaterialsRepairList != null) {
							for(ModuleMaterialRepairDto moduleMaterialRepair : moduleMaterialsRepairList) {
								if(moduleMaterialRepair.getPartNumber() != null ) {
									List<MasterMaterialLovTemp> tempMaterialList = nonStdListMap.get(moduleMaterialRepair.getPartNumber());
									if(tempMaterialList != null) {
										for(MasterMaterialLovTemp tempMaterial : tempMaterialList) {
											if(tempMaterial.getEngine().equalsIgnoreCase(modelEngine.getEngine()) && tempMaterial.getModule() != null  && tempMaterial.getModule().equalsIgnoreCase(modules.getModule()) && "R".equalsIgnoreCase(tempMaterial.getNewRepair())) {
												addedList.add(tempMaterial);
											}
										}
									}
								}
							}
						}
					}
				  }
				}
			}
			}	
			//handle direct submit by adding non standard materials
			engineInfoDto.setMasterMaterialLovTempDtoList(null);
			if(addedList.size() >0) {
				List<SowMasterMaterial> nonStdListTemp =  entityBoMapper.map(addedList, SowMasterMaterial.class);
				for(SowMasterMaterial temp : nonStdListTemp) {
					temp.setId(null);
					temp.setCreatedBy(engineInfoDto.getLastUpdatedBy());
					temp.setLastUpdatedBy(engineInfoDto.getLastUpdatedBy());
				}
				sowMasterMaterialDAO.save(nonStdListTemp);
			}
			if(nonStdList != null) {
				nonStdTempMaterialsDAO.delete(nonStdList);
			}
		}
	}
	
	/**
	 * @param nonStdList
	 * @return
	 */
	private Map<String, List<MasterMaterialLovTemp>> createNonStdDtoListMap(List<MasterMaterialLovTemp> nonStdList) {
		Map<String,List<MasterMaterialLovTemp>>  returnMap = new HashMap<>();
		if(nonStdList != null && nonStdList.size() > 0) {
			for(MasterMaterialLovTemp temp : nonStdList) {
				String partNumber = temp.getPartNumber();
				if(partNumber != null && returnMap.get(partNumber) != null) {
					List<MasterMaterialLovTemp> tempList = returnMap.get(partNumber);
					tempList.add(temp);
				}else if(partNumber != null && returnMap.get(partNumber) == null) {
					List<MasterMaterialLovTemp> tempList = new ArrayList<>();
					tempList.add(temp);
					returnMap.put(partNumber, tempList);
				}
			}
		}
		return returnMap;
	}

	/**
	 * @param sso
	 * @return
	 */
	public ResponseTemplateDto<UserProfilesDto> getUserInfo(Integer sso) {
		ResponseTemplateDto<UserProfilesDto> response = new ResponseTemplateDto<>();
		try{
			List<UserProfilesDto> profileList = userProfileDAO.getUserInfo(sso);
			UserProfilesDto profile = profileList != null &&  profileList.size() >0  ?profileList.get(0) :null;
			if(profile != null) {
				List<UserSubRoleDto> userSubRoleList = userProfileDAO.getUserSubRole(sso);
				setSubRolesInProfile(profile, userSubRoleList);
			}
			response.setData(profile);
			response.setSuccess(true);		
		} catch (Exception e) {
			LOGGER.error("Error while getting getUserInfo", e);
			response.setStatusMsg("Error while getting getUserInfo");
			response.setSuccess(false);
		}			
		return response;
		
	}
	
	/**
	 * @param profile
	 * @param userSubRoleDtoList
	 */
	private void setSubRolesInProfile(UserProfilesDto profile, List<UserSubRoleDto> userSubRoleDtoList) {
		if(profile != null && userSubRoleDtoList != null) {
			List<UserRolesDto> rolesList = profile.getRole();
			for(UserRolesDto userRolesDto : rolesList) {
				for(UserSubRoleDto userSubRoleDto : userSubRoleDtoList) {
					if(userRolesDto.getUserRole().equalsIgnoreCase(userSubRoleDto.getUserRole())) {
						if(userRolesDto.getUserSubRole()!= null) {
							List<UserSubRoleDto> temp = userRolesDto.getUserSubRole();
							temp.add(userSubRoleDto);
						}else{
							List<UserSubRoleDto> temp = new ArrayList<>();
							temp.add(userSubRoleDto);
							userRolesDto.setUserSubRole(temp);
						}
					}
				}
			}
		}
		
	}
	
	private void handleNonStdMaterial(String docName, EngineInfoDto engineInfoDto, boolean newSow) {
		List<MasterMaterialLovTemp> nonStdList = nonStdTempMaterialsDAO.getAllUserCreatedMaterials(docName);
		List<MasterMaterialLovTempDto> nonStdDtoList = entityBoMapper.map(nonStdList, MasterMaterialLovTempDto.class);
		if(!newSow) {
			engineInfoDto.setMasterMaterialLovTempDtoList(nonStdDtoList);
		}else{
			if(nonStdList != null) {
				for(MasterMaterialLovTempDto temp : nonStdDtoList) {
					temp.setId(null);
				}
			}
			engineInfoDto.setMasterMaterialLovTempDtoList(nonStdDtoList);
		}
	}
	
	private void populateDocName(EngineInfoDto engineInfoDto, String maxDocName) {
		ProductLov productLov = sowMasterMaterialDAO.getProductDetails(engineInfoDto.getProduct());
		String prefix = productLov.getPrefixCounter()!=null ? productLov.getPrefixCounter() : SOW;
		if(maxDocName == null) {
			engineInfoDto.setDocName(prefix+"001");
		}else{
			engineInfoDto.setDocName(getNextDocName(maxDocName,engineInfoDto.getProduct()));
		}
	}
	
}
