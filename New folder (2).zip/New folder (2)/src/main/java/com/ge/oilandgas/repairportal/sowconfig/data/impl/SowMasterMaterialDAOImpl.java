package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.oilandgas.repairportal.sowconfig.data.SowMasterMaterialDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.SowMasterMaterialRepository;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineModelLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.OpptyTypeLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.ProductLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.ProposalTypeLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.SowMasterMaterial;

@Component
public class SowMasterMaterialDAOImpl extends GenericCrudDAOImpl<SowMasterMaterial, Long> implements SowMasterMaterialDAO {
	
	@Autowired
	private SowMasterMaterialRepository sowMasterMaterialRepository;
	
    public SowMasterMaterialDAOImpl(SowMasterMaterialRepository sowMasterMaterialRepository) {
        this.sowMasterMaterialRepository = sowMasterMaterialRepository;
    }
	  public SowMasterMaterialDAOImpl() {
		super();
	}

    @SuppressWarnings("unchecked")
	public SowMasterMaterialRepository getRepository() {
        return sowMasterMaterialRepository;
    }

	@Override
	public List<SowMasterMaterial> findMaterialByEngine(String product, String model, String engine, String newRepair) {
		return sowMasterMaterialRepository.findMaterialByEngine(product,model,engine, newRepair);
	}

	@Override
	public List<SowMasterMaterial> findMaterialByModule(String product, String model,String engine,String module,String newRepair) {
		return sowMasterMaterialRepository.findMaterialByModule(product, model, engine, module, newRepair);
	}
	@Override
	public List<SowMasterMaterial> getMaterialByModuleList(String product, String model, String engine, String newRepair) {
		return sowMasterMaterialRepository.getMaterialByModuleList(product, model, engine, newRepair);
	}
	@Override
	public List<EngineLov> getEngineLovList(String product) {
		return sowMasterMaterialRepository.getEngineLovList(product);
	}
	@Override
	public List<OpptyTypeLov> getOpptyTypeList() {
		return sowMasterMaterialRepository.getOpptyTypeList();
	}
	@Override
	public List<ProposalTypeLov> getProposalTypeList() {
		return sowMasterMaterialRepository.getProposalTypeList();
	}
	@Override
	public List<SowMasterMaterial> getGGTestModuleMaterialList(String product, String model, String engine,	String priceCategory) {
		return sowMasterMaterialRepository.getGGTestModuleMaterialList(product, model, engine, priceCategory);
	}
	
	@Override
	public List<SowMasterMaterial> getGGTestEngineMaterialList(String product, String model, String engine,	String priceCategory) {
		return sowMasterMaterialRepository.getGGTestEngineMaterialList(product, model, engine, priceCategory);
	}
	
	@Override
	public String getPlcModelCode(String product, String model) {
		return sowMasterMaterialRepository.getPlcModelCode(product, model);
	}
	@Override
	public List<EngineModelLov> getAllEngineModelLov(String product) {
		return sowMasterMaterialRepository.getAllEngineModelLov(product);
	}
	@Override
	public List<SowMasterMaterial> getAllMaterialByModuleList(String product, String model, String engine) {
		return sowMasterMaterialRepository.getAllMaterialByModuleList(product,model,engine);
	}
	@Override
	public List<SowMasterMaterial> getAllMaterialByEngine(String product, String model, String engine) {
		return sowMasterMaterialRepository.getAllMaterialByEngine(product,model,engine);
	}
	@Override
	public List<SowMasterMaterial> getAllMaterialByModule(String product, String model, String engine, String module) {
		return sowMasterMaterialRepository.getAllMaterialByModule(product,model,engine,module);
	}
	@Override
	public ProductLov getProductDetails(String productCode) {
		return sowMasterMaterialRepository.getProductDetails(productCode);
	}
	@Override
	public List<ProductLov> getProductList() {
		return sowMasterMaterialRepository.getProductList();
	}
	
	
}
