package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "ong_orp_sow_set")
public class EngineInfoSowSet extends GenericEntity<Long>{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4357237745629981466L;
	@Id
	@Column(name="sow_id")
	private Long id;
	
	@Column(name="sow_set_code")
	private String sowSetCode;
	
	@Column(name="sow_name")
	private String sowName;
	
	@Column(name="mandatory_flag")
	private String mandatoryFlag;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSowSetCode() {
		return sowSetCode;
	}

	public void setSowSetCode(String sowSetCode) {
		this.sowSetCode = sowSetCode;
	}

	public String getSowName() {
		return sowName;
	}

	public void setSowName(String sowName) {
		this.sowName = sowName;
	}

	public String getMandatoryFlag() {
		return mandatoryFlag;
	}

	public void setMandatoryFlag(String mandatoryFlag) {
		this.mandatoryFlag = mandatoryFlag;
	}
	
	
}
