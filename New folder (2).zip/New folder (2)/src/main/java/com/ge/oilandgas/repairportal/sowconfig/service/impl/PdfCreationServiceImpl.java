package com.ge.oilandgas.repairportal.sowconfig.service.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineInfoDto;
import com.ge.oilandgas.repairportal.sowconfig.manager.PdfCreationManager;
import com.ge.oilandgas.repairportal.sowconfig.service.api.PdfCreationService;

@RequestMapping("/service/sowconfigurator")
@RestController
public class PdfCreationServiceImpl implements PdfCreationService {
	private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	PdfCreationManager pdfCreationManager;
	
	@RequestMapping(value = "/createSowTechnicalDetailsPdf/{proposalType}",  method= RequestMethod.POST, consumes = "application/json" )
	public void createSowTechnicalDetailsPdf(@RequestBody Map<String, Object> technicalDetailsPdfInput, @PathVariable("proposalType")  String proposalType , HttpServletResponse response) {
		LOGGER.debug("Started the method createSowTechnicalDetailsPdf in the class PdfCreationServiceImpl.");
		try {
			byte[] sowTechnicalDetails = pdfCreationManager.createSowTechnicalDetailsPdf(technicalDetailsPdfInput,proposalType);
			InputStream is = new ByteArrayInputStream(sowTechnicalDetails);
			response.setHeader("Content-Disposition", "attachment; filename=" + "SowTechnicalDetails.pdf");
			response.setContentType("application/pdf");
			IOUtils.copy(is, response.getOutputStream());
			response.flushBuffer();
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.debug("Completed the method createSowTechnicalDetailsPdf in the class PdfCreationServiceImpl.");
	}


	@RequestMapping(value = "/createSummaryByModuleDetailsPdf/{product}",  method= RequestMethod.POST, consumes = "application/json" )
	public void createSummaryByModuleDetailsPdf(@RequestBody Map<String, Object> summaryByModuleDetails,HttpServletResponse response,@PathVariable("product")  String product) {
		LOGGER.debug("Started the method createSummaryByModuleDetailsPdf in the class PdfCreationServiceImpl.");
		try {
			byte[] moduleDetails = pdfCreationManager.createSummaryByModuleDetailsPdf(summaryByModuleDetails,product);
			InputStream is = new ByteArrayInputStream(moduleDetails);
			response.setHeader("Content-Disposition", "attachment; filename=" + "SummaryByModuleDetails.pdf");
			response.setContentType("application/pdf");
			IOUtils.copy(is, response.getOutputStream());
			response.flushBuffer();
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.debug("Completed the method createSummaryByModuleDetailsPdf in the class PdfCreationServiceImpl.");
	}


	@RequestMapping(value = "/createSummaryByModuleDetailsPdfNew",  method= RequestMethod.POST, consumes = "application/json" )
	public void createSummaryByModuleDetailsPdfNew(@RequestBody EngineInfoDto engineInfoDto, HttpServletResponse response) {
		LOGGER.debug("Started the method createSummaryByModuleDetailsPdf in the class PdfCreationServiceImpl.");
		try {
			byte[] moduleDetails = pdfCreationManager.createSummaryByModuleDetailsPdf(engineInfoDto);
			InputStream is = new ByteArrayInputStream(moduleDetails);
			response.setHeader("Content-Disposition", "attachment; filename=" + "SummaryByModuleDetails.pdf");
			response.setContentType("application/pdf");
			IOUtils.copy(is, response.getOutputStream());
			response.flushBuffer();
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
		}
		LOGGER.debug("Completed the method createSummaryByModuleDetailsPdf in the class PdfCreationServiceImpl.");
		
	}
	
	
		
}
