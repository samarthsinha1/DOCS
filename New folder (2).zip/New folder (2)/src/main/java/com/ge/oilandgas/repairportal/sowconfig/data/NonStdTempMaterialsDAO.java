package com.ge.oilandgas.repairportal.sowconfig.data;

import java.util.List;

import com.ge.oilandgas.repairportal.sowconfig.entity.MasterMaterialLovTemp;

public interface NonStdTempMaterialsDAO extends GenericDAO<MasterMaterialLovTemp, Long>{

	List<MasterMaterialLovTemp> getAllUserCreatedMaterials(String docName);

	List<MasterMaterialLovTemp> getAllUserCreatedEngineMaterials(String docName, String engine);

	List<MasterMaterialLovTemp> getAllUserCreatedModuleMaterials(String docName, String engine,String module);

}
