package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class ServiceBulletinMasterDto extends AuditDataDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    private StdSbLovDto stdSbLovDto;
	private List<ServiceBulletinNewMaterialsDto> sbNewMaterialList;
	private List<ServiceBulletinOperationsDto> sbOperationsList;
	private List<ServiceBulletinRepairAndServiceDto> sbRepairAndServiceList;
	
	public StdSbLovDto getStdSbLovDto() {
		return stdSbLovDto;
	}
	public void setStdSbLovDto(StdSbLovDto stdSbLovDto) {
		this.stdSbLovDto = stdSbLovDto;
	}
	public List<ServiceBulletinNewMaterialsDto> getSbNewMaterialList() {
		return sbNewMaterialList;
	}
	public void setSbNewMaterialList(List<ServiceBulletinNewMaterialsDto> sbNewMaterialList) {
		this.sbNewMaterialList = sbNewMaterialList;
	}
	public List<ServiceBulletinOperationsDto> getSbOperationsList() {
		return sbOperationsList;
	}
	public void setSbOperationsList(List<ServiceBulletinOperationsDto> sbOperationsList) {
		this.sbOperationsList = sbOperationsList;
	}
	public List<ServiceBulletinRepairAndServiceDto> getSbRepairAndServiceList() {
		return sbRepairAndServiceList;
	}
	public void setSbRepairAndServiceList(List<ServiceBulletinRepairAndServiceDto> sbRepairAndServiceList) {
		this.sbRepairAndServiceList = sbRepairAndServiceList;
	}
	@Override
	public String toString() {
		return "ServiceBulletinMasterDto [stdSbLovDto=" + stdSbLovDto + ", sbNewMaterialList=" + sbNewMaterialList
				+ ", sbOperationsList=" + sbOperationsList + ", sbRepairAndServiceList=" + sbRepairAndServiceList + "]";
	}

	
}
