package com.ge.oilandgas.repairportal.sowconfig.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ge.oilandgas.repairportal.sowconfig.bo.ReportFieldsDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;
import com.ge.oilandgas.repairportal.sowconfig.manager.ReportFieldsManager;
import com.ge.oilandgas.repairportal.sowconfig.service.api.ReportFieldsService;

@RequestMapping("/service/sowconfigurator")
@RestController
public class ReportFieldsServiceImpl implements ReportFieldsService{
	
	@Autowired
	ReportFieldsManager reportFieldsManager;


	@RequestMapping(value="/getReportFieldsByEngineInfoId/{engineInfoId}", method= RequestMethod.GET, produces = "application/json" )
	public ResponseTemplateDto<ReportFieldsDto> getReportFieldsByEngineInfoId(@PathVariable("engineInfoId") Long engineInfoId) {
		return reportFieldsManager.getReportFieldsByEngineInfoId(engineInfoId);
	}
	
	@RequestMapping(value="/deleteReportFields/{engineInfoId}", method= RequestMethod.GET,produces = "application/json")
	public ResponseTemplateDto<ReportFieldsDto> deleteReportFieldById(@PathVariable("engineInfoId") Long engineInfoId) {
		return reportFieldsManager.deleteReportFields(engineInfoId);
	}

	@RequestMapping(value="/saveUpdateReportFields", method= RequestMethod.POST, produces = "application/json", consumes = "application/json" )
	public ResponseTemplateDto<ReportFieldsDto> saveUpdateReportFields(@RequestBody ReportFieldsDto reportFieldsDto) {
		return reportFieldsManager.saveUpdateReportFields(reportFieldsDto);
	}

}
