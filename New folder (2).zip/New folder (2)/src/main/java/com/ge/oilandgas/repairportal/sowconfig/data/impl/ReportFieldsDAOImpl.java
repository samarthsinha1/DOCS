package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.oilandgas.repairportal.sowconfig.data.ReportFieldsDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.ReportFieldsRepository;
import com.ge.oilandgas.repairportal.sowconfig.entity.ReportFields;


@Component
public class ReportFieldsDAOImpl extends GenericCrudDAOImpl<ReportFields, Long> implements ReportFieldsDAO {
	
	@Autowired
	private ReportFieldsRepository reportFieldsRepository;
	
	  public ReportFieldsDAOImpl(ReportFieldsRepository reportFieldsRepository) {
	        this.reportFieldsRepository = reportFieldsRepository;
	    }
	  
	  public ReportFieldsDAOImpl() {
		super();
	}

	  @SuppressWarnings("unchecked")
	 public ReportFieldsRepository getRepository() {
        return reportFieldsRepository;
    }

	@Override
	public List<ReportFields> findReportFieldsByEngineInfoId(Long engineInfoId) {
		return reportFieldsRepository.findReportFieldsByEngineInfoId(engineInfoId);
	}

	
}
