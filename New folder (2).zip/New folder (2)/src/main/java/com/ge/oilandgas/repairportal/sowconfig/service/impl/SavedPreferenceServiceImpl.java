package com.ge.oilandgas.repairportal.sowconfig.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.SavedPreferenceDto;
import com.ge.oilandgas.repairportal.sowconfig.manager.SavedPreferenceManager;
import com.ge.oilandgas.repairportal.sowconfig.service.api.SavedPreferenceService;

@RequestMapping("/service/sowconfigurator")
@RestController
public class SavedPreferenceServiceImpl implements SavedPreferenceService {

	@Autowired
	SavedPreferenceManager savedPreferenceManager;

	
	@RequestMapping(value="/getSavedPreferenceDetailsBySsoId/{ssoId}", method= RequestMethod.GET,produces = "application/json")
	public ResponseTemplateDto<SavedPreferenceDto> getDetailsBySsoId(@PathVariable("ssoId")Long ssoId) {
		return savedPreferenceManager.getDetailsBySsoId(ssoId);
	}


	@RequestMapping(value="/saveUpdateSavedPreferenceDetails", method= RequestMethod.POST, produces = "application/json", consumes = "application/json" )
	public ResponseTemplateDto<SavedPreferenceDto> saveUpdateDetails(@RequestBody SavedPreferenceDto savedPreferenceDto) {
			return savedPreferenceManager.saveUpdateDetails(savedPreferenceDto);
	}
	


}
