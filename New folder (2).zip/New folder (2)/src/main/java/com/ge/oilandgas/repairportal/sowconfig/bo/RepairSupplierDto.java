package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

public class RepairSupplierDto implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String supplier;
	private String supplierType;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	
	public String getSupplier() {
		return supplier;
	}
	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public String getSupplierType() {
		return supplierType;
	}
	public void setSupplierType(String supplierType) {
		this.supplierType = supplierType;
	}
	
	
}
