package com.ge.oilandgas.repairportal.sowconfig.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ServiceBulletinMasterDto;
import com.ge.oilandgas.repairportal.sowconfig.manager.ServiceBulletinAdminManager;
import com.ge.oilandgas.repairportal.sowconfig.service.api.ServiceBulletinAdminService;

@RequestMapping("/service/sowconfigurator")
@RestController
public class ServiceBulletinAdminServiceImpl implements ServiceBulletinAdminService {

	@Autowired
	ServiceBulletinAdminManager serviceBulletinAdminManager;
	
	//add endpoint
	@RequestMapping(value="/saveNewServiceBulletin", method= RequestMethod.POST, produces = "application/json", consumes = "application/json" )
	public ResponseTemplateDto<ServiceBulletinMasterDto> saveNewServiceBulletin(@RequestBody ServiceBulletinMasterDto serviceBulletinsMasterDto) {
		return serviceBulletinAdminManager.saveNewServiceBulletin(serviceBulletinsMasterDto);
	}

}
