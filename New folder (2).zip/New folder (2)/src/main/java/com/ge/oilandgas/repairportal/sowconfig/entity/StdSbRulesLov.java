package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "ong_sowcfg_std_sb_rules_lov")
public class StdSbRulesLov extends GenericEntity<Long>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7223893602345504215L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="std_sb_rules_id")
	private Long id;
	
	@Column(name="sow_sb_description")
	private String sbDescription;
	
	@Column(name="sow_name")
	private String sowName;
	
	@Column(name="std_sb_rule_color")
	private String sbRuleColor;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	public String getSbDescription() {
		return sbDescription;
	}

	public void setSbDescription(String sbDescription) {
		this.sbDescription = sbDescription;
	}

	public String getSowName() {
		return sowName;
	}

	public void setSowName(String sowName) {
		this.sowName = sowName;
	}

	public String getSbRuleColor() {
		return sbRuleColor;
	}

	public void setSbRuleColor(String sbRuleColor) {
		this.sbRuleColor = sbRuleColor;
	}


}
