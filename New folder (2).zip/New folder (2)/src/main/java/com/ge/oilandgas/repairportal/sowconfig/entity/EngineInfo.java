package com.ge.oilandgas.repairportal.sowconfig.entity;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



@Entity
@Table(name= "ong_sowcfg_trx_engine_model_info")

public class EngineInfo extends GenericEntity<Long>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 *
	 */
	
	@Id
	@SequenceGenerator(name="SEQ_ENGINE_INFO", sequenceName="ong_sowcfg_trx_engine_model_info_sequence_id")
	@GeneratedValue(generator="SEQ_ENGINE_INFO", strategy=GenerationType.SEQUENCE)
	@Column(name="INFO_SEQUENCE_ID")
	private Long id;
	
	@Column(name="doc_type")
	private String docType;
	
	@Column(name="doc_name")
	private String docName;
	
	@Column(name="SCOPE_TYPE")
	private String scopeType;
	
	@Column(name="std_doc_rev")
	private Float stdDocRev;
	
	@Column(name="sow_doc_rev")
	private Float sowDocRev;
	
	@Column(name="MODEL")
	private String model;
	
	@Column(name="component_sequence_id")
	private Long componentSequenceId; 
		
	@Column(name="PRODUCT")
	private String product;
	
	@Column(name="engine_date")
	private Date engineDate;
		
	@Column(name="CUSTOMER_NAME")
	private String customerName;
	
	@Column(name="SERIAL_NUMBER")
	private String serialNumber;
	
	@Column(name="DEPOT_REPAIR_SHOP")
	private String depotRepairShop;
	
	@Column(name="labor_hour_unit_cost")
	private float laborHourUnitCost;
	
	@Column(name="LABOR_HOUR_UNIT_PRICE")
	private float laborHourUnitPrice;
	
	@Column(name="status")
	private String status;
	
	@Column(name="sb_file_name")
	private String sbFileName;
	
	@Column(name="std_doc_name")
	private String stdDocName;
	
	@Column(name="admin_uploaded")
	private String adminUploaded;
	
	@Column(name="sow_description")
	private String sowDescription;
	
	@Column(name="oppty_id")
	private String opptyId;
	
	@Column(name="oppty_rev")
	private float opptyRev;
	
	@Column(name="oppty_type")
	private String opptyType;
	
	@Column(name="proposal_type")
	private String proposalType;
	
	@Column(name="proposal_date")
	private Date proposalDate;
	
	@Column(name="sow_selection")
	private String sowSelection;
	
	@OneToMany(cascade = CascadeType.ALL,
			fetch = FetchType.EAGER, orphanRemoval=true)
	@JoinColumn(name="info_sequence_id",referencedColumnName="info_sequence_id", nullable=false)
	@OrderBy
	private List<ServiceBulletins> serviceBulletinList = new LinkedList<>();
	
	@OneToMany(cascade = CascadeType.ALL,
			fetch = FetchType.EAGER, orphanRemoval=true)
	@JoinColumn(name="info_sequence_id",referencedColumnName="info_sequence_id", nullable=false)
	@OrderBy
	private List<ModelEngine> modelEngineList = new LinkedList<>();
	
	

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public String getScopeType() {
		return scopeType;
	}

	public void setScopeType(String scopeType) {
		this.scopeType = scopeType;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public Date getEngineDate() {
		return engineDate;
	}

	public void setEngineDate(Date engineDate) {
		this.engineDate = engineDate;
	}

	
	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getDepotRepairShop() {
		return depotRepairShop;
	}

	public void setDepotRepairShop(String depotRepairShop) {
		this.depotRepairShop = depotRepairShop;
	}

	public List<ServiceBulletins> getServiceBulletinList() {
		return serviceBulletinList;
	}

	public void setServiceBulletinList(List<ServiceBulletins> serviceBulletinList) {
		this.serviceBulletinList = serviceBulletinList;
	}

	public List<ModelEngine> getModelEngineList() {
		return modelEngineList;
	}

	public void setModelEngineList(List<ModelEngine> modelEngineList) {
		this.modelEngineList = modelEngineList;
	}

	public Float getStdDocRev() {
		return stdDocRev;
	}

	public void setStdDocRev(Float stdDocRev) {
		this.stdDocRev = stdDocRev;
	}

	public Float getSowDocRev() {
		return sowDocRev;
	}

	public void setSowDocRev(Float sowDocRev) {
		this.sowDocRev = sowDocRev;
	}

	public float getLaborHourUnitCost() {
		return laborHourUnitCost;
	}

	public void setLaborHourUnitCost(float laborHourUnitCost) {
		this.laborHourUnitCost = laborHourUnitCost;
	}

	public float getLaborHourUnitPrice() {
		return laborHourUnitPrice;
	}

	public void setLaborHourUnitPrice(float laborHourUnitPrice) {
		this.laborHourUnitPrice = laborHourUnitPrice;
	}

	public Long getComponentSequenceId() {
		return componentSequenceId;
	}

	public void setComponentSequenceId(Long componentSequenceId) {
		this.componentSequenceId = componentSequenceId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSbFileName() {
		return sbFileName;
	}

	public void setSbFileName(String sbFileName) {
		this.sbFileName = sbFileName;
	}

	public String getStdDocName() {
		return stdDocName;
	}

	public void setStdDocName(String stdDocName) {
		this.stdDocName = stdDocName;
	}

	public String getAdminUploaded() {
		return adminUploaded;
	}

	public void setAdminUploaded(String adminUploaded) {
		this.adminUploaded = adminUploaded;
	}

	public String getSowDescription() {
		return sowDescription;
	}

	public void setSowDescription(String sowDescription) {
		this.sowDescription = sowDescription;
	}

	public String getOpptyId() {
		return opptyId;
	}

	public void setOpptyId(String opptyId) {
		this.opptyId = opptyId;
	}

	public float getOpptyRev() {
		return opptyRev;
	}

	public void setOpptyRev(float opptyRev) {
		this.opptyRev = opptyRev;
	}

	public String getOpptyType() {
		return opptyType;
	}

	public void setOpptyType(String opptyType) {
		this.opptyType = opptyType;
	}

	public String getProposalType() {
		return proposalType;
	}

	public void setProposalType(String proposalType) {
		this.proposalType = proposalType;
	}

	public Date getProposalDate() {
		return proposalDate;
	}

	public void setProposalDate(Date proposalDate) {
		this.proposalDate = proposalDate;
	}

	public String getSowSelection() {
		return sowSelection;
	}

	public void setSowSelection(String sowSelection) {
		this.sowSelection = sowSelection;
	}
	
	
}
