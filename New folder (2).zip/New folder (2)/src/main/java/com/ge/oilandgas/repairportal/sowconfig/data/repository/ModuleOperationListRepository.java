package com.ge.oilandgas.repairportal.sowconfig.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ge.oilandgas.repairportal.sowconfig.entity.ModuleOperationList;

@Repository
public interface ModuleOperationListRepository extends GenericCrudRepository<ModuleOperationList, Long>{

	@Query("SELECT s from ModuleOperationList s where s.engine= ?1 and s.module= ?2 and s.plcProductType = ?3")  
	List<ModuleOperationList> findModuleOperationList(String engine,String module,String product);
	
	@Query("SELECT max(s.numOperation) from ModuleOperationList s where s.engine=?1 and s.module=?2 and s.plcProductType = ?3")
	Long getLatestNumOperation(String engine,String module,String product);

	@Query("SELECT s.numOperation,s.engine from ModuleOperationList s where s.engine=?1 and s.module=?2 and s.plcProductType = ?3")
	Object[] getNumOperation(String engine,String module,String product);

	@Query("SELECT s from ModuleOperationList s where s.plcProductType = ?1 order by s.numOperation")  
	List<ModuleOperationList> findAllProductOperations(String product);
	
}
