package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.ge.oilandgas.repairportal.sowconfig.data.RepairSupplierDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.RepairSupplierRepository;
import com.ge.oilandgas.repairportal.sowconfig.entity.RepairSupplier;

@Component
public class RepairSupplierDAOImpl implements RepairSupplierDAO {

	
	private static final Logger LOGGER = LoggerFactory
			.getLogger(RepairSupplierDAOImpl.class);
	
	@Autowired
	private RepairSupplierRepository repairSupplierRepository;
	
	  public RepairSupplierDAOImpl(RepairSupplierRepository repairSupplierRepository) {
	        this.repairSupplierRepository = repairSupplierRepository;
	    }

	  public RepairSupplierDAOImpl() {
	       super();
	    }
	  
	   public RepairSupplierRepository getRepository() {
	        return repairSupplierRepository;
	    }
	
	@Override
	public List<RepairSupplier> findAllRS() {
		//LOGGER.debug("Class::Repair_supplierDAOImpl, Method::findAllRS::model"+engine_model);
		LOGGER.debug("Class::Repair_supplierDAOImpl, Method::findAllRS::repairSupplierRepository.findAllRS()"+repairSupplierRepository.findAllRS());
		return repairSupplierRepository.findAllRS();
	}

	

	}