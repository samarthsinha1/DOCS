package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.oilandgas.repairportal.sowconfig.data.ModuleOperationListDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.ModuleOperationListRepository;
import com.ge.oilandgas.repairportal.sowconfig.entity.ModuleOperationList;

@Component
public class ModuleOperationListDAOImpl  extends GenericCrudDAOImpl<ModuleOperationList, Long> implements ModuleOperationListDAO{
		
	@Autowired
	private ModuleOperationListRepository moduleOperationListRepository;
	
	  public ModuleOperationListDAOImpl(ModuleOperationListRepository moduleOperationListRepository) {
	        this.moduleOperationListRepository = moduleOperationListRepository;
	    }

	  public ModuleOperationListDAOImpl() {
	       super();
	    }

	  @SuppressWarnings("unchecked")
		
	    public ModuleOperationListRepository getRepository() {
	        return moduleOperationListRepository;
	    }


	@Override
	public List<ModuleOperationList> findModuleOperationList(String engine,String module,String product) {		
		return moduleOperationListRepository.findModuleOperationList(engine,module,product);
	}
	
	public Long getLatestNumOperation(String engine,String module,String product){
		return moduleOperationListRepository.getLatestNumOperation(engine,module,product);
	}

	@Override
	public Object[] getNumOperation(String engine,String module,String product) {
		return moduleOperationListRepository.getNumOperation(engine,module,product);
	}

	@Override
	public List<ModuleOperationList> findAllProductOperations(String product) {
		return moduleOperationListRepository.findAllProductOperations(product);
	}


}
