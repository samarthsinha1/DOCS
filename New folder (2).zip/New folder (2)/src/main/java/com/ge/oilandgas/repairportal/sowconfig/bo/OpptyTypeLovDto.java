package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

public class OpptyTypeLovDto extends AuditDataDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3199879715627158419L;
	
	private Long id;
	
	private String opptyTypeName;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOpptyTypeName() {
		return opptyTypeName;
	}

	public void setOpptyTypeName(String opptyTypeName) {
		this.opptyTypeName = opptyTypeName;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	

}
