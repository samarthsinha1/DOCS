package com.ge.oilandgas.repairportal.sowconfig.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ge.oilandgas.repairportal.sowconfig.bo.EngineInfoDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineInfoForAllSowDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineInfoSowSetDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ListPriceDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.PartNumberListDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseStatusDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.UserProfilesDto;
import com.ge.oilandgas.repairportal.sowconfig.data.UserProfileDAO;
import com.ge.oilandgas.repairportal.sowconfig.manager.SowConfigManager;
import com.ge.oilandgas.repairportal.sowconfig.service.api.EngineInfoService;

@RequestMapping("/service/sowconfigurator")
@RestController
public class EngineInfoServiceImpl implements EngineInfoService{

	@Autowired
	SowConfigManager sowConfigManager;
    @Autowired
	UserProfileDAO userProfileDAO;  

	
		
	@Override
	@RequestMapping(value="/getEngineInfo/{componentSequenceId}/{model}/{product}", method= RequestMethod.GET, produces = "application/json")
	public ResponseTemplateDto<EngineInfoDto> getEngineInfo(@PathVariable("componentSequenceId") Long componentSequenceId,@PathVariable("model") String model,@PathVariable("product") String product) {
		return sowConfigManager.getEngineInfo(componentSequenceId,model, product);
	}
	@RequestMapping(value="/getEngineInfoDetails/{componentSequenceId}/{model}/{product}/{version}", method= RequestMethod.GET, produces = "application/json")
	public ResponseTemplateDto<EngineInfoDto> getEngineInfoDetails(@PathVariable("componentSequenceId") Long componentSequenceId,@PathVariable("model") String model, @PathVariable("product") String product,  @PathVariable("version") float version) {
		return sowConfigManager.getEngineInfoDetails(componentSequenceId,model, product, version);
	}

	@RequestMapping(value="/getEngineInfoDetailsFromMaster/{docType}/{docName}/{model}/{product}/{eventType}", method= RequestMethod.GET, produces = "application/json")
	public ResponseTemplateDto<EngineInfoDto> getEngineInfoDetailsFromMaster(@PathVariable("docType") String docType, @PathVariable("docName") String docName, @PathVariable("model") String model, @PathVariable("product") String product, @PathVariable("eventType") String eventType) {
		return sowConfigManager.getEngineInfoDetailsFromMaster(docType,docName,model, product,eventType);
	}

	@RequestMapping(value="/getDocNameList/{docType}/{model}/{product}", method= RequestMethod.GET, produces = "application/json")
	public ResponseTemplateDto<List<String>> getDocNameListFromMaster(@PathVariable("docType") String docType,@PathVariable("model") String model,@PathVariable("product") String product) {
		return sowConfigManager.getDocNameListFromMaster(docType,model, product);
	}

	@Override
	@RequestMapping(value="/saveEngineInfo", method= RequestMethod.POST, produces = "application/json", consumes = "application/json" )
	public ResponseTemplateDto<EngineInfoDto> saveEngineInfo(@RequestBody EngineInfoDto engineInfoDto) {
		return sowConfigManager.saveEngineInfo(engineInfoDto);
	}
	@Override
	@RequestMapping(value="/submitEngineInfo", method= RequestMethod.POST, produces = "application/json", consumes = "application/json" )
	public ResponseTemplateDto<EngineInfoDto> submitEngineInfo(@RequestBody EngineInfoDto engineInfoDto) {
		return sowConfigManager.submitEngineInfo(engineInfoDto);
	}
	@Override
	@RequestMapping(value="/getAllEngineInfo", method= RequestMethod.GET, produces = "application/json")
	public ResponseTemplateDto<List<EngineInfoForAllSowDto>> getAllEngineInfo() {
		return sowConfigManager.getAllEngineInfo();
	}
	@Override
	@RequestMapping(value="/getEngineInfoById/{id}", method= RequestMethod.GET, produces = "application/json")
	public ResponseTemplateDto<EngineInfoDto> getEngineInfoById(@PathVariable("id") Long id) {
		return sowConfigManager.getEngineInfoById(id);
	}
	@Override
	@RequestMapping(value="/deleteEngineInfo/{id}/{docName}", method= RequestMethod.DELETE)
	public ResponseStatusDto deleteEngineInfo(@PathVariable("id") Long id, @PathVariable("docName") String docName) {
		return sowConfigManager.deleteEngineInfo(id,docName);
	}
	@Override
	@RequestMapping(value="/copyEngineInfo/{id}", method= RequestMethod.POST, produces = "application/json" )
	public ResponseTemplateDto<EngineInfoDto> copyEngineInfo(@PathVariable("id") Long id) {
		return sowConfigManager.copyEngineInfo(id);
	}
	@RequestMapping(value="/updateEngineInfo/{id}", method= RequestMethod.POST, produces = "application/json" )
	public ResponseTemplateDto<EngineInfoDto> updateEngineInfo(@PathVariable("id") Long id) {
		return sowConfigManager.updateEngineInfo(id);
	}
	@RequestMapping(value="/getAllSowSet", method= RequestMethod.GET, produces = "application/json")
	public ResponseTemplateDto<List<EngineInfoSowSetDto>> getAllSowSet() {
		return sowConfigManager.getAllSowSet();
	}
	@RequestMapping(value="/getAllNewPriceList", method= RequestMethod.POST,produces = "application/json", consumes = "application/json")
	public ResponseTemplateDto<List<ListPriceDto>> getAllNewPriceList(@RequestBody PartNumberListDto partNumerList) {
		return sowConfigManager.getAllNewPriceList(partNumerList.getPartNumbers());
	}
	@RequestMapping(value="/getAllRepairPriceList",method= RequestMethod.POST,produces = "application/json", consumes = "application/json")
	public ResponseTemplateDto<List<ListPriceDto>> getAllRepairPriceList(@RequestBody PartNumberListDto partNumerList) {
		return sowConfigManager.getAllRepairPriceList(partNumerList.getPartNumbers());
	}
	@RequestMapping(value="getUserInfo/{sso}", method= RequestMethod.GET, produces = "application/json" )
	public ResponseTemplateDto<UserProfilesDto> getUserInfo(@PathVariable("sso")Integer sso) {
		return sowConfigManager.getUserInfo(sso);
	}
	

}
