package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name= "ong_sowcfg_std_module_operation_hrs")
public class ModuleOperationHrsLov extends GenericEntity<Long>{
	/**
	 * 
	 */
	private static final long serialVersionUID = 6697953964848233521L;

	@Id
	@SequenceGenerator(name="SEQ_MODULE_OPERATION_HRS", sequenceName="ong_sowcfg_std_module_operation_hrs_sequence_id")
	@GeneratedValue(generator="SEQ_MODULE_OPERATION_HRS", strategy=GenerationType.SEQUENCE)
	@Column(name="module_operation_hrs_id")
	private Long id;
	
	@Column(name="model")
	private String model;
		
	@Column(name="operation_hrs")
	private float operationHrs;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public float getOperationHrs() {
		return operationHrs;
	}

	public void setOperationHrs(float operationHrs) {
		this.operationHrs = operationHrs;
	}
	

}
