package com.ge.oilandgas.repairportal.sowconfig.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ge.oilandgas.repairportal.sowconfig.entity.EngineLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineModelLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.OpptyTypeLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.ProductLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.ProposalTypeLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.SowMasterMaterial;

@Repository
public interface SowMasterMaterialRepository extends GenericCrudRepository<SowMasterMaterial, Long> {
	
	@Query("SELECT s from SowMasterMaterial s where s.product=?1 and s.model= ?2 and s.engine= ?3 and s.newRepair = ?4 and s.module is null and s.displayInSowMaterialSection='Y'")
	List<SowMasterMaterial> findMaterialByEngine(String product,String model,String engine, String newRepair);

	@Query("SELECT s from SowMasterMaterial s where s.product=?1 and s.model= ?2 and s.engine= ?3 and s.module=?4 and s.newRepair=?5 and s.displayInSowMaterialSection='Y'")
	List<SowMasterMaterial> findMaterialByModule(String product,String model,String engine,String module,String newRepair);

	@Query("SELECT s from SowMasterMaterial s where s.product=?1 and s.model= ?2 and s.engine= ?3 and s.newRepair=?4 and s.module is not null and s.displayInSowMaterialSection='Y'")
	List<SowMasterMaterial> getMaterialByModuleList(String product, String model, String engine,String newRepair);
	
	@Query("SELECT s from EngineLov s where s.product =?1")
	List<EngineLov> getEngineLovList(String product);
	
	@Query("SELECT s from OpptyTypeLov s")
	List<OpptyTypeLov> getOpptyTypeList();

	@Query("SELECT s from ProposalTypeLov s")
	List<ProposalTypeLov> getProposalTypeList();

	@Query("SELECT s from SowMasterMaterial s where s.product=?1 and s.model= ?2 and s.engine= ?3 and s.priceCategory=?4 and s.module is not null and s.displayInSowMaterialSection='Y'")
	List<SowMasterMaterial> getGGTestModuleMaterialList(String product, String model, String engine,String priceCategory);
	
	@Query("SELECT s from SowMasterMaterial s where s.product=?1 and s.model= ?2 and s.engine= ?3 and s.priceCategory=?4 and s.module is null and s.displayInSowMaterialSection='Y'")
	List<SowMasterMaterial> getGGTestEngineMaterialList(String product, String model, String engine,String priceCategory);

	
	@Query("SELECT s.plcModel from EngineModelLov s where s.plcProductType=?1 and s.model= ?2")
	String getPlcModelCode(String product, String model);

	@Query("SELECT s from EngineModelLov s where s.plcProductType =?1")
	List<EngineModelLov> getAllEngineModelLov(String product);
	
	@Query("SELECT s from SowMasterMaterial s where s.product=?1 and s.model= ?2 and s.engine= ?3 and s.module is not null and s.displayInSowMaterialSection='Y'")
	List<SowMasterMaterial> getAllMaterialByModuleList(String product, String model, String engine);
	
	@Query("SELECT s from SowMasterMaterial s where s.product=?1 and s.model= ?2 and s.engine= ?3 and s.module is null and s.displayInSowMaterialSection='Y'")
	List<SowMasterMaterial> getAllMaterialByEngine(String product, String model, String engine);

	@Query("SELECT s from SowMasterMaterial s where s.product=?1 and s.model= ?2 and s.engine= ?3 and s.module=?4 and s.displayInSowMaterialSection='Y'")
	List<SowMasterMaterial> getAllMaterialByModule(String product, String model, String engine, String module);

	@Query("SELECT s from ProductLov s where s.plcProductType = ?1")
	ProductLov getProductDetails(String productCode);

	@Query("SELECT s from ProductLov s")
	List<ProductLov> getProductList();

}



