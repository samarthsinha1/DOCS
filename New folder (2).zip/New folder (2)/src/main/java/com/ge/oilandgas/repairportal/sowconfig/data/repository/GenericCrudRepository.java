package com.ge.oilandgas.repairportal.sowconfig.data.repository;

import java.io.Serializable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ge.oilandgas.repairportal.sowconfig.entity.GenericEntity;


@Repository
public interface GenericCrudRepository<T extends GenericEntity<ID>, ID extends Serializable> 
extends JpaRepository<T, ID>{

}
