package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.oilandgas.repairportal.sowconfig.data.SavedPreferenceDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.SavedPreferenceRepository;
import com.ge.oilandgas.repairportal.sowconfig.entity.SavedPreference;

@Component
public class SavedPreferenceDAOImpl extends GenericCrudDAOImpl<SavedPreference, Long> implements SavedPreferenceDAO {
	
		@Autowired
		private SavedPreferenceRepository savedPreferenceRepository;
		
		  public SavedPreferenceDAOImpl(SavedPreferenceRepository savedPreferenceRepository) {
		        this.savedPreferenceRepository = savedPreferenceRepository;
		    }
		  public SavedPreferenceDAOImpl() {
		       super();
		    }

		  @SuppressWarnings("unchecked")
		    public SavedPreferenceRepository getRepository() {
		        return savedPreferenceRepository;
		    }
		@Override
		public List<SavedPreference> findDetailsBySsoId(Long ssoId) {
			return savedPreferenceRepository.findDetailsBySsoId(ssoId);
		}


}
