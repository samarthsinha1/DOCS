package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ModelEngineDto extends AuditDataDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;
	private Long engineInfoId;
	private String model;
	private String engine;
	private String engineChecked = "false";
	private String additionalComment;
	private List<ModulesDto> moduleList= new LinkedList<>();
	private List<EngineOperationsDto> engineOperationsList = new LinkedList<>();
	private List<EngineMaterialsDto> engineMaterialsList = new LinkedList<>();
	private List<EngineMaterialRepairDto> engineMaterialRepairList= new LinkedList<>();
	private List<EngineOperationListDto> engineNonStdOperationsList = new LinkedList<>();
	private List<EngineOperationListDto> engineOperationOptions= new LinkedList<>();
	
	public List<ModulesDto> getModuleList() {
		return moduleList;
	}
	public void setModuleList(List<ModulesDto> moduleList) {
		this.moduleList = moduleList;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getEngine() {
		return engine;
	}
	public void setEngine(String engine) {
		this.engine = engine;
	}
	
	public Long getEngineInfoId() {
		return engineInfoId;
	}
	public void setEngineInfoId(Long engineInfoId) {
		this.engineInfoId = engineInfoId;
	}
	public String getEngineChecked() {
		return engineChecked;
	}
	public void setEngineChecked(String engineChecked) {
		this.engineChecked = engineChecked;
	}
	public List<EngineOperationsDto> getEngineOperationsList() {
		return engineOperationsList;
	}
	public void setEngineOperationsList(List<EngineOperationsDto> engineOperationsList) {
		this.engineOperationsList = engineOperationsList;
	}
	public List<EngineMaterialsDto> getEngineMaterialsList() {
		return engineMaterialsList;
	}
	public void setEngineMaterialsList(List<EngineMaterialsDto> engineMaterialsList) {
		this.engineMaterialsList = engineMaterialsList;
	}
	public List<EngineMaterialRepairDto> getEngineMaterialRepairList() {
		return engineMaterialRepairList;
	}
	public void setEngineMaterialRepairList(List<EngineMaterialRepairDto> engineMaterialRepairList) {
		this.engineMaterialRepairList = engineMaterialRepairList;
	}
	public String getAdditionalComment() {
		return additionalComment;
	}
	public void setAdditionalComment(String additionalComment) {
		this.additionalComment = additionalComment;
	}
	

	public List<EngineOperationListDto> getEngineOperationOptions() {
		return engineOperationOptions;
	}
	public void setEngineOperationOptions(List<EngineOperationListDto> engineOperationOptions) {
		this.engineOperationOptions = engineOperationOptions;
	}
	public List<EngineOperationListDto> getEngineNonStdOperationsList() {
		return engineNonStdOperationsList;
	}
	public void setEngineNonStdOperationsList(List<EngineOperationListDto> engineNonStdOperationsList) {
		this.engineNonStdOperationsList = engineNonStdOperationsList;
	}
	@Override
	public String toString() {
		return "ModelEngineDto [id=" + id + ", engineInfoId=" + engineInfoId + ", model=" + model + ", engine=" + engine
				+ ", engineChecked=" + engineChecked + ", additionalComment=" + additionalComment + ", moduleList="
				+ moduleList + ", engineOperationsList=" + engineOperationsList + ", engineMaterialsList="
				+ engineMaterialsList + ", engineMaterialRepairList=" + engineMaterialRepairList + "]";
	}
	
	
		
}
