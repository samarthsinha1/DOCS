package com.ge.oilandgas.repairportal.sowconfig.data;

import java.util.List;

import com.ge.oilandgas.repairportal.sowconfig.entity.CommercialView;


public interface CommercialViewDAO extends GenericDAO<CommercialView, Long> {
	
	List<CommercialView> findCommercialViewByEngineInfoId(Long engineInfoId);

}
