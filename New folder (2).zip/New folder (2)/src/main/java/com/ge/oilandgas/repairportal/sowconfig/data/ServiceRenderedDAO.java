package com.ge.oilandgas.repairportal.sowconfig.data;

import java.util.List;

import com.ge.oilandgas.repairportal.sowconfig.entity.ServiceRendered;


public interface ServiceRenderedDAO {
	
	// EngineInfo findByModel(String model);
	 List<ServiceRendered> findByService();

}
