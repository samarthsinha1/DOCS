package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;
import java.util.Date;


public class ReportFieldsDto extends AuditDataDto implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;
	
	private Long engineInfoId;

	private String paymentTerms;

	private String incoterms;

	private String termsAndconditions;


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}



	public Long getEngineInfoId() {
		return engineInfoId;
	}

	public void setEngineInfoId(Long engineInfoId) {
		this.engineInfoId = engineInfoId;
	}

	public String getPaymentTerms() {
		return paymentTerms;
	}

	public void setPaymentTerms(String paymentTerms) {
		this.paymentTerms = paymentTerms;
	}

	public String getIncoterms() {
		return incoterms;
	}

	public void setIncoterms(String incoterms) {
		this.incoterms = incoterms;
	}

	public String getTermsAndconditions() {
		return termsAndconditions;
	}

	public void setTermsAndconditions(String termsAndconditions) {
		this.termsAndconditions = termsAndconditions;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
	
}
