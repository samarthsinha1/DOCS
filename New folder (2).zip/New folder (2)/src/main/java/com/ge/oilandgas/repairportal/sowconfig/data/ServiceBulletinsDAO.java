package com.ge.oilandgas.repairportal.sowconfig.data;

import java.util.List;

import com.ge.oilandgas.repairportal.sowconfig.entity.ReportFields;
import com.ge.oilandgas.repairportal.sowconfig.entity.ServiceBulletins;


public interface ServiceBulletinsDAO extends GenericDAO<ServiceBulletins, Long>{
	List<ServiceBulletins> findServiceBulletinsById(Long id);
}
