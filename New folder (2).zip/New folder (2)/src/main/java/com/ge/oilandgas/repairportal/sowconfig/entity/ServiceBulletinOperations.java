package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ong_sowcfg_SB_operations")
public class ServiceBulletinOperations {

	@Id
    @Column(name = "Operations_id")
	private Long operationsId;
	
	@Column(name="Operations_name")
	private String operationsName;
	
	@Column(name="labour_hours")
	private Long labourHours;
	
	@Column(name="labour_cost")
	private Float labourCost;
	
	@Column(name="labour_price")
	private Float labourPrice;
	
	@Column(name="labour_quote_Price")
	private Float labourQuotePrice;
	
	@Column(name="non_standard_operation_flag")
	private String nonStandardOperation;
	
	@Column(name="description")
	private String description;
	
	@Column(name="bulletin_sequence_id")
	private Long bulletinSeqId;

	public Long getOperationsId() {
		return operationsId;
	}

	public void setOperationsId(Long operationsId) {
		this.operationsId = operationsId;
	}

	public String getOperationsName() {
		return operationsName;
	}

	public void setOperationsName(String operationsName) {
		this.operationsName = operationsName;
	}

	public Long getLabourHours() {
		return labourHours;
	}

	public void setLabourHours(Long labourHours) {
		this.labourHours = labourHours;
	}

	public Float getLabourCost() {
		return labourCost;
	}

	public void setLabourCost(Float labourCost) {
		this.labourCost = labourCost;
	}

	public Float getLabourPrice() {
		return labourPrice;
	}

	public void setLabourPrice(Float labourPrice) {
		this.labourPrice = labourPrice;
	}

	public Float getLabourQuotePrice() {
		return labourQuotePrice;
	}

	public void setLabourQuotePrice(Float labourQuotePrice) {
		this.labourQuotePrice = labourQuotePrice;
	}

	public String isNonStandardOperation() {
		return nonStandardOperation;
	}

	public void setNonStandardOperation(String nonStandardOperation) {
		this.nonStandardOperation = nonStandardOperation;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getBulletinSeqId() {
		return bulletinSeqId;
	}

	public void setBulletinSeqId(Long bulletinSeqId) {
		this.bulletinSeqId = bulletinSeqId;
	}
		
}

