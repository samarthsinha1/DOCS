package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.ge.oilandgas.repairportal.sowconfig.data.SbRepairAndServiceDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.SbRepairAndServiceRepository;

@Component
public class SbRepairAndServiceDAOImpl implements SbRepairAndServiceDAO {

	private static final Logger logger = LoggerFactory.getLogger(SbRepairAndServiceDAOImpl.class);
	
	@Autowired
	private SbRepairAndServiceRepository sbRepairAndServiceRepository;
	
	public SbRepairAndServiceDAOImpl(SbRepairAndServiceRepository sbRepairAndServiceRepository){
		this.sbRepairAndServiceRepository=sbRepairAndServiceRepository;
	}
	
	public SbRepairAndServiceDAOImpl(){
		super();
	}
	
	public SbRepairAndServiceRepository getRepository(){
		return sbRepairAndServiceRepository;
		
	}
	
}
