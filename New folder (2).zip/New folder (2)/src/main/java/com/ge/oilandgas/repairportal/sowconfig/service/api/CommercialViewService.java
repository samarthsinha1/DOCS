package com.ge.oilandgas.repairportal.sowconfig.service.api;

import org.springframework.web.bind.annotation.RequestBody;

import com.ge.oilandgas.repairportal.sowconfig.bo.CommercialViewDto;

import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;

public interface CommercialViewService {
	ResponseTemplateDto<CommercialViewDto> getCommercialViewByEngineInfoId(Long engine_info_id);
	ResponseTemplateDto<CommercialViewDto> saveUpdateCommercialView(@RequestBody CommercialViewDto commercialViewDto);
}
