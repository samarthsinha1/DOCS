package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

public class ModuleOperationListDto implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String plcProductType;
	private String plcCodeRouting;
	private String engine;	
	private String module;
	private Long numOperation;
	private String operationName;
	private String operationType;
	private String stdOperation;
	private List<ModuleOperationHrsLovDto> moduleOperationHrsList = new LinkedList<>();
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	
	public String getOperationName() {
		return operationName;
	}
	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getEngine() {
		return engine;
	}
	public void setEngine(String engine) {
		this.engine = engine;
	}
	public String getPlcProductType() {
		return plcProductType;
	}
	public void setPlcProductType(String plcProductType) {
		this.plcProductType = plcProductType;
	}
	public String getPlcCodeRouting() {
		return plcCodeRouting;
	}
	public void setPlcCodeRouting(String plcCodeRouting) {
		this.plcCodeRouting = plcCodeRouting;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public Long getNumOperation() {
		return numOperation;
	}
	public void setNumOperation(Long numOperation) {
		this.numOperation = numOperation;
	}
	public String getOperationType() {
		return operationType;
	}
	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}
	public String getStdOperation() {
		return stdOperation;
	}
	public void setStdOperation(String stdOperation) {
		this.stdOperation = stdOperation;
	}
	
	public List<ModuleOperationHrsLovDto> getModuleOperationHrsList() {
		return moduleOperationHrsList;
	}
	public void setModuleOperationHrsList(List<ModuleOperationHrsLovDto> moduleOperationHrsList) {
		this.moduleOperationHrsList = moduleOperationHrsList;
	}

}
