package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

public class ShopDetailDto implements Serializable{

		private static final long serialVersionUID = 1L;
		
		private Long id;
		private String engineModel;
		private String product;
		private String shopName;
		private Float shopLaborHourUnitPrice;
		private Float laborHourUnitCost;
		
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		
		
		public String getEngineModel() {
			return engineModel;
		}
		public void setEngineModel(String engineModel) {
			this.engineModel = engineModel;
		}
		public String getShopName() {
			return shopName;
		}
		public void setShopName(String shopName) {
			this.shopName = shopName;
		}
			
		public Float getShopLaborHourUnitPrice() {
			return shopLaborHourUnitPrice;
		}
		public void setShopLaborHourUnitPrice(Float shopLaborHourUnitPrice) {
			this.shopLaborHourUnitPrice = shopLaborHourUnitPrice;
		}
		public String getProduct() {
			return product;
		}
		public void setProduct(String product) {
			this.product = product;
		}
		public Float getLaborHourUnitCost() {
			return laborHourUnitCost;
		}
		public void setLaborHourUnitCost(Float laborHourUnitCost) {
			this.laborHourUnitCost = laborHourUnitCost;
		}
		public static long getSerialversionuid() {
			return serialVersionUID;
		}
		
		
}
