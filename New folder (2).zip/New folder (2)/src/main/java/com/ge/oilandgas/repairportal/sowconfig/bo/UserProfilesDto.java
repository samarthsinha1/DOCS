package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

import java.util.List;

public class UserProfilesDto implements Serializable {
	

	private static final long serialVersionUID = 1L;
	private Long id;
	private String userSso;
	private String userFirstName;
	private String userLastName;
	private String userMiddleName;
	private String userEmail;
	private String userPhone;
	private List<UserRolesDto> role;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUserSso() {
		return userSso;
	}
	public void setUserSso(String userSso) {
		this.userSso = userSso;
	}
	public String getUserFirstName() {
		return userFirstName;
	}
	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}
	public String getUserLastName() {
		return userLastName;
	}
	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}
	public String getUserMiddleName() {
		return userMiddleName;
	}
	public void setUserMiddleName(String userMiddleName) {
		this.userMiddleName = userMiddleName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public List<UserRolesDto> getRole() {
		return role;
	}
	public void setRole(List<UserRolesDto> role) {
		this.role = role;
	}
}
