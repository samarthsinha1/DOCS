package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name= "ong_sowcfg_std_new_material_lov_temp")
public class MasterMaterialLovTemp extends GenericEntity<Long>{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4807493246513369866L;
	
	@Id
	@SequenceGenerator(name="SEQ_MATERIAL_LOV_TEMP", sequenceName="ong_sowcfg_std_new_material_lov_temp_sequence_id")
	@GeneratedValue(generator="SEQ_MATERIAL_LOV_TEMP", strategy=GenerationType.SEQUENCE)
	@Column(name="material_lov_temp_id")
	private Long id;
	
	
	@Column(name="source")
	private String source;
	
	@Column(name="product")
	private String product;
	
	@Column(name="model")
	private String model;
	
	@Column(name="document")
	private String document;
	
	@Column(name="change")
	private Long change;
	
	@Column(name="engine")
	private String engine;
	
	@Column(name="module")
	private String module; 
		
	@Column(name="module_name")
	private String moduleName;
	
	@Column(name="pagina")
	private Long pagina;
		
	@Column(name="sow_index")
	private String sowIndex;
	
	@Column(name="part_number")
	private String partNumber;
	
	@Column(name="nomenclature")
	private String nomenclature;
	
	@Column(name="status")
	private String status;
	
	@Column(name="bom_qty")
	private Long bomQty;
	
	@Column(name="display_in_sow_material_section")
	private String displayInSowMaterialSection;
	
	@Column(name="display_in_sow_material_as")
	private String displayInSowMaterialAs;
	
	@Column(name="price_category")
	private String priceCategory; 
		
	@Column(name="new_repair")
	private String newRepair;
	
	@Column(name="service_rendered")
	private String serviceRendered;
		
	@Column(name="fall_out")
	private Float fallOut;
	
	@Column(name="price_family")
	private String priceFamily;
	
	@Column(name="doc_name")
	private String docName;
		
	@Column(name="supplier_type")
	private String supplierType;
	
	@Column(name="supplier")
	private String supplier;
	
	@Column(name="unit_cost")
	private float unitCost;
	
	@Column(name="unit_price")
	private float unitPrice;
	
	@Transient
	private String materialDeleted;
	 
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getDocument() {
		return document;
	}

	public void setDocument(String document) {
		this.document = document;
	}

	public Long getChange() {
		return change;
	}

	public void setChange(Long change) {
		this.change = change;
	}

	public String getEngine() {
		return engine;
	}

	public void setEngine(String engine) {
		this.engine = engine;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public Long getPagina() {
		return pagina;
	}

	public void setPagina(Long pagina) {
		this.pagina = pagina;
	}

    

	public String getSowIndex() {
		return sowIndex;
	}

	public void setSowIndex(String sowIndex) {
		this.sowIndex = sowIndex;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getNomenclature() {
		return nomenclature;
	}

	public void setNomenclature(String nomenclature) {
		this.nomenclature = nomenclature;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getBomQty() {
		return bomQty;
	}

	public void setBomQty(Long bomQty) {
		this.bomQty = bomQty;
	}

	public String getDisplayInSowMaterialSection() {
		return displayInSowMaterialSection;
	}

	public void setDisplayInSowMaterialSection(String displayInSowMaterialSection) {
		this.displayInSowMaterialSection = displayInSowMaterialSection;
	}

	public String getDisplayInSowMaterialAs() {
		return displayInSowMaterialAs;
	}

	public void setDisplayInSowMaterialAs(String displayInSowMaterialAs) {
		this.displayInSowMaterialAs = displayInSowMaterialAs;
	}

	public String getPriceCategory() {
		return priceCategory;
	}

	public void setPriceCategory(String priceCategory) {
		this.priceCategory = priceCategory;
	}

	public String getNewRepair() {
		return newRepair;
	}

	public void setNewRepair(String newRepair) {
		this.newRepair = newRepair;
	}

	public String getServiceRendered() {
		return serviceRendered;
	}

	public void setServiceRendered(String serviceRendered) {
		this.serviceRendered = serviceRendered;
	}

	public Float getFallOut() {
		return fallOut;
	}

	public void setFallOut(Float fallOut) {
		this.fallOut = fallOut;
	}

	public String getPriceFamily() {
		return priceFamily;
	}

	public void setPriceFamily(String priceFamily) {
		this.priceFamily = priceFamily;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public String getSupplierType() {
		return supplierType;
	}

	public void setSupplierType(String supplierType) {
		this.supplierType = supplierType;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public float getUnitCost() {
		return unitCost;
	}

	public void setUnitCost(float unitCost) {
		this.unitCost = unitCost;
	}

	public float getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(float unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getMaterialDeleted() {
		return materialDeleted;
	}

	public void setMaterialDeleted(String materialDeleted) {
		this.materialDeleted = materialDeleted;
	}

	
}
