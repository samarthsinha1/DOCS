package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ong_sowcfg_SB_newMaterials")
public class ServiceBulletinNewMaterials {

	@Id
    @Column(name = "material_id")
	private Long materialId;
	
	@Column(name="bulletin_sequence_id")
	private Long bulletinSeqId;
	
	@Column(name="component_group")
	private String componentGroup;
	
	@Column(name="componenet_code")
	private String componentCode;
	
	@Column(name="component_description")
	private String componentDescription;
	
	@Column(name="quantity")
	private Long quantity;
	
	@Column(name="machine_Model")
	private String machineModel;
	
	@Column(name="module")
	private String module;

	public Long getMaterialId() {
		return materialId;
	}

	public void setMaterialId(Long materialId) {
		this.materialId = materialId;
	}

	public Long getBulletinSeqId() {
		return bulletinSeqId;
	}

	public void setBulletinSeqId(Long bulletinSeqId) {
		this.bulletinSeqId = bulletinSeqId;
	}

	public String getComponentGroup() {
		return componentGroup;
	}

	public void setComponentGroup(String componentGroup) {
		this.componentGroup = componentGroup;
	}

	public String getComponentCode() {
		return componentCode;
	}

	public void setComponentCode(String componentCode) {
		this.componentCode = componentCode;
	}

	public String getComponentDescription() {
		return componentDescription;
	}

	public void setComponentDescription(String componentDescription) {
		this.componentDescription = componentDescription;
	}

	public Long getQuantity() {
		return quantity;
	}

	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}

	public String getMachineModel() {
		return machineModel;
	}

	public void setMachineModel(String machineModel) {
		this.machineModel = machineModel;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}
	
}
