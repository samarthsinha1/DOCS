package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PriceCategoryDto extends AuditDataDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private Long id;
	
	private String priceCategoryName;
	
	private Float priceCategoryTotalCost;
	
	private Float priceCategoryQuotePrice;

	private Float priceCategoryCm;

	private Float priceCategoryCmPercentage;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPriceCategoryName() {
		return priceCategoryName;
	}

	public void setPriceCategoryName(String priceCategoryName) {
		this.priceCategoryName = priceCategoryName;
	}

	public Float getPriceCategoryTotalCost() {
		return priceCategoryTotalCost;
	}

	public void setPriceCategoryTotalCost(Float priceCategoryTotalCost) {
		this.priceCategoryTotalCost = priceCategoryTotalCost;
	}

	public Float getPriceCategoryQuotePrice() {
		return priceCategoryQuotePrice;
	}

	public void setPriceCategoryQuotePrice(Float priceCategoryQuotePrice) {
		this.priceCategoryQuotePrice = priceCategoryQuotePrice;
	}

	public Float getPriceCategoryCm() {
		return priceCategoryCm;
	}

	public void setPriceCategoryCm(Float priceCategoryCm) {
		this.priceCategoryCm = priceCategoryCm;
	}

	public Float getPriceCategoryCmPercentage() {
		return priceCategoryCmPercentage;
	}

	public void setPriceCategoryCmPercentage(Float priceCategoryCmPercentage) {
		this.priceCategoryCmPercentage = priceCategoryCmPercentage;
	}
	
	
}
