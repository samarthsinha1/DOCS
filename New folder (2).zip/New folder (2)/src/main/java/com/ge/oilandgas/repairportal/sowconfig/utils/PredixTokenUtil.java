package com.ge.oilandgas.repairportal.sowconfig.utils;

import java.io.IOException;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class PredixTokenUtil {
	
	@Autowired
	private RestProxyTemplate restProxyTemplate;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(PredixTokenUtil.class);
	
	public String getToken() throws JsonParseException, JsonMappingException, IOException{
		LOGGER.debug("Inside getToken");
		ObjectMapper mapper = new ObjectMapper();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.add("Authorization","Basic YXZpYXRpb25fRUdUU2VydmljZV9kZXY6cmR6M2hPUXU4cHAxZ0MxTg==");
		MultiValueMap<String, String> map= new LinkedMultiValueMap<String, String>();
		map.add("grant_type", "client_credentials");
		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(map, headers);
		RestTemplate restTemplate = restProxyTemplate.getRestTemplate();
		ResponseEntity<String> responseEntity = restTemplate.postForEntity( "https://a99b7fee-a495-4161-89c3-faa83054627d.predix-uaa.run.asv-pr.ice.predix.io/oauth/token", request , String.class );
		String body = responseEntity.getBody();
		Map<String,String> values = mapper.readValue(body, new TypeReference<Map<String, String>>(){});
		String response = values.get("access_token");
		LOGGER.debug(response);
		return response;
	}
	
}
