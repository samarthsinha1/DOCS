package com.ge.oilandgas.repairportal.sowconfig.service.api;

import org.springframework.web.bind.annotation.RequestBody;

import com.ge.oilandgas.repairportal.sowconfig.bo.ReportFieldsDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;

public interface ReportFieldsService {
	
	ResponseTemplateDto<ReportFieldsDto> getReportFieldsByEngineInfoId(Long engineInfoId);
	
   ResponseTemplateDto<ReportFieldsDto> deleteReportFieldById(Long engineInfoId);
	
	ResponseTemplateDto<ReportFieldsDto> saveUpdateReportFields(@RequestBody ReportFieldsDto reportFieldsDto);


}
