package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

public class CommercialViewDto extends AuditDataDto implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;
	
	private Long engineInfoId;
	
	private float partsDiscountableCostEscalation;

	private float partsNonDiscountableCostEscalation;
	
	private float partsConsumablesCostEscalation;

	private float sbCostEscalation;
	
	private float laborCostEscalation;

	private float outSourcingRepairGeAirfollsCostEscalation;

	private float outSourcingRepairVendorCostEscalation;
	
	private float partsDiscountableCost;

	private float partsNonDiscountableCost;

	private float partsConsumablesCost;

	private float sbCost;

	private float laborCost;

	private float outSourcingRepairGeAirfollsCost;

	private float outSourcingRepairVendorCost;

	private float depotTestCost;
	
	private float outSourcingRepairGeAirfollsMarkup;

	private float outSourcingRepairVendorMarkup;

	private float partsDiscountablePriceEscalation;
	
	private float partsNonDiscountablePriceEscalation;
	
	private float partsConsumablesPriceEscalation;

	private float sbPriceEscalation;

	private float laborPriceEscalation;

	private float outSourcingRepairGeAirfollsPriceEscalation;

	private float outSourcingRepairVendorPriceEscalation;

	private float partsDiscountableDiscount;
	
	private float partsNonDiscountableDiscount;

	private float partsConsumablesDiscount;

	private float sbDiscount;

	private float laborDiscount;

	private float depotTestDiscount;

	private float partsDiscountableQuotePrice;
	
	private float partsNonDiscountableQuotePrice;

	private float partsConsumablesQuotePrice;

	private float sbQuotePrice;

	private float laborQuotePrice;

	private float outSourcingRepairGeAirfollsQuotePrice;

	private float outSourcingRepairVendorQuotePrice;

	private float depotTestQuotePrice;

	private float partsDiscountableCm;

	private float partsNonDiscountableCm;

	private float partsConsumablesCm;

	private float sbCm;

	private float laborCm;

	private float outSourcingRepairGeAirfollsCm;

	private float outSourcingRepairVendorCm;

	private float depotTestCm;

	private float partsDiscountableCmPercentage;

	private float partsNonDiscountableCmPercentage;

	private float partsConsumablesCmPercentage;

	private float sbCmPercentage;

	private float laborCmPercentage;
	
	private float outSourcingRepairGeAirfollsCmPercentage;

	private float outSourcingRepairVendorCmPercentage;

	private float depotTestCmPercentage;
	
	private float partsDiscountableCostSum;
	
	private float partsNonDiscountableCostSum;
	
	private float partsConsumablesCostSum;
	
	private float sbCostSum;
	
	private float laborCostSum;
	
	private float outSourcingRepairGeAirfollsCostSum;
	
	private float outSourcingRepairVendorCostSum;
	
	private float depotTestCostSum;
		
	private float partsDiscountablePriceSum;
	
	private float partsNonDiscountablePriceSum;
	
	private float partsConsumablesPriceSum;
	
	private float sbPriceSum;
	
	private float laborPriceSum;
	
	private float outSourcingRepairGeAirfollsPriceSum;
	
	private float outSourcingRepairVendorPriceSum;

	private float depotTestPriceSum;
	
	private float overAllDiscount;

	private float laborSupervising;
	
	private float depotTestCostEscalation;
	
	private float depotTestPriceEscalation;
	
	private float laborHrsSum;
	
	private List<PriceCategoryDto> priceCategoryList = new LinkedList<>();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	

	public Long getEngineInfoId() {
		return engineInfoId;
	}

	public void setEngineInfoId(Long engineInfoId) {
		this.engineInfoId = engineInfoId;
	}

	public float getPartsDiscountableCostEscalation() {
		return partsDiscountableCostEscalation;
	}

	public void setPartsDiscountableCostEscalation(float partsDiscountableCostEscalation) {
		this.partsDiscountableCostEscalation = partsDiscountableCostEscalation;
	}

	public float getPartsNonDiscountableCostEscalation() {
		return partsNonDiscountableCostEscalation;
	}

	public void setPartsNonDiscountableCostEscalation(float partsNonDiscountableCostEscalation) {
		this.partsNonDiscountableCostEscalation = partsNonDiscountableCostEscalation;
	}

	public float getPartsConsumablesCostEscalation() {
		return partsConsumablesCostEscalation;
	}

	public void setPartsConsumablesCostEscalation(float partsConsumablesCostEscalation) {
		this.partsConsumablesCostEscalation = partsConsumablesCostEscalation;
	}

	public float getLaborCostEscalation() {
		return laborCostEscalation;
	}

	public void setLaborCostEscalation(float laborCostEscalation) {
		this.laborCostEscalation = laborCostEscalation;
	}

	public float getOutSourcingRepairGeAirfollsCostEscalation() {
		return outSourcingRepairGeAirfollsCostEscalation;
	}

	public void setOutSourcingRepairGeAirfollsCostEscalation(float outSourcingRepairGeAirfollsCostEscalation) {
		this.outSourcingRepairGeAirfollsCostEscalation = outSourcingRepairGeAirfollsCostEscalation;
	}

	public float getOutSourcingRepairVendorCostEscalation() {
		return outSourcingRepairVendorCostEscalation;
	}

	public void setOutSourcingRepairVendorCostEscalation(float outSourcingRepairVendorCostEscalation) {
		this.outSourcingRepairVendorCostEscalation = outSourcingRepairVendorCostEscalation;
	}

	public float getPartsDiscountableCost() {
		return partsDiscountableCost;
	}

	public void setPartsDiscountableCost(float partsDiscountableCost) {
		this.partsDiscountableCost = partsDiscountableCost;
	}

	public float getPartsNonDiscountableCost() {
		return partsNonDiscountableCost;
	}

	public void setPartsNonDiscountableCost(float partsNonDiscountableCost) {
		this.partsNonDiscountableCost = partsNonDiscountableCost;
	}

	public float getPartsConsumablesCost() {
		return partsConsumablesCost;
	}

	public void setPartsConsumablesCost(float partsConsumablesCost) {
		this.partsConsumablesCost = partsConsumablesCost;
	}

	public float getLaborCost() {
		return laborCost;
	}

	public void setLaborCost(float laborCost) {
		this.laborCost = laborCost;
	}

	public float getOutSourcingRepairGeAirfollsCost() {
		return outSourcingRepairGeAirfollsCost;
	}

	public void setOutSourcingRepairGeAirfollsCost(float outSourcingRepairGeAirfollsCost) {
		this.outSourcingRepairGeAirfollsCost = outSourcingRepairGeAirfollsCost;
	}

	public float getOutSourcingRepairVendorCost() {
		return outSourcingRepairVendorCost;
	}

	public void setOutSourcingRepairVendorCost(float outSourcingRepairVendorCost) {
		this.outSourcingRepairVendorCost = outSourcingRepairVendorCost;
	}

	public float getDepotTestCost() {
		return depotTestCost;
	}

	public void setDepotTestCost(float depotTestCost) {
		this.depotTestCost = depotTestCost;
	}

	public float getOutSourcingRepairGeAirfollsMarkup() {
		return outSourcingRepairGeAirfollsMarkup;
	}

	public void setOutSourcingRepairGeAirfollsMarkup(float outSourcingRepairGeAirfollsMarkup) {
		this.outSourcingRepairGeAirfollsMarkup = outSourcingRepairGeAirfollsMarkup;
	}

	public float getOutSourcingRepairVendorMarkup() {
		return outSourcingRepairVendorMarkup;
	}

	public void setOutSourcingRepairVendorMarkup(float outSourcingRepairVendorMarkup) {
		this.outSourcingRepairVendorMarkup = outSourcingRepairVendorMarkup;
	}

	public float getPartsDiscountablePriceEscalation() {
		return partsDiscountablePriceEscalation;
	}

	public void setPartsDiscountablePriceEscalation(float partsDiscountablePriceEscalation) {
		this.partsDiscountablePriceEscalation = partsDiscountablePriceEscalation;
	}

	public float getPartsNonDiscountablePriceEscalation() {
		return partsNonDiscountablePriceEscalation;
	}

	public void setPartsNonDiscountablePriceEscalation(float partsNonDiscountablePriceEscalation) {
		this.partsNonDiscountablePriceEscalation = partsNonDiscountablePriceEscalation;
	}

	public float getPartsConsumablesPriceEscalation() {
		return partsConsumablesPriceEscalation;
	}

	public void setPartsConsumablesPriceEscalation(float partsConsumablesPriceEscalation) {
		this.partsConsumablesPriceEscalation = partsConsumablesPriceEscalation;
	}

	public float getLaborPriceEscalation() {
		return laborPriceEscalation;
	}

	public void setLaborPriceEscalation(float laborPriceEscalation) {
		this.laborPriceEscalation = laborPriceEscalation;
	}

	public float getOutSourcingRepairGeAirfollsPriceEscalation() {
		return outSourcingRepairGeAirfollsPriceEscalation;
	}

	public void setOutSourcingRepairGeAirfollsPriceEscalation(float outSourcingRepairGeAirfollsPriceEscalation) {
		this.outSourcingRepairGeAirfollsPriceEscalation = outSourcingRepairGeAirfollsPriceEscalation;
	}

	public float getOutSourcingRepairVendorPriceEscalation() {
		return outSourcingRepairVendorPriceEscalation;
	}

	public void setOutSourcingRepairVendorPriceEscalation(float outSourcingRepairVendorPriceEscalation) {
		this.outSourcingRepairVendorPriceEscalation = outSourcingRepairVendorPriceEscalation;
	}

	public float getPartsDiscountableDiscount() {
		return partsDiscountableDiscount;
	}

	public void setPartsDiscountableDiscount(float partsDiscountableDiscount) {
		this.partsDiscountableDiscount = partsDiscountableDiscount;
	}

	public float getPartsNonDiscountableDiscount() {
		return partsNonDiscountableDiscount;
	}

	public void setPartsNonDiscountableDiscount(float partsNonDiscountableDiscount) {
		this.partsNonDiscountableDiscount = partsNonDiscountableDiscount;
	}

	public float getPartsConsumablesDiscount() {
		return partsConsumablesDiscount;
	}

	public void setPartsConsumablesDiscount(float partsConsumablesDiscount) {
		this.partsConsumablesDiscount = partsConsumablesDiscount;
	}

	public float getLaborDiscount() {
		return laborDiscount;
	}

	public void setLaborDiscount(float laborDiscount) {
		this.laborDiscount = laborDiscount;
	}

	public float getDepotTestDiscount() {
		return depotTestDiscount;
	}

	public void setDepotTestDiscount(float depotTestDiscount) {
		this.depotTestDiscount = depotTestDiscount;
	}

	public float getPartsDiscountableQuotePrice() {
		return partsDiscountableQuotePrice;
	}

	public void setPartsDiscountableQuotePrice(float partsDiscountableQuotePrice) {
		this.partsDiscountableQuotePrice = partsDiscountableQuotePrice;
	}

	public float getPartsNonDiscountableQuotePrice() {
		return partsNonDiscountableQuotePrice;
	}

	public void setPartsNonDiscountableQuotePrice(float partsNonDiscountableQuotePrice) {
		this.partsNonDiscountableQuotePrice = partsNonDiscountableQuotePrice;
	}

	public float getPartsConsumablesQuotePrice() {
		return partsConsumablesQuotePrice;
	}

	public void setPartsConsumablesQuotePrice(float partsConsumablesQuotePrice) {
		this.partsConsumablesQuotePrice = partsConsumablesQuotePrice;
	}

	public float getLaborQuotePrice() {
		return laborQuotePrice;
	}

	public void setLaborQuotePrice(float laborQuotePrice) {
		this.laborQuotePrice = laborQuotePrice;
	}

	public float getOutSourcingRepairGeAirfollsQuotePrice() {
		return outSourcingRepairGeAirfollsQuotePrice;
	}

	public void setOutSourcingRepairGeAirfollsQuotePrice(float outSourcingRepairGeAirfollsQuotePrice) {
		this.outSourcingRepairGeAirfollsQuotePrice = outSourcingRepairGeAirfollsQuotePrice;
	}

	public float getOutSourcingRepairVendorQuotePrice() {
		return outSourcingRepairVendorQuotePrice;
	}

	public void setOutSourcingRepairVendorQuotePrice(float outSourcingRepairVendorQuotePrice) {
		this.outSourcingRepairVendorQuotePrice = outSourcingRepairVendorQuotePrice;
	}

	public float getDepotTestQuotePrice() {
		return depotTestQuotePrice;
	}

	public void setDepotTestQuotePrice(float depotTestQuotePrice) {
		this.depotTestQuotePrice = depotTestQuotePrice;
	}

	public float getPartsDiscountableCm() {
		return partsDiscountableCm;
	}

	public void setPartsDiscountableCm(float partsDiscountableCm) {
		this.partsDiscountableCm = partsDiscountableCm;
	}

	public float getPartsNonDiscountableCm() {
		return partsNonDiscountableCm;
	}

	public void setPartsNonDiscountableCm(float partsNonDiscountableCm) {
		this.partsNonDiscountableCm = partsNonDiscountableCm;
	}

	public float getPartsConsumablesCm() {
		return partsConsumablesCm;
	}

	public void setPartsConsumablesCm(float partsConsumablesCm) {
		this.partsConsumablesCm = partsConsumablesCm;
	}

	public float getLaborCm() {
		return laborCm;
	}

	public void setLaborCm(float laborCm) {
		this.laborCm = laborCm;
	}

	public float getOutSourcingRepairGeAirfollsCm() {
		return outSourcingRepairGeAirfollsCm;
	}

	public void setOutSourcingRepairGeAirfollsCm(float outSourcingRepairGeAirfollsCm) {
		this.outSourcingRepairGeAirfollsCm = outSourcingRepairGeAirfollsCm;
	}

	public float getOutSourcingRepairVendorCm() {
		return outSourcingRepairVendorCm;
	}

	public void setOutSourcingRepairVendorCm(float outSourcingRepairVendorCm) {
		this.outSourcingRepairVendorCm = outSourcingRepairVendorCm;
	}

	public float getDepotTestCm() {
		return depotTestCm;
	}

	public void setDepotTestCm(float depotTestCm) {
		this.depotTestCm = depotTestCm;
	}

	public float getPartsDiscountableCmPercentage() {
		return partsDiscountableCmPercentage;
	}

	public void setPartsDiscountableCmPercentage(float partsDiscountableCmPercentage) {
		this.partsDiscountableCmPercentage = partsDiscountableCmPercentage;
	}

	public float getPartsNonDiscountableCmPercentage() {
		return partsNonDiscountableCmPercentage;
	}

	public void setPartsNonDiscountableCmPercentage(float partsNonDiscountableCmPercentage) {
		this.partsNonDiscountableCmPercentage = partsNonDiscountableCmPercentage;
	}

	public float getPartsConsumablesCmPercentage() {
		return partsConsumablesCmPercentage;
	}

	public void setPartsConsumablesCmPercentage(float partsConsumablesCmPercentage) {
		this.partsConsumablesCmPercentage = partsConsumablesCmPercentage;
	}

	public float getLaborCmPercentage() {
		return laborCmPercentage;
	}

	public void setLaborCmPercentage(float laborCmPercentage) {
		this.laborCmPercentage = laborCmPercentage;
	}

	public float getOutSourcingRepairGeAirfollsCmPercentage() {
		return outSourcingRepairGeAirfollsCmPercentage;
	}

	public void setOutSourcingRepairGeAirfollsCmPercentage(float outSourcingRepairGeAirfollsCmPercentage) {
		this.outSourcingRepairGeAirfollsCmPercentage = outSourcingRepairGeAirfollsCmPercentage;
	}

	public float getOutSourcingRepairVendorCmPercentage() {
		return outSourcingRepairVendorCmPercentage;
	}

	public void setOutSourcingRepairVendorCmPercentage(float outSourcingRepairVendorCmPercentage) {
		this.outSourcingRepairVendorCmPercentage = outSourcingRepairVendorCmPercentage;
	}

	public float getDepotTestCmPercentage() {
		return depotTestCmPercentage;
	}

	public void setDepotTestCmPercentage(float depotTestCmPercentage) {
		this.depotTestCmPercentage = depotTestCmPercentage;
	}

	public float getPartsDiscountableCostSum() {
		return partsDiscountableCostSum;
	}

	public void setPartsDiscountableCostSum(float partsDiscountableCostSum) {
		this.partsDiscountableCostSum = partsDiscountableCostSum;
	}

	public float getPartsNonDiscountableCostSum() {
		return partsNonDiscountableCostSum;
	}

	public void setPartsNonDiscountableCostSum(float partsNonDiscountableCostSum) {
		this.partsNonDiscountableCostSum = partsNonDiscountableCostSum;
	}

	public float getPartsConsumablesCostSum() {
		return partsConsumablesCostSum;
	}

	public void setPartsConsumablesCostSum(float partsConsumablesCostSum) {
		this.partsConsumablesCostSum = partsConsumablesCostSum;
	}

	public float getLaborCostSum() {
		return laborCostSum;
	}

	public void setLaborCostSum(float laborCostSum) {
		this.laborCostSum = laborCostSum;
	}

	public float getOutSourcingRepairGeAirfollsCostSum() {
		return outSourcingRepairGeAirfollsCostSum;
	}

	public void setOutSourcingRepairGeAirfollsCostSum(float outSourcingRepairGeAirfollsCostSum) {
		this.outSourcingRepairGeAirfollsCostSum = outSourcingRepairGeAirfollsCostSum;
	}

	public float getOutSourcingRepairVendorCostSum() {
		return outSourcingRepairVendorCostSum;
	}

	public void setOutSourcingRepairVendorCostSum(float outSourcingRepairVendorCostSum) {
		this.outSourcingRepairVendorCostSum = outSourcingRepairVendorCostSum;
	}

	public float getDepotTestCostSum() {
		return depotTestCostSum;
	}

	public void setDepotTestCostSum(float depotTestCostSum) {
		this.depotTestCostSum = depotTestCostSum;
	}

	public float getPartsDiscountablePriceSum() {
		return partsDiscountablePriceSum;
	}

	public void setPartsDiscountablePriceSum(float partsDiscountablePriceSum) {
		this.partsDiscountablePriceSum = partsDiscountablePriceSum;
	}

	public float getPartsNonDiscountablePriceSum() {
		return partsNonDiscountablePriceSum;
	}

	public void setPartsNonDiscountablePriceSum(float partsNonDiscountablePriceSum) {
		this.partsNonDiscountablePriceSum = partsNonDiscountablePriceSum;
	}

	public float getPartsConsumablesPriceSum() {
		return partsConsumablesPriceSum;
	}

	public void setPartsConsumablesPriceSum(float partsConsumablesPriceSum) {
		this.partsConsumablesPriceSum = partsConsumablesPriceSum;
	}

	public float getLaborPriceSum() {
		return laborPriceSum;
	}

	public void setLaborPriceSum(float laborPriceSum) {
		this.laborPriceSum = laborPriceSum;
	}

	public float getOutSourcingRepairGeAirfollsPriceSum() {
		return outSourcingRepairGeAirfollsPriceSum;
	}

	public void setOutSourcingRepairGeAirfollsPriceSum(float outSourcingRepairGeAirfollsPriceSum) {
		this.outSourcingRepairGeAirfollsPriceSum = outSourcingRepairGeAirfollsPriceSum;
	}

	public float getOutSourcingRepairVendorPriceSum() {
		return outSourcingRepairVendorPriceSum;
	}

	public void setOutSourcingRepairVendorPriceSum(float outSourcingRepairVendorPriceSum) {
		this.outSourcingRepairVendorPriceSum = outSourcingRepairVendorPriceSum;
	}

	public float getDepotTestPriceSum() {
		return depotTestPriceSum;
	}

	public void setDepotTestPriceSum(float depotTestPriceSum) {
		this.depotTestPriceSum = depotTestPriceSum;
	}

	public float getOverAllDiscount() {
		return overAllDiscount;
	}

	public void setOverAllDiscount(float overAllDiscount) {
		this.overAllDiscount = overAllDiscount;
	}

	public List<PriceCategoryDto> getPriceCategoryList() {
		return priceCategoryList;
	}

	public void setPriceCategoryList(List<PriceCategoryDto> priceCategoryList) {
		this.priceCategoryList = priceCategoryList;
	}

	public float getSbCostEscalation() {
		return sbCostEscalation;
	}

	public void setSbCostEscalation(float sbCostEscalation) {
		this.sbCostEscalation = sbCostEscalation;
	}

	public float getSbCost() {
		return sbCost;
	}

	public void setSbCost(float sbCost) {
		this.sbCost = sbCost;
	}

	public float getSbPriceEscalation() {
		return sbPriceEscalation;
	}

	public void setSbPriceEscalation(float sbPriceEscalation) {
		this.sbPriceEscalation = sbPriceEscalation;
	}

	public float getSbDiscount() {
		return sbDiscount;
	}

	public void setSbDiscount(float sbDiscount) {
		this.sbDiscount = sbDiscount;
	}

	public float getSbQuotePrice() {
		return sbQuotePrice;
	}

	public void setSbQuotePrice(float sbQuotePrice) {
		this.sbQuotePrice = sbQuotePrice;
	}

	public float getSbCm() {
		return sbCm;
	}

	public void setSbCm(float sbCm) {
		this.sbCm = sbCm;
	}

	public float getSbCmPercentage() {
		return sbCmPercentage;
	}

	public void setSbCmPercentage(float sbCmPercentage) {
		this.sbCmPercentage = sbCmPercentage;
	}

	public float getSbCostSum() {
		return sbCostSum;
	}

	public void setSbCostSum(float sbCostSum) {
		this.sbCostSum = sbCostSum;
	}

	public float getSbPriceSum() {
		return sbPriceSum;
	}

	public void setSbPriceSum(float sbPriceSum) {
		this.sbPriceSum = sbPriceSum;
	}

	public float getLaborSupervising() {
		return laborSupervising;
	}

	public void setLaborSupervising(float laborSupervising) {
		this.laborSupervising = laborSupervising;
	}

	public float getDepotTestCostEscalation() {
		return depotTestCostEscalation;
	}

	public void setDepotTestCostEscalation(float depotTestCostEscalation) {
		this.depotTestCostEscalation = depotTestCostEscalation;
	}

	public float getDepotTestPriceEscalation() {
		return depotTestPriceEscalation;
	}

	public void setDepotTestPriceEscalation(float depotTestPriceEscalation) {
		this.depotTestPriceEscalation = depotTestPriceEscalation;
	}

	public float getLaborHrsSum() {
		return laborHrsSum;
	}

	public void setLaborHrsSum(float laborHrsSum) {
		this.laborHrsSum = laborHrsSum;
	}
	

}
