package com.ge.oilandgas.repairportal.sowconfig.manager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.oilandgas.repairportal.sowconfig.bo.EngineModuleDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineOperationListDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ListPriceDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ListPriceServicesRenderedDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ListPriceSuppliersDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ModuleOperationListDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.OperationTypeLovDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.OpptyTypeLovDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ProductLovDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ProposalTypeLovDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.RepairSupplierDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ServiceRenderedDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ShopDetailDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.SowMasterMaterialDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.SowMasterMaterialDtoForUI;
import com.ge.oilandgas.repairportal.sowconfig.bo.StdSbLovDto;
import com.ge.oilandgas.repairportal.sowconfig.common.EntityBoMapper;
import com.ge.oilandgas.repairportal.sowconfig.data.EngineModuleDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.EngineOperationListDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.ListPriceDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.ModuleOperationListDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.OperationTypeLovDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.RepairSupplierDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.ServiceRenderedDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.ShopDetailDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.SowMasterMaterialDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.StdSbLovDAO;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineModule;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineOperationList;
import com.ge.oilandgas.repairportal.sowconfig.entity.ListPrice;
import com.ge.oilandgas.repairportal.sowconfig.entity.ModuleOperationList;
import com.ge.oilandgas.repairportal.sowconfig.entity.OperationTypeLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.OpptyTypeLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.ProductLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.ProposalTypeLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.RepairSupplier;
import com.ge.oilandgas.repairportal.sowconfig.entity.ServiceRendered;
import com.ge.oilandgas.repairportal.sowconfig.entity.ShopDetail;
import com.ge.oilandgas.repairportal.sowconfig.entity.SowMasterMaterial;
import com.ge.oilandgas.repairportal.sowconfig.entity.StdSbLov;

@Service
public class SowMasterManager {
	
	private static final String ALL = "ALL";
	private static final String SUCCESS = "Success";
	private static final Logger LOGGER = LoggerFactory.getLogger(SowMasterManager.class);
	private static List<String> PRICE_LIST_TYPE = Arrays.asList(new String[] {"NEW","OSS"});
	private static List<String> SUPPLIER_TYPE = Arrays.asList(new String[] {"GE","EXT"});
	
	@Autowired
	private EntityBoMapper entityBoMapper;
	@Autowired
	private ShopDetailDAO shopDetailDAO;
	@Autowired
	private ServiceRenderedDAO serviceRenderedDAO;
	@Autowired
	private RepairSupplierDAO repairSupplierDAO;
	@Autowired
	private EngineModuleDAO engineModuleDAO;
	@Autowired
	private EngineOperationListDAO engineOperationListDAO;
	@Autowired
	private ModuleOperationListDAO moduleOperationListDAO;
	@Autowired
	private SowMasterMaterialDAO sowMasterMaterialDAO;
	@Autowired
	private OperationTypeLovDAO operationTypeLovDAO;
	@Autowired
	ListPriceDAO listPriceDAO;
	@Autowired
	StdSbLovDAO stdSbLovDAO;
		
	/**
	 * @param engineModel
	 * @param product
	 * @return
	 */
	public ResponseTemplateDto<ShopDetailDto> getEngineModelShopDetails(String engineModel,String product) {
		LOGGER.debug("Class::SowMasterManager, Method::getEngineModelShopDetails::ENTER");
		ResponseTemplateDto<ShopDetailDto> response = new ResponseTemplateDto<>();
		try{
			LOGGER.debug("Class::SowMasterManager, Method::getEngineModelShopDetails::engineModel"+engineModel);
			List<ShopDetail> shopDetailList= shopDetailDAO.findByEngineModel(engineModel,product);
			List<ShopDetailDto> shopDetailDtoList = entityBoMapper.map(shopDetailList,ShopDetailDto.class);				
			LOGGER.debug("Class::SowMasterManager, Method::getEngineModelShopDetails::engineModel"+engineModel);
			response.setDataList(shopDetailDtoList);
			response.setOverallCount(new Long(shopDetailDtoList.size()));
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Error retrieving engineInfo for model " + engineModel, e);
			response.setStatusMsg("Error retrieving engineInfo for model " + engineModel);
			response.setSuccess(false);
		}
		LOGGER.debug("Class::SowMasterManager, Method::getEngineModelShopDetails::EXIT");
		return response;
		
	}

	/**
	 * @return
	 */
	public ResponseTemplateDto<ServiceRenderedDto> getServices() {
		LOGGER.debug("Class::SowMasterManager, Method::getServices::ENTER");
		ResponseTemplateDto<ServiceRenderedDto> response = new ResponseTemplateDto<>();
		try{
			List<ServiceRendered> serviceRenderedList= serviceRenderedDAO.findByService();
			List<ServiceRenderedDto> serviceRenderedDtoList = entityBoMapper.map(serviceRenderedList,ServiceRenderedDto.class);
			response.setDataList(serviceRenderedDtoList);
			response.setOverallCount(new Long(serviceRenderedDtoList.size()));
			response.setSuccess(true);
			
		} catch (Exception e) {
			LOGGER.error("Issue while retrieving getServices", e);
			response.setStatusMsg("Issue while retrieving getServices");
			response.setSuccess(false);
		}
		LOGGER.debug("Class::SowMasterManager, Method::getServices::EXIT");
		return response;
		
	}
	
	/**
	 * @return
	 */
	public ResponseTemplateDto<RepairSupplierDto> getRepairSupplier() {
		LOGGER.debug("Class::SowMasterManager, Method::getRepairSupplier::ENTER");
		ResponseTemplateDto<RepairSupplierDto> response = new ResponseTemplateDto<>();
		try{
			List<RepairSupplier> repairSupplierList= repairSupplierDAO.findAllRS();
			List<RepairSupplierDto> repairSupplierDtoList = entityBoMapper.map(repairSupplierList,RepairSupplierDto.class);
			response.setDataList(repairSupplierDtoList);
				response.setOverallCount(new Long(repairSupplierDtoList.size()));
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Issue while retrieving getRepairSupplier", e);
			response.setStatusMsg("Issue while retrieving getRepairSupplier");
			response.setSuccess(false);
		}
		LOGGER.debug("Class::SowMasterManager, Method::getRepairSupplier::EXIT");
		return response;
	}
	
	/**
	 * @return
	 */
	public ResponseTemplateDto<EngineModuleDto> getEngineModule(String product) {
		LOGGER.debug("Class::SowMasterManager, Method::getEngineModule::ENTER");
		ResponseTemplateDto<EngineModuleDto> response = new ResponseTemplateDto<>();
		try{
			List<EngineModule> engineModuleList= engineModuleDAO.findEngineModule(product);
			List<EngineModuleDto> engineModuleDtoList=entityBoMapper.map(engineModuleList,EngineModuleDto.class);
			List<EngineLov> engineLovList= sowMasterMaterialDAO.getEngineLovList(product);
			updateEngineModuleDtoList(engineModuleDtoList,engineLovList);
			response.setDataList(engineModuleDtoList);
			response.setOverallCount(new Long(engineModuleDtoList.size()));
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Issue while retrieving getEngineModule", e);
			response.setStatusMsg("Issue while retrieving getEngineModule");
			response.setSuccess(false);
		}
		LOGGER.debug("Class::SowMasterManager, Method::getEngineModule::EXIT");
		return response;
		
	}
	
	/**
	 * @param engineModuleDtoList
	 * @param engineLovList
	 */
	private void updateEngineModuleDtoList(List<EngineModuleDto> engineModuleDtoList, List<EngineLov> engineLovList) {
		for(EngineLov engineLov : engineLovList) {
			for(EngineModuleDto engineModuleDto : engineModuleDtoList) {
				if(engineLov.getEngine().equalsIgnoreCase(engineModuleDto.getEngine())) {
					engineModuleDto.setEngineDisplayName(engineLov.getEngineDisplayName());
					engineModuleDto.setEngineDiscription(engineLov.getEngineDiscription());
				}
			}
			
		}
		
	}

	/**
	 * @param engine
	 * @return
	 */
	public ResponseTemplateDto<List<EngineOperationListDto>> getEngineOperationList(String engine,String product) {
		LOGGER.debug("Class::SowMasterManager, Method::getEngineOperationList::ENTER");
		ResponseTemplateDto<List<EngineOperationListDto>> response = new ResponseTemplateDto<>();
		try{
			List<EngineOperationList> engineOperationList = engineOperationListDAO.findEngineOperationList(engine,product);
			List<EngineOperationListDto> engineOperationDtoList=entityBoMapper.map(engineOperationList,EngineOperationListDto.class);
			response.setData(engineOperationDtoList);
			response.setSuccess(true);
		}catch(Exception e){
			LOGGER.error("Issue while retrieving getEngineOperationList", e);
			response.setStatusMsg("Issue while retrieving getEngineOperationList");
			response.setSuccess(false);
		}
		LOGGER.debug("Class::SowMasterManager, Method::getEngineOperationList::EXIT");
		return response;
		}

	/**
	 * @param engine
	 * @param module
	 * @return
	 */
	public ResponseTemplateDto<List<ModuleOperationListDto>> getModuleOperationList(String engine,String module,String product) {
		LOGGER.debug("Class::SowMasterManager, Method::getModuleOperationList::ENTER");
		ResponseTemplateDto<List<ModuleOperationListDto>> response = new ResponseTemplateDto<>();
		try{
			 List<ModuleOperationList> moduleOperationList=new ArrayList<>();
			 moduleOperationList= moduleOperationListDAO.findModuleOperationList(engine, module, product);
			List<ModuleOperationListDto> moduleOperationDtoList=entityBoMapper.map(moduleOperationList,ModuleOperationListDto.class);
					
			response.setData(moduleOperationDtoList);
			response.setSuccess(true);
		}catch (Exception e){
			LOGGER.error("Issue while retrieving getModuleOperationList", e);
			response.setStatusMsg("Issue while retrieving getModuleOperationList");
			response.setSuccess(false);
		}
		LOGGER.debug("Class::SowMasterManager, Method::getModuleOperationList::EXIT");
        return response;
		}
	
	
	/**
	 * @param product
	 * @param model
	 * @param engine
	 * @param newRepair
	 * @param docName
	 * @param sowStatus
	 * @return
	 */
	public ResponseTemplateDto<SowMasterMaterialDtoForUI> getMaterialByEngine(String product,String model,String engine, String newRepair,String docName, String sowStatus) {
		LOGGER.debug("Class::SowMasterManager, Method::getMaterialByEngine::ENTER");
		ResponseTemplateDto<SowMasterMaterialDtoForUI> response = new ResponseTemplateDto<>();
		try{
			List<SowMasterMaterial> sowMasterMaterialList= sowMasterMaterialDAO.findMaterialByEngine(product, model, engine,newRepair);
			List<SowMasterMaterialDto> sowMasterMaterialDtoList = entityBoMapper.map(sowMasterMaterialList,SowMasterMaterialDto.class);
			List<SowMasterMaterialDtoForUI> sowMasterMaterialDtoListForUI = convertToMaterialDtoListForUI(sowMasterMaterialDtoList);
			response.setDataList(sowMasterMaterialDtoListForUI);		
			response.setOverallCount(new Long(sowMasterMaterialDtoList.size()));
			response.setSuccess(true);
			
		} catch (Exception e) {
			LOGGER.error("Issue while retrieving getMaterialByEngine", e);
			response.setStatusMsg("Issue while retrieving getMaterialByEngine");
			response.setSuccess(false);
		}
		LOGGER.debug("Class::SowMasterManager, Method::getMaterialByEngine::EXIT");
		return response;
		
	}
	
	/**
	 * @param product
	 * @param model
	 * @param engine
	 * @param module
	 * @param newRepair
	 * @param docName
	 * @param sowStatus
	 * @return
	 */
	public ResponseTemplateDto<SowMasterMaterialDtoForUI> getMaterialByModule(String product,String model,String engine,String module,String newRepair,String docName, String sowStatus ) {
		LOGGER.debug("Class::SowMasterManager, Method::getMaterialByModule::ENTER");
		ResponseTemplateDto<SowMasterMaterialDtoForUI> response = new ResponseTemplateDto<>();
		try{
			List<SowMasterMaterial> sowMasterMaterialList= sowMasterMaterialDAO.findMaterialByModule(product, model,engine,module,newRepair);
			List<SowMasterMaterialDto> sowMasterMaterialDtoList = entityBoMapper.map(sowMasterMaterialList,SowMasterMaterialDto.class);
			List<SowMasterMaterialDtoForUI> sowMasterMaterialDtoListForUI = convertToMaterialDtoListForUI(sowMasterMaterialDtoList);
			response.setDataList(sowMasterMaterialDtoListForUI);
			response.setOverallCount(new Long(sowMasterMaterialDtoList.size()));
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Issue while retrieving getMaterialByModule", e);
			response.setStatusMsg("Issue while retrieving getMaterialByModule");
			response.setSuccess(false);
		}
		LOGGER.debug("Class::SowMasterManager, Method::getMaterialByModule::EXIT");
		return response;
		
	}
	
	/**
	 * @param sowMasterMaterialDtoList
	 * @return
	 */
	private List<SowMasterMaterialDtoForUI> convertToMaterialDtoListForUI(List<SowMasterMaterialDto> sowMasterMaterialDtoList) {
		List<SowMasterMaterialDtoForUI> returnList = new ArrayList<>(); 
		for(SowMasterMaterialDto sowMasterMaterialDto : sowMasterMaterialDtoList) {
			SowMasterMaterialDtoForUI sowMasterMaterialDtoForUI = new SowMasterMaterialDtoForUI();
			sowMasterMaterialDtoForUI.setBomQty(sowMasterMaterialDto.getBomQty());
			sowMasterMaterialDtoForUI.setEngine(sowMasterMaterialDto.getEngine());
			if(sowMasterMaterialDto.getFallOut() != null) {
				sowMasterMaterialDtoForUI.setFallOut(sowMasterMaterialDto.getFallOut());
			}
			sowMasterMaterialDtoForUI.setModel(sowMasterMaterialDto.getModel());
			sowMasterMaterialDtoForUI.setModule(sowMasterMaterialDto.getModule());
			sowMasterMaterialDtoForUI.setNomenclature(sowMasterMaterialDto.getNomenclature());
			sowMasterMaterialDtoForUI.setPartNumber(sowMasterMaterialDto.getDisplayInSowMaterialAs());
			sowMasterMaterialDtoForUI.setPriceCategory(sowMasterMaterialDto.getPriceCategory());
			sowMasterMaterialDtoForUI.setProduct(sowMasterMaterialDto.getProduct());
			sowMasterMaterialDtoForUI.setServiceRendered(sowMasterMaterialDto.getServiceRendered());
			sowMasterMaterialDtoForUI.setSowIndex(sowMasterMaterialDto.getSowIndex());
			returnList.add(sowMasterMaterialDtoForUI);
		}
		return returnList; 
	}


	
	/**
	 * @param tempMaterialsList
	 * @return
	 */
	/*private List<SowMasterMaterialDtoForUI> convertToMaterialDtoListForUIForTemp(List<MasterMaterialLovTemp> tempMaterialsList) {
		List<SowMasterMaterialDtoForUI> returnList = new ArrayList<>(); 
		for(MasterMaterialLovTemp sowMasterMaterialDto : tempMaterialsList) {
			SowMasterMaterialDtoForUI sowMasterMaterialDtoForUI = new SowMasterMaterialDtoForUI();
			sowMasterMaterialDtoForUI.setBomQty(sowMasterMaterialDto.getBomQty());
			sowMasterMaterialDtoForUI.setEngine(sowMasterMaterialDto.getEngine());
			if(sowMasterMaterialDto.getFallOut() != null) {
				sowMasterMaterialDtoForUI.setFallOut(sowMasterMaterialDto.getFallOut());
			}
			sowMasterMaterialDtoForUI.setModel(sowMasterMaterialDto.getModel());
			sowMasterMaterialDtoForUI.setModule(sowMasterMaterialDto.getModule());
			sowMasterMaterialDtoForUI.setNomenclature(sowMasterMaterialDto.getNomenclature());
			sowMasterMaterialDtoForUI.setPartNumber(sowMasterMaterialDto.getDisplayInSowMaterialAs());
			sowMasterMaterialDtoForUI.setPriceCategory(sowMasterMaterialDto.getPriceCategory());
			sowMasterMaterialDtoForUI.setProduct(sowMasterMaterialDto.getProduct());
			sowMasterMaterialDtoForUI.setServiceRendered(sowMasterMaterialDto.getServiceRendered());
			sowMasterMaterialDtoForUI.setSowIndex(sowMasterMaterialDto.getSowIndex());
			returnList.add(sowMasterMaterialDtoForUI);
		}
		return returnList; 
	}*/

	/**
	 * @param product
	 * @param model
	 * @param engine
	 * @param moduleList
	 * @param newRepair
	 * @return
	 */
	public ResponseTemplateDto<Map<String,List<SowMasterMaterialDtoForUI>>> getMaterialByModuleList(String product, String model,	String engine, List<String> moduleList, String newRepair) {
		LOGGER.debug("Class::SowMasterManager, Method::getMaterialByModuleList::ENTER");
		ResponseTemplateDto<Map<String,List<SowMasterMaterialDtoForUI>>> response = new ResponseTemplateDto<>();
		try{
			List<SowMasterMaterial> sowMasterMaterialList= sowMasterMaterialDAO.getMaterialByModuleList(product, model,engine,newRepair);
			List<SowMasterMaterialDto> sowMasterMaterialDtoList = entityBoMapper.map(sowMasterMaterialList,SowMasterMaterialDto.class);
			Map<String,List<SowMasterMaterialDtoForUI>> returnMap = prepareMaterialByModuleList(sowMasterMaterialDtoList,moduleList);
			response.setData(returnMap);
			response.setOverallCount(new Long(sowMasterMaterialDtoList.size()));
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Issue while retrieving getMaterialByModuleList", e);
			response.setStatusMsg("Issue while retrieving getMaterialByModuleList");
			response.setSuccess(false);
		}
		LOGGER.debug("Class::SowMasterManager, Method::getMaterialByModuleList::EXIT");
		return response;
	}

	/**
	 * @param sowMasterMaterialDtoList
	 * @param moduleList
	 * @return
	 */
	private Map<String, List<SowMasterMaterialDtoForUI>> prepareMaterialByModuleList(List<SowMasterMaterialDto> sowMasterMaterialDtoList, List<String> moduleList) {
		Map<String,List<SowMasterMaterialDtoForUI>> returnMap = new HashMap<>();
		Map<String,List<SowMasterMaterialDto>> sowMasterMaterialMap = new HashMap<>();
		for(SowMasterMaterialDto sowMasterMaterialDto : sowMasterMaterialDtoList) {
			for(String module : moduleList) {
				if(module.equalsIgnoreCase(sowMasterMaterialDto.getModule())) {
					if(sowMasterMaterialMap.get(module) != null) {
						List<SowMasterMaterialDto> materialList = sowMasterMaterialMap.get(module);
						materialList.add(sowMasterMaterialDto);
					}else{
						List<SowMasterMaterialDto> materialList = new ArrayList<>();
						materialList.add(sowMasterMaterialDto);
						sowMasterMaterialMap.put(module, materialList);
					}
				}
			}
		}
		Set<String> keySet = sowMasterMaterialMap.keySet();
		for(String str : keySet) {
			List<SowMasterMaterialDto> sowMasterMaterialList = sowMasterMaterialMap.get(str);
			returnMap.put(str, convertToMaterialDtoListForUI(sowMasterMaterialList));
		}
		return returnMap;
	}

	/**
	 * @return
	 */
	public ResponseTemplateDto<List<OpptyTypeLovDto>> getOpptyTypeList() {
		LOGGER.debug("Class::SowMasterManager, Method::getOpptyTypeList::ENTER");
		ResponseTemplateDto<List<OpptyTypeLovDto>> response = new ResponseTemplateDto<>();
		try{
			List<OpptyTypeLov> opptyTypeLovList= sowMasterMaterialDAO.getOpptyTypeList();
			List<OpptyTypeLovDto> opptyTypeLovDtoList = entityBoMapper.map(opptyTypeLovList,OpptyTypeLovDto.class);
			response.setData(opptyTypeLovDtoList);
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Issue while retrieving getOpptyTypeList", e);
			response.setStatusMsg("Issue while retrieving getOpptyTypeList");
			response.setSuccess(false);
		}
		LOGGER.debug("Class::SowMasterManager, Method::getOpptyTypeList::EXIT");
		return response;
	}

	/**
	 * @return
	 */
	public ResponseTemplateDto<List<ProposalTypeLovDto>> getProposalTypeList() {
		LOGGER.debug("Class::SowMasterManager, Method::getProposalTypeList::ENTER");
		ResponseTemplateDto<List<ProposalTypeLovDto>> response = new ResponseTemplateDto<>();
		try{
			List<ProposalTypeLov> opptyTypeLovList= sowMasterMaterialDAO.getProposalTypeList();
			List<ProposalTypeLovDto> opptyTypeLovDtoList = entityBoMapper.map(opptyTypeLovList,ProposalTypeLovDto.class);
			response.setData(opptyTypeLovDtoList);
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Issue while retrieving getProposalTypeList", e);
			response.setStatusMsg("Issue while retrieving getProposalTypeList");
			response.setSuccess(false);
		}
		LOGGER.debug("Class::SowMasterManager, Method::getProposalTypeList::EXIT");
		return response;
	}
	
	/**
	 * @param engineOperationListDto
	 * @return
	 */
	public ResponseTemplateDto<EngineOperationListDto> saveEngineOperationList(List<EngineOperationListDto> engineOperationListDto) {
		LOGGER.debug("Class::SowMasterManager, Method::saveEngineOperationList::ENTER");
		ResponseTemplateDto<EngineOperationListDto> response = new ResponseTemplateDto<>();
		try{
			List<EngineOperationList> engineOperationList =  entityBoMapper.map(engineOperationListDto, EngineOperationList.class);
			for(EngineOperationListDto engineOperationDto:engineOperationListDto){
				Object[] numOperationList = engineOperationListDAO.getNumOperation(engineOperationDto.getEngine(),engineOperationDto.getPlcProductType());
				if(isNumOperationExist(numOperationList, engineOperationDto.getNumOperation(),engineOperationDto.getEngine())) {
					LOGGER.error("Issue in saving the EngineOperationListDto as numOperation Value repeats");
					response.setSuccess(false);
					response.setStatusMsg("Issue in saving the EngineOperationListDto as numOperation Value repeats");
					return response;
					
				}
			}
			for(EngineOperationList engineOperation:engineOperationList){
				if(engineOperation.getId() == null) {		
					engineOperation=engineOperationListDAO.save(engineOperation);
				}else{
					engineOperation.setLastUpdateDate(new Date());
					engineOperation=engineOperationListDAO.update(engineOperation);
				}
			}
			engineOperationListDto=entityBoMapper.map(engineOperationList, EngineOperationListDto.class);
			response.setDataList(engineOperationListDto);
			response.setSuccess(true);
			response.setStatusMsg(SUCCESS);
		}catch (Exception e) {
			LOGGER.error("Issue in saving the EngineOperationList" , e);
			response.setSuccess(false);
			response.setStatusMsg("Issue in saving the EngineOperationList");
		}
		LOGGER.debug("Class::SowMasterManager, Method::saveEngineOperationList::EXIT");
		return response;
	}
	
	/**
	 * @param moduleOperationListDto
	 * @return
	 */
	public ResponseTemplateDto<ModuleOperationListDto> saveModuleOperationList(List<ModuleOperationListDto> moduleOperationListDto) {
		LOGGER.debug("Class::SowMasterManager, Method::saveModuleOperationList::ENTER");
		ResponseTemplateDto<ModuleOperationListDto> response = new ResponseTemplateDto<>();
		try{
			List<ModuleOperationList> moduleOperationList =  entityBoMapper.map(moduleOperationListDto, ModuleOperationList.class);
			for(ModuleOperationListDto moduleOperationDto:moduleOperationListDto){
				Object[] numOperationList = moduleOperationListDAO.getNumOperation(moduleOperationDto.getEngine(),moduleOperationDto.getModule(),moduleOperationDto.getPlcProductType());
				if(isNumOperationExist(numOperationList, moduleOperationDto.getNumOperation(),moduleOperationDto.getOperationType())) {
					LOGGER.error("Issue in saving the ModuleOperationListDto as numOperation Value repeats");
					response.setSuccess(false);
					response.setStatusMsg("Issue in saving the ModuleOperationListDto as numOperation Value repeats");
					return response;
					
				}
			}
			for(ModuleOperationList moduleOperation:moduleOperationList){
				if(moduleOperation.getId() == null) {	
					moduleOperation=moduleOperationListDAO.save(moduleOperation);
				}else{
					moduleOperation.setLastUpdateDate(new Date());
					moduleOperation=moduleOperationListDAO.update(moduleOperation);
				}
			}
			moduleOperationListDto= entityBoMapper.map(moduleOperationList, ModuleOperationListDto.class);
			response.setDataList(moduleOperationListDto);
			response.setSuccess(true);
			response.setStatusMsg(SUCCESS);
		}catch (Exception e) {
			LOGGER.error("Issue in saving the ModuleOperationList" , e);
			response.setSuccess(false);
			response.setStatusMsg("Issue in saving the ModuleOperationList");
		}
		LOGGER.debug("Class::SowMasterManager, Method::saveModuleOperationList::EXIT");
		return response;
	}

	/**
	 * @param numOperationList
	 * @param numOperation
	 * @param engine
	 * @return
	 */
	private boolean isNumOperationExist(Object[] numOperationList, Long numOperation,String engine) {
		for(Object obj : numOperationList) {		
			Object[] temp = (Object[])obj;	
			Long first = (Long) temp[0];	
			if(numOperation.longValue() == first.longValue()) {
				return true;
			}	
		}
		return false;
	}
	
	/**
	 * @param engine
	 * @param module
	 * @return
	 */
	public ResponseTemplateDto<Long> suggestedNextValueForModuleOperationList(String engine,String module,String product) {
		LOGGER.debug("Class::SowMasterManager, Method::suggestedNextValueForModuleOperationList::ENTER");
		ResponseTemplateDto<Long> response = new ResponseTemplateDto<>();
		Long numOperation=null;
		try{		
			numOperation=moduleOperationListDAO.getLatestNumOperation(engine,module,product);
			if(numOperation == null) {
				numOperation = (long)0;
			}
			response.setData(numOperation+10);
			response.setSuccess(true);
			response.setStatusMsg(SUCCESS);
		}catch(Exception e){
		  LOGGER.error("Issue in getting the suggestedNextValueForModuleOperationList" , e);
		  response.setSuccess(false);
		  response.setStatusMsg("Issue in getting the suggestedNextValueForModuleOperationList");
		 }
		LOGGER.debug("Class::SowMasterManager, Method::suggestedNextValueForModuleOperationList::Exit");
		return response;
	 }
	
	/**
	 * @param engine
	 * @return
	 */
	public ResponseTemplateDto<Long> suggestedNextValueForEngineOperationList(String engine,String product) {
		LOGGER.debug("Class::SowMasterManager, Method::suggestedNextValueForEngineOperationList::ENTER");
		ResponseTemplateDto<Long> response = new ResponseTemplateDto<>();
		Long numOperation=null;
		try{		
			numOperation=engineOperationListDAO.getLatestNumOperation(engine,product);
			if(numOperation == null) {
				numOperation = (long)0;
			}
			response.setData(numOperation+10);
			response.setSuccess(true);
			response.setStatusMsg(SUCCESS);
		}catch(Exception e){
		  LOGGER.error("Issue in getting the suggestedNextValueForEngineOperationList" , e);
		  response.setSuccess(false);
		  response.setStatusMsg("Issue in getting the suggestedNextValueForEngineOperationList");
		}
		LOGGER.debug("Class::SowMasterManager, Method::suggestedNextValueForEngineOperationList::Exit");
		return response;
	  }
	
	/**
	 * @return
	 */
	public ResponseTemplateDto<OperationTypeLovDto> getOperationTypeLov() {
		LOGGER.debug("Class::SowMasterManager, Method::getOperationTypeLov::ENTER");
		ResponseTemplateDto<OperationTypeLovDto> response = new ResponseTemplateDto<>();
		try{
			LOGGER.debug("Class::SowMasterManager, Method::getOperationTypeLov");
			List<OperationTypeLov> operationTypeLov= operationTypeLovDAO.findOperationTypeLov();
			List<OperationTypeLovDto> operationTypeLovDto = entityBoMapper.map(operationTypeLov,OperationTypeLovDto.class);				
			response.setDataList(operationTypeLovDto);
			response.setOverallCount(new Long(operationTypeLovDto.size()));
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Issue in retrieving Operation Type List", e);
			response.setStatusMsg("Issue in retrieving Operation Type List");
			response.setSuccess(false);
		}
		LOGGER.debug("Class::SowMasterManager, Method::getOperationTypeLov::EXIT");
		return response;
		
	}

	/**
	 * @param partNumber
	 * @param newRepair
	 * @param supplier
	 * @return
	 */
	public ResponseTemplateDto<ListPriceDto> getListPriceMaterialPriceDetails(String partNumber, String newRepair) {
		LOGGER.debug("Class::SowMasterManager, Method::getOperationTypeLov::ENTER");
		ResponseTemplateDto<ListPriceDto> response = new ResponseTemplateDto<>();
		try{
			List<ListPrice> listPriceList = listPriceDAO.getListPriceMaterialPriceDetails(partNumber, newRepair);
			ListPriceDto listPriceDto = listPriceList!=null && listPriceList.size() > 0 ? createListPriceDto(listPriceList,newRepair) : null;
			response.setData(listPriceDto);
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Issue in retrieving ListPriceMaterialPriceDetails for partNumber :: "+partNumber, e);
			response.setStatusMsg("Issue in retrieving Operation Type List");
			response.setSuccess(false);
		}
		LOGGER.debug("Class::SowMasterManager, Method::getOperationTypeLov::EXIT");
		return response;
	}
	
	/**
	 * @param priceListType
	 * @param supplierType
	 * @param supplier
	 * @param partNumberString
	 * @return
	 */
	public ResponseTemplateDto<List<ListPriceDto>> getPartMaterialList(String priceListType, String supplierType,String supplier,String partNumberString) {
		LOGGER.debug("Class::ListPriceMaterialUploadManager, Method::getPartNumberObjectList::ENTER");
		ResponseTemplateDto<List<ListPriceDto>> response = new ResponseTemplateDto<>();
		try{
			List<String> priceListTypeList = null;
			List<String> supplierTypeList = null;
			if(ALL.equalsIgnoreCase(priceListType)) {
				priceListTypeList = PRICE_LIST_TYPE;
			}else{
				priceListTypeList = new ArrayList<>(Arrays.asList(priceListType));
			}
			if(ALL.equalsIgnoreCase(supplierType)) {
				supplierTypeList = SUPPLIER_TYPE;
			}else{
				supplierTypeList = new ArrayList<>(Arrays.asList(supplierType));
			}
			List<ListPrice> listPriceList = null;
			partNumberString = partNumberString!= null ? partNumberString.toUpperCase() : "";
			if(ALL.equalsIgnoreCase(supplier)){
				listPriceList = listPriceDAO.getPartListWithOutSupplier(priceListTypeList,supplierTypeList,partNumberString);
			}else{
				listPriceList = listPriceDAO.getPartListWithSupplier(priceListTypeList,supplierTypeList,supplier,partNumberString);
			}
			List<ListPriceDto> partNumberDtoList = createListPriceDtoList(listPriceList);
			response.setSuccess(true);
			response.setData(partNumberDtoList);
		} catch (Exception e) {
			LOGGER.error("Error while getting getPartNumberList", e);
			response.setStatusMsg("Error while getting getPartNumberList");
			response.setSuccess(false);
		}
		LOGGER.debug("Class::ListPriceMaterialUploadManager, Method::getPartNumberList::EXIT");
		return response;
	}

	/**
	 * @param listPriceList
	 * @return
	 */
	private List<ListPriceDto> createListPriceDtoList(List<ListPrice> listPriceList) {
		List<ListPriceDto> returnList = new ArrayList<>();
		if(listPriceList != null && listPriceList.size() > 0) {
			Map<String,ListPriceDto> listPriceMap = createListPriceMap(listPriceList);
			returnList.addAll(listPriceMap.values());
		}
		return returnList;
	}

	/**
	 * @param listPriceList
	 * @return
	 */
	private Map<String, ListPriceDto> createListPriceMap(List<ListPrice> listPriceList) {
		Map<String, ListPriceDto> returnMap = new HashMap<>();
		for(ListPrice listPrice : listPriceList) {
			String partNumber = listPrice.getPartNumber();
			if(returnMap.get(partNumber) != null) {
				ListPriceDto listPriceDto = returnMap.get(partNumber);
				List<ListPriceServicesRenderedDto> serviceRenderedList = listPriceDto.getServiceRenderedList();
				ListPriceServicesRenderedDto listPriceServicesRenderedDto = new ListPriceServicesRenderedDto();
				listPriceServicesRenderedDto.setPriceListType(listPrice.getPriceListType());
				listPriceServicesRenderedDto.setServiceRendered(listPrice.getServiceRendered());
				listPriceServicesRenderedDto.setSupplier(listPrice.getSupplier());
				serviceRenderedList.add(listPriceServicesRenderedDto);
				ListPriceSuppliersDto listPriceSuppliersDto = new ListPriceSuppliersDto();
				listPriceSuppliersDto.setSupplier(listPrice.getSupplier());
				listPriceSuppliersDto.setSupplierType(listPrice.getSupplierType());
				listPriceSuppliersDto.setUnitCost(listPrice.getUnitCost());
				listPriceSuppliersDto.setUnitPrice(listPrice.getUnitPrice());
				listPriceSuppliersDto.setServiceRendered(listPrice.getServiceRendered());
				listPriceSuppliersDto.setPriceCategory(listPrice.getPriceCategory());
				List<ListPriceSuppliersDto> supplierList = listPriceDto.getSupplierList();
				supplierList.add(listPriceSuppliersDto);
				
			}else{
				ListPriceDto temp = new ListPriceDto();
				temp.setPartNumber(listPrice.getPartNumber());
				temp.setNomenclature(listPrice.getPartNumberDescription());
				List<ListPriceServicesRenderedDto> serviceRenderedList = new ArrayList<>(); 
				ListPriceServicesRenderedDto listPriceServicesRenderedDto = new ListPriceServicesRenderedDto();
				listPriceServicesRenderedDto.setPriceListType(listPrice.getPriceListType());
				listPriceServicesRenderedDto.setServiceRendered(listPrice.getServiceRendered());
				listPriceServicesRenderedDto.setSupplier(listPrice.getSupplier());
				serviceRenderedList.add(listPriceServicesRenderedDto);
				temp.setServiceRenderedList(serviceRenderedList);
				List<ListPriceSuppliersDto> supplierList = new ArrayList<>();  
				ListPriceSuppliersDto listPriceSuppliersDto = new ListPriceSuppliersDto();
				listPriceSuppliersDto.setSupplier(listPrice.getSupplier());
				listPriceSuppliersDto.setSupplierType(listPrice.getSupplierType());
				listPriceSuppliersDto.setUnitCost(listPrice.getUnitCost());
				listPriceSuppliersDto.setUnitPrice(listPrice.getUnitPrice());
				listPriceSuppliersDto.setServiceRendered(listPrice.getServiceRendered());
				listPriceSuppliersDto.setPriceCategory(listPrice.getPriceCategory());
				supplierList.add(listPriceSuppliersDto);
				temp.setSupplierList(supplierList);
				returnMap.put(partNumber, temp);
			}
		}
		return returnMap;
	}
	

	private ListPriceDto createListPriceDto(List<ListPrice> listPriceList, String newRepair) {
		ListPriceDto returnObj = new ListPriceDto();
		for(ListPrice temp :listPriceList) {
			returnObj.setPartNumber(temp.getPartNumber());
			returnObj.setNomenclature(temp.getPartNumberDescription());
			String supplier = temp.getSupplier();
			if(supplier != null && supplier.length() > 0) {
				ListPriceSuppliersDto listPriceSuppliersDto = new ListPriceSuppliersDto();
				listPriceSuppliersDto.setSupplier(supplier);
				listPriceSuppliersDto.setSupplierType(temp.getSupplierType());
				listPriceSuppliersDto.setUnitCost(temp.getUnitCost());
				listPriceSuppliersDto.setUnitPrice(temp.getUnitPrice());
				if("OSS".equalsIgnoreCase(newRepair)) {
					listPriceSuppliersDto.setServiceRendered(temp.getServiceRendered());
				}
				returnObj.getSupplierList().add(listPriceSuppliersDto);
			}
			String serviceRendered = temp.getServiceRendered();
			if(serviceRendered != null && serviceRendered.length() > 0) {
				ListPriceServicesRenderedDto listPriceServicesRenderedDto = new ListPriceServicesRenderedDto();
				listPriceServicesRenderedDto.setServiceRendered(serviceRendered);
				listPriceServicesRenderedDto.setPriceListType(temp.getPriceListType());
				if("OSS".equalsIgnoreCase(newRepair)) {
					listPriceServicesRenderedDto.setSupplier(temp.getSupplier());
				}
				returnObj.getServiceRenderedList().add(listPriceServicesRenderedDto);
			}
		}
		return returnObj;
	}
	
	public ResponseTemplateDto<List<StdSbLovDto>> getStdSbLov() {
		LOGGER.debug("Class::SowMasterManager, Method::getStdSbLov::ENTER");
		ResponseTemplateDto<List<StdSbLovDto>> response = new ResponseTemplateDto<>();
		try{
			LOGGER.debug("Class::SowMasterManager, Method::getStdSbLov");
			List<StdSbLov> stdSbLovList= stdSbLovDAO.getStdSbLov();
			List<StdSbLovDto> stdSbLovDtoList = entityBoMapper.map(stdSbLovList,StdSbLovDto.class);				
			LOGGER.debug("Class::SowMasterManager, Method::getStdSbLov");
			response.setData(stdSbLovDtoList);
			response.setOverallCount(new Long(stdSbLovDtoList.size()));
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Error retrieving StdSbLov ");
			response.setStatusMsg("Error retrieving StdSbLov");
			response.setSuccess(false);
		}
		LOGGER.debug("Class::SowMasterManager, Method::getStdSbLov::EXIT");
		return response;
		
	}

	public ResponseTemplateDto<List<ProductLovDto>> getProductList() {
		LOGGER.debug("Class::SowMasterManager, Method::getProductList::ENTER");
		ResponseTemplateDto<List<ProductLovDto>> response = new ResponseTemplateDto<>();
		try{
			List<ProductLov> productList= sowMasterMaterialDAO.getProductList();
			List<ProductLovDto> productDtoList = entityBoMapper.map(productList,ProductLovDto.class);				
			response.setData(productDtoList);
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Error retrieving StdSbLov ");
			response.setStatusMsg("Error retrieving ProductList");
			response.setSuccess(false);
		}
		LOGGER.debug("Class::SowMasterManager, Method::getProductList::EXIT");
		return response;
	}

}

