package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

public class EngineOperationHrsLovDto  extends AuditDataDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3192264414560108174L;
	private Long id;
	private String model;
	private float operationHrs;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public float getOperationHrs() {
		return operationHrs;
	}
	public void setOperationHrs(float operationHrs) {
		this.operationHrs = operationHrs;
	}
	
	
}
