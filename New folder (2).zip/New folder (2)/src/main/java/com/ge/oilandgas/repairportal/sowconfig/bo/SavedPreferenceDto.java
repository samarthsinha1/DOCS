package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;



public class SavedPreferenceDto implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
    private Long ssoId;
	private String savedData;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getSsoId() {
		return ssoId;
	}
	public void setSsoId(Long ssoId) {
		this.ssoId = ssoId;
	}
	public String getSavedData() {
		return savedData;
	}
	public void setSavedData(String savedData) {
		this.savedData = savedData;
	}
	
	
	
}
