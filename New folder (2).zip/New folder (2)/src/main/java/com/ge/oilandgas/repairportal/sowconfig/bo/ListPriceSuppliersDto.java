package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

public class ListPriceSuppliersDto implements Serializable  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	 private String supplierType;
	 private String supplier;	 
	 private float unitCost;	 
	 private String unitCostCurrency;
	 private float unitPrice;
	 private String unitPriceCurrency;
	 private String serviceRendered;  
	 private String priceCategory;
	 
	 public String getSupplierType() {
			return supplierType;
		}

		public void setSupplierType(String supplierType) {
			this.supplierType = supplierType;
		}

		public String getSupplier() {
			return supplier;
		}

		public void setSupplier(String supplier) {
			this.supplier = supplier;
		}
		public float getUnitCost() {
			return unitCost;
		}

		public void setUnitCost(float unitCost) {
			this.unitCost = unitCost;
		}

		public String getUnitCostCurrency() {
			return unitCostCurrency;
		}

		public void setUnitCostCurrency(String unitCostCurrency) {
			this.unitCostCurrency = unitCostCurrency;
		}

		public float getUnitPrice() {
			return unitPrice;
		}

		public void setUnitPrice(float unitPrice) {
			this.unitPrice = unitPrice;
		}

		public String getUnitPriceCurrency() {
			return unitPriceCurrency;
		}

		public void setUnitPriceCurrency(String unitPriceCurrency) {
			this.unitPriceCurrency = unitPriceCurrency;
		}

		public String getServiceRendered() {
			return serviceRendered;
		}

		public void setServiceRendered(String serviceRendered) {
			this.serviceRendered = serviceRendered;
		}

		public static long getSerialversionuid() {
			return serialVersionUID;
		}

		public String getPriceCategory() {
			return priceCategory;
		}

		public void setPriceCategory(String priceCategory) {
			this.priceCategory = priceCategory;
		}

		
}
