package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name= "ong_sowcfg_trx_engine_material_repair")
public class EngineMaterialRepair extends GenericEntity<Long>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SEQ_ENGINE_MATERIALS_REPAIR", sequenceName="ong_sowcfg_trx_engine_material_repair_sequence_id")
	@GeneratedValue(generator="SEQ_ENGINE_MATERIALS_REPAIR", strategy=GenerationType.SEQUENCE)
	@Column(name="MATERIAL_SEQUENCE_ID")
	private Long id;
	
	@Column(name="BOM_QUANTITY")
	private int bomQuantity;
	
	@Column(name="service_rendered")
	private String serviceRendered;

	@Column(name="NOMENCLATURE")
	private String nomenclature;
	
	@Column(name="PART_NUMBER")
	private String partNumber;
	
	@Column(name="QUANTITY")
	private int quantity;
	
	@Column(name="MATERIAL_TYPE")
	private String materialType;
	
	@Column(name="SUPPLIER")
	private String supplier;
	
	@Column(name="SUPPLIER_TYPE")
	private String supplierType;
	
	@Column(name="cost")
	private float cost;
	
	@Column(name="PRICE")
	private float price;
	
	@Column(name="quote_price")
	private float quotePrice;
	
	@Column(name="base_quote_price")
	private float baseQuotePrice;
	
	@Transient
	private String priceCategory;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getBomQuantity() {
		return bomQuantity;
	}

	public void setBomQuantity(int bomQuantity) {
		this.bomQuantity = bomQuantity;
	}

	public String getServiceRendered() {
		return serviceRendered;
	}

	public void setServiceRendered(String serviceRendered) {
		this.serviceRendered = serviceRendered;
	}

	public String getNomenclature() {
		return nomenclature;
	}

	public void setNomenclature(String nomenclature) {
		this.nomenclature = nomenclature;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getMaterialType() {
		return materialType;
	}

	public void setMaterialType(String materialType) {
		this.materialType = materialType;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public float getCost() {
		return cost;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public float getQuotePrice() {
		return quotePrice;
	}

	public void setQuotePrice(float quotePrice) {
		this.quotePrice = quotePrice;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getPriceCategory() {
		return priceCategory;
	}

	public void setPriceCategory(String priceCategory) {
		this.priceCategory = priceCategory;
	}

	public float getBaseQuotePrice() {
		return baseQuotePrice;
	}

	public void setBaseQuotePrice(float baseQuotePrice) {
		this.baseQuotePrice = baseQuotePrice;
	}

	public String getSupplierType() {
		return supplierType;
	}

	public void setSupplierType(String supplierType) {
		this.supplierType = supplierType;
	}
	
}
