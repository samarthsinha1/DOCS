package com.ge.oilandgas.repairportal.sowconfig.entity;



import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name= "ong_sowcfg_trx_service_bulletin")
public class ServiceBulletins extends GenericEntity<Long> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SEQ_BULLETIN", sequenceName="ong_sowcfg_trx_service_bulletin_sequence_id")
	@GeneratedValue(generator="SEQ_BULLETIN", strategy=GenerationType.SEQUENCE)
	@Column(name="BULLETIN_SEQUENCE_ID")
	private Long id;
	
	@Column(name="sb_implementation_date")
	private Date sbImplementationDate;
	
	@Column(name="sb_description")
	private String sbDescription;
	
	@Column(name="price")
	private float price;
	
	@Column(name="checked")
	private String serviceBulletinChecked;
	
	@Column(name="cost")
	private float cost;
	
	@Column(name="base_quote_price")
	private float baseQuotePrice;

	@Column(name="category")
	private String category;
	
	@Column(name="is_new_SB_flag")
	private String newSBFlag;
	
	@Column(name="info_sequence_id")
	private Long infoSequenceId;
	
	public Date getSbImplementationDate() {
		return sbImplementationDate;
	}

	public void setSbImplementationDate(Date sbImplementationDate) {
		this.sbImplementationDate = sbImplementationDate;
	}

	public String getSbDescription() {
		return sbDescription;
	}

	public void setSbDescription(String sbDescription) {
		this.sbDescription = sbDescription;
	}
	
	
	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	@Override
	public Long getId() {
		return id;
	}

	@Override
	public void setId(Long id) {
		this.id=id;
		
	}

	public String getServiceBulletinChecked() {
		return serviceBulletinChecked;
	}

	public void setServiceBulletinChecked(String serviceBulletinChecked) {
		this.serviceBulletinChecked = serviceBulletinChecked;
	}

	public float getCost() {
		return cost;
	}

	public void setCost(float cost) {
		this.cost = cost;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public float getBaseQuotePrice() {
		return baseQuotePrice;
	}

	public void setBaseQuotePrice(float baseQuotePrice) {
		this.baseQuotePrice = baseQuotePrice;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getNewSBFlag() {
		return newSBFlag;
	}

	public void setNewSBFlag(String newSBFlag) {
		this.newSBFlag = newSBFlag;
	}

	public Long getInfoSequenceId() {
		return infoSequenceId;
	}

	public void setInfoSequenceId(Long infoSequenceId) {
		this.infoSequenceId = infoSequenceId;
	}

}
