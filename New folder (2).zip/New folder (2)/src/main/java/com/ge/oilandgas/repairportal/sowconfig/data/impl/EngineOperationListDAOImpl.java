package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.oilandgas.repairportal.sowconfig.data.EngineOperationListDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.EngineOperationListRepository;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineOperationList;

@Component
public class EngineOperationListDAOImpl  extends GenericCrudDAOImpl<EngineOperationList, Long> implements EngineOperationListDAO{
	
	@Autowired
	private EngineOperationListRepository engineOperationListRepository;
	
	  public EngineOperationListDAOImpl(EngineOperationListRepository engineOperationListRepository) {
	        this.engineOperationListRepository = engineOperationListRepository;
	    }
	  
	  public EngineOperationListDAOImpl() {
	       super();
	    }


	  @SuppressWarnings("unchecked")		
	    public EngineOperationListRepository getRepository() {
	        return engineOperationListRepository;
	    }

	@Override
	public List<EngineOperationList> findEngineOperationList(String engine,String product) {	
		return engineOperationListRepository.findEngineOperationList(engine,product);
	}

	public Long getLatestNumOperation(String engine,String product){
		return engineOperationListRepository.getLatestNumOperation(engine,product);
	}
	
	
	public Object[] getNumOperation(String engine,String product) {
		return engineOperationListRepository.getNumOperation(engine,product);
	}

	@Override
	public List<EngineOperationList> findAllProductOperations(String product) {
		return engineOperationListRepository.findAllProductOperations(product);
	}
	
	
}
