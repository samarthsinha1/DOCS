package com.ge.oilandgas.repairportal.sowconfig.manager;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.oilandgas.repairportal.sowconfig.bo.ServiceBulletinsDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;
import com.ge.oilandgas.repairportal.sowconfig.common.EntityBoMapper;
import com.ge.oilandgas.repairportal.sowconfig.data.ServiceBulletinsDAO;
import com.ge.oilandgas.repairportal.sowconfig.entity.ServiceBulletins;

@Service
public class ServiceBulletinsManager {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommercialViewManager.class);
	private EntityBoMapper entityBoMapper;
	private ServiceBulletinsDAO serviceBulletinsDAO;
		
	@Autowired
	public ServiceBulletinsManager(EntityBoMapper entityBoMapper, ServiceBulletinsDAO serviceBulletinsDAO) {
		this.entityBoMapper = entityBoMapper;
		this.serviceBulletinsDAO = serviceBulletinsDAO;	
	}

	/**
	 * @param id
	 * @return
	 */
	public ResponseTemplateDto<ServiceBulletinsDto> getServiceBulletinsById(Long id) {
		LOGGER.debug("Class::ServiceBulletinsManager, Method::getServiceBulletinsByEngineInfoId::ENTER");
		ResponseTemplateDto<ServiceBulletinsDto> response = new ResponseTemplateDto<>();
		try{
			LOGGER.debug("Class::ServiceBulletinsManager, Method::getServiceBulletinsByEngineInfoId::id"+id);
			List<ServiceBulletins> serviceBulletinsList= serviceBulletinsDAO.findServiceBulletinsById(id);
			List<ServiceBulletinsDto> serviceBulletinsDtoList = entityBoMapper.map(serviceBulletinsList,ServiceBulletinsDto.class);				
			response.setDataList(serviceBulletinsDtoList);
			response.setOverallCount(new Long(serviceBulletinsDtoList.size()));
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Issue in retrieving Service Bulletins by id", e);
			response.setStatusMsg("Issue in retrieving Service Bulletins by id");
			response.setSuccess(false);
		}
		LOGGER.debug("Class::ServiceBulletinsManager, Method::getServiceBulletinsByEngineInfoId::EXIT");
		return response;
		
	}
	
	
	/**
	 * @param serviceBulletinsDto
	 * @return
	 */
	public ResponseTemplateDto<ServiceBulletinsDto> saveUpdateServiceBulletins(ServiceBulletinsDto serviceBulletinsDto) {
		LOGGER.debug("Class::ServiceBulletinsManager, Method::saveUpdateServiceBulletins::ENTER");
		ResponseTemplateDto<ServiceBulletinsDto> response = new ResponseTemplateDto<>();
		try{
			ServiceBulletins serviceBulletins =  entityBoMapper.map(serviceBulletinsDto, ServiceBulletins.class);
			if(serviceBulletins.getId() == null) {
				serviceBulletins=serviceBulletinsDAO.save(serviceBulletins);
			}else{
				serviceBulletins.setLastUpdateDate(new Date());
				serviceBulletins=serviceBulletinsDAO.update(serviceBulletins);
			}
			serviceBulletinsDto=entityBoMapper.map(serviceBulletins, ServiceBulletinsDto.class);
			response.setData(serviceBulletinsDto);
			response.setSuccess(true);
			response.setStatusMsg("Success");
		}catch (Exception e) {
			LOGGER.error("Issue in saving the service bulletins" , e);
			response.setSuccess(false);
			response.setStatusMsg("Issue in saving the service bulletins");
		}
		LOGGER.debug("Class::ServiceBulletinsManager, Method::saveUpdateServiceBulletins::EXIT");
		return response;
	}

	
	/**
	 * @param id
	 * @return
	 */
	public ResponseTemplateDto<ServiceBulletinsDto> deleteServiceBulletins(Long id) {
		LOGGER.debug("Class::ServiceBulletinsManager, Method::deleteServiceBulletins::ENTER");
		ResponseTemplateDto<ServiceBulletinsDto> response = new ResponseTemplateDto<>();
		try{
			ServiceBulletins serviceBulletins=serviceBulletinsDAO.delete(id);
			ServiceBulletinsDto serviceBulletinsDto=entityBoMapper.map(serviceBulletins, ServiceBulletinsDto.class);
			serviceBulletins.setLastUpdateDate(new Date());
			response.setData(serviceBulletinsDto);
			response.setSuccess(true);
			response.setStatusMsg("Success");
		}catch (Exception e) {
			LOGGER.error("Issue in deleting the service bulletins" , e);
			response.setSuccess(false);
			response.setStatusMsg("Issue in deleting the service bulletins");
		}
		LOGGER.debug("Class::ServiceBulletinsManager, Method::deleteServiceBulletins::EXIT");
		return response;
	}
	
	/**
	 * @param sbNumber
	 * @return
	 */
	public ResponseTemplateDto<ServiceBulletinsDto> findServiceBulletinsByNumber(String sbNumber){
		LOGGER.debug("Class::ServiceBulletinsManager, Method::findServiceBulletinsByNumber::ENTER");
		ResponseTemplateDto<ServiceBulletinsDto> response = new ResponseTemplateDto<>();
		try{
			LOGGER.debug("Class::ServiceBulletinsManager, Method::findServiceBulletinsByNumber::sbNumber"+sbNumber);
			
			//List<ServiceBulletins> serviceBulletinsList= serviceBulletinsDAO.findServiceBulletinsById(sbNumber);
			List<ServiceBulletins> serviceBulletinsList= findServiceBulletinsByNumberMockup(sbNumber);
			
			List<ServiceBulletinsDto> serviceBulletinsDtoList = entityBoMapper.map(serviceBulletinsList,ServiceBulletinsDto.class);				
			response.setDataList(serviceBulletinsDtoList);
			response.setOverallCount(new Long(serviceBulletinsDtoList.size()));
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Issue in finding Service Bulletins by sbNumber", e);
			response.setStatusMsg("Issue in finding Service Bulletins by sbNumber");
			response.setSuccess(false);
		}
		LOGGER.debug("Class::ServiceBulletinsManager, Method::findServiceBulletinsByNumber::EXIT");
		return response;
	}
	
	private List<ServiceBulletins> findServiceBulletinsByNumberMockup(String sbNumber){
		List<ServiceBulletins> serviceBulletinsAllList= new LinkedList<ServiceBulletins>();
		List<ServiceBulletins> serviceBulletinsFindList= new LinkedList<ServiceBulletins>();
		
		//carico la lista serviceBulletinsAllList
		ServiceBulletins sb1= new ServiceBulletins();
		sb1.setId(2418L);
		sb1.setSbDescription("SB 2418");
		sb1.setCategory("Category 1");
		serviceBulletinsAllList.add(sb1);
		
		ServiceBulletins sb2= new ServiceBulletins();
		sb2.setId(9501L);
		sb2.setSbDescription("SB 9501");
		sb2.setCategory("Category 2");
		serviceBulletinsAllList.add(sb2);
		
		//ricerca dei risultati e caricamento in serviceBulletinsFindList
		for (ServiceBulletins sb : serviceBulletinsAllList) {
			if(sb.getSbDescription().contains(sbNumber)) {
				//sb.getId().toString().contains(sbNumber)
				serviceBulletinsFindList.add(sb);
			}
		}
		return serviceBulletinsFindList;
	}
}
