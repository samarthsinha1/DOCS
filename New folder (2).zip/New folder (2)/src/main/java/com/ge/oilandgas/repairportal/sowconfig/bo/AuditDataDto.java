package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;
import java.util.Date;

public class AuditDataDto implements Serializable {
	
	/**
	 * Audit data
	 */
	private static final long serialVersionUID = 1L;
	private Integer createdBy;
	private Integer lastUpdatedBy;
	private Date creationDate;
	private Date lastUpdateDate;
	public Integer getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Integer createdBy) {
		this.createdBy = createdBy;
	}
	public Integer getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(Integer lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public Date getLastUpdateDate() {
		return lastUpdateDate;
	}
	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
	
	
	
}
