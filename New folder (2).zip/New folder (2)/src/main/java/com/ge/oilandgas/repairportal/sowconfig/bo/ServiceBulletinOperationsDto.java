package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

public class ServiceBulletinOperationsDto implements Serializable{

	private Long operationsId;
	private Long bulletinSeqId;
	private String operationsName;
	private Long labourHours;
	private Float labourCost;
	private Float labourPrice;
	private Float labourQuotePrice;
	private String nonStandardOperation;
	private String description;
	public Long getOperationsId() {
		return operationsId;
	}
	public void setOperationsId(Long operationsId) {
		this.operationsId = operationsId;
	}
	public Long getBulletinSeqId() {
		return bulletinSeqId;
	}
	public void setBulletinSeqId(Long bulletinSeqId) {
		this.bulletinSeqId = bulletinSeqId;
	}
	public String getOperationsName() {
		return operationsName;
	}
	public void setOperationsName(String operationsName) {
		this.operationsName = operationsName;
	}
	public Long getLabourHours() {
		return labourHours;
	}
	public void setLabourHours(Long labourHours) {
		this.labourHours = labourHours;
	}
	public Float getLabourCost() {
		return labourCost;
	}
	public void setLabourCost(Float labourCost) {
		this.labourCost = labourCost;
	}
	public Float getLabourPrice() {
		return labourPrice;
	}
	public void setLabourPrice(Float labourPrice) {
		this.labourPrice = labourPrice;
	}
	public Float getLabourQuotePrice() {
		return labourQuotePrice;
	}
	public void setLabourQuotePrice(Float labourQuotePrice) {
		this.labourQuotePrice = labourQuotePrice;
	}
	public String getNonStandardOperation() {
		return nonStandardOperation;
	}
	public void setNonStandardOperation(String nonStandardOperation) {
		this.nonStandardOperation = nonStandardOperation;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "ServiceBulletinOperationsDto [operationsId=" + operationsId + ", bulletinSeqId=" + bulletinSeqId
				+ ", operationsName=" + operationsName + ", labourHours=" + labourHours + ", labourCost=" + labourCost
				+ ", labourPrice=" + labourPrice + ", labourQuotePrice=" + labourQuotePrice + ", nonStandardOperation="
				+ nonStandardOperation + ", description=" + description + "]";
	}
	
	
	
}
