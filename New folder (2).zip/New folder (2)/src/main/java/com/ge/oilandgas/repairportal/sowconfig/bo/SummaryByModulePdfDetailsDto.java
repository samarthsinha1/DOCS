package com.ge.oilandgas.repairportal.sowconfig.bo;

public class SummaryByModulePdfDetailsDto {

	private String modules;
	private String fallOut;
	private String labor;
	private String materials;
	private String specialServices;	
	private String totalPrice;
	public String getModules() {
		return modules;
	}
	public void setModules(String modules) {
		this.modules = modules;
	}
	public String getFallOut() {
		return fallOut;
	}
	public void setFallOut(String fallOut) {
		this.fallOut = fallOut;
	}
	public String getLabor() {
		return labor;
	}
	public void setLabor(String labor) {
		this.labor = labor;
	}
	public String getMaterials() {
		return materials;
	}
	public void setMaterials(String materials) {
		this.materials = materials;
	}
	public String getSpecialServices() {
		return specialServices;
	}
	public void setSpecialServices(String specialServices) {
		this.specialServices = specialServices;
	}
	public String getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(String totalPrice) {
		this.totalPrice = totalPrice;
	}

	
}
