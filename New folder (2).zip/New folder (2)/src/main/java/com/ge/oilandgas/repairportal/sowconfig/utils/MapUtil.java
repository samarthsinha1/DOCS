package com.ge.oilandgas.repairportal.sowconfig.utils;

import java.io.IOException;
import java.util.Arrays;

import java.util.Map;

import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig.Feature;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

public class MapUtil {
	
	public static MultivaluedMap<String, String> multiValueMap(Map<String, String[]> map) {
		MultivaluedMap<String, String> multiValuedMap = new MultivaluedHashMap<>();
		if (map != null){
			for (Map.Entry<String, String[]> e : map.entrySet()) {
				multiValuedMap.put(e.getKey(), Arrays.asList(e.getValue()));
	    	}
    	}
		return multiValuedMap;
	}
	
	/**
	 * Parses an string into map of String, List<String>
	 * 
	 * @param mapString: The format of the string is <b>"key1:value1;key2:value2;key3:value3,value4"<b>.
	 * <br>
	 * If either key or values is missing, then this key pair is not put into map.
	 * @return
	 */
	public static MultivaluedMap<String, String> parseAsMap(String mapString) {
		MultivaluedMap<String, String> map = new MultivaluedHashMap<>();
		
		if (mapString != null && mapString.length() > 0) {
			String [] entries = mapString.split(";");
			if (entries.length > 0) {
				for (String entry : entries) {
					String[] entryPair= entry.split(":");
					if (entryPair.length == 2){
						String key = entryPair[0];
						String value = entryPair[1];
						if (key.trim() != null && key.trim().length() > 0
								&& value != null && value.trim().length() > 0) {
							if (value.indexOf(',') > 0) {
								map.put(key, Arrays.asList(value.split(",")));
							}else{
								map.putSingle(key, value);
							}
						}
					}
				}
			}
		}
		return map;
	}
	
	
	public static String marshall(Map<?, ?> ruleMap) throws IOException{
		String jsonRule = "{}";
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationConfig(mapper.getSerializationConfig().withSerializationInclusion(Inclusion.NON_DEFAULT));
		mapper.enable(Feature.INDENT_OUTPUT);
		jsonRule = mapper.writeValueAsString(ruleMap);
		return jsonRule;
	}
}
