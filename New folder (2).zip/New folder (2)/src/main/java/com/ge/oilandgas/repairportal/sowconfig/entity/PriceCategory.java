package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name= "ong_sowcfg_trx_new_price_category")

public class PriceCategory extends GenericEntity<Long>{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Id
	@SequenceGenerator(name="SEQ_PriceCategory", sequenceName="ong_sowcfg_trx_new_price_category_sequence_id")
	@GeneratedValue(generator="SEQ_PriceCategory", strategy=GenerationType.SEQUENCE)
	@Column(name="price_category_id")
	private Long id;
	
	@Column(name="price_category_name")
	private String priceCategoryName;	
	
	@Column(name="price_category_total_cost")
	private Float priceCategoryTotalCost;
	
	@Column(name="price_category_quote_price")
	private Float priceCategoryQuotePrice;
	
	@Column(name="price_category_cm")
	private Float priceCategoryCm;
	
	@Column(name="price_category_cm_percentage")
	private Float priceCategoryCmPercentage;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPriceCategoryName() {
		return priceCategoryName;
	}

	public void setPriceCategoryName(String priceCategoryName) {
		this.priceCategoryName = priceCategoryName;
	}

	public Float getPriceCategoryTotalCost() {
		return priceCategoryTotalCost;
	}

	public void setPriceCategoryTotalCost(Float priceCategoryTotalCost) {
		this.priceCategoryTotalCost = priceCategoryTotalCost;
	}

	public Float getPriceCategoryQuotePrice() {
		return priceCategoryQuotePrice;
	}

	public void setPriceCategoryQuotePrice(Float priceCategoryQuotePrice) {
		this.priceCategoryQuotePrice = priceCategoryQuotePrice;
	}

	public Float getPriceCategoryCm() {
		return priceCategoryCm;
	}

	public void setPriceCategoryCm(Float priceCategoryCm) {
		this.priceCategoryCm = priceCategoryCm;
	}

	public Float getPriceCategoryCmPercentage() {
		return priceCategoryCmPercentage;
	}

	public void setPriceCategoryCmPercentage(Float priceCategoryCmPercentage) {
		this.priceCategoryCmPercentage = priceCategoryCmPercentage;
	}

	
}
