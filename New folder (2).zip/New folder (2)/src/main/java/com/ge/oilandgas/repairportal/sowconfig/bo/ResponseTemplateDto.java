/*
 * Copyright (c) 2014 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.util.List;

public class ResponseTemplateDto <T>  extends ResponseStatusDto {
	private List<T> dataList;
	private Long overallCount;
	private T data;
	
				
	public List<T> getDataList() {
		return this.dataList;
	}
	
	public void setDataList(List<T> dataDtoList) {
		this.dataList = dataDtoList;
	}

	public T getData() {
		return this.data;
	}

	public void setData(T data) {
		this.data = data;
	}

	public Long getOverallCount() {
		return overallCount;
	}

	public void setOverallCount(Long overallCount) {
		this.overallCount = overallCount;
	}
}
