package com.ge.oilandgas.repairportal.sowconfig.data;

import java.util.List;
import com.ge.oilandgas.repairportal.sowconfig.entity.ModuleOperationList;

public interface ModuleOperationListDAO  extends GenericDAO<ModuleOperationList, Long> {
	
	List<ModuleOperationList> findModuleOperationList(String engine,String module,String product);
	
	Long getLatestNumOperation(String engine,String module,String product);
	
	Object[] getNumOperation(String engine,String module,String product);

	List<ModuleOperationList> findAllProductOperations(String product);

}
