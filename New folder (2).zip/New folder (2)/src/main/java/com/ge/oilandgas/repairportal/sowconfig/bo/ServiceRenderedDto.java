package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

public class ServiceRenderedDto implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String serviceRendered;
	private Long unitPrice;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	public String getServiceRendered() {
		return serviceRendered;
	}
	public void setServiceRendered(String serviceRendered) {
		this.serviceRendered = serviceRendered;
	}
	public Long getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(Long unitPrice) {
		this.unitPrice = unitPrice;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}