package com.ge.oilandgas.repairportal.sowconfig.service.impl;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ge.oilandgas.repairportal.sowconfig.data.impl.CommercialViewDAOImpl;
import com.ge.oilandgas.repairportal.sowconfig.entity.CommercialView;
import com.ge.oilandgas.repairportal.sowconfig.service.api.TestService;



@RequestMapping("/test")
@RestController
public class TestServiceImpl implements TestService {
	
	@Autowired
	CommercialViewDAOImpl commercialViewDAOImpl;

	private static final Logger LOGGER = LoggerFactory.getLogger(TestServiceImpl.class);
	
	@RequestMapping("/isalive")
	public CommercialView isAlive() {
		
		LOGGER.error("PROVA ERROR");
		LOGGER.warn("PROVA WARN");
		LOGGER.info("PROVA INFO");
		LOGGER.debug("Prova DEBUG");	
		
		
		CommercialView result =  new CommercialView();
		
		List<CommercialView> results = commercialViewDAOImpl.getRepository().findAll();
		
		if(results != null && results.size() != 0) {
			result = results.get(0);
		} else {
			LOGGER.error("Nessun dato recuperato procedo coi default");
			result.setCreatedBy(1);
			result.setCreatedDate(new Date());
			result.setDepotTestCm(Float.valueOf("12"));
		}
		
		
		return result;
		
	}

}
