package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

public class StdSbRulesLovDto extends AuditDataDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	private String sowName;
	private String sbRuleColor;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getSowName() {
		return sowName;
	}
	public void setSowName(String sowName) {
		this.sowName = sowName;
	}
	public String getSbRuleColor() {
		return sbRuleColor;
	}
	public void setSbRuleColor(String sbRuleColor) {
		this.sbRuleColor = sbRuleColor;
	}

}
