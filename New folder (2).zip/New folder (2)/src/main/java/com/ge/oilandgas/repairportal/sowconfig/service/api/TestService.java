package com.ge.oilandgas.repairportal.sowconfig.service.api;

import com.ge.oilandgas.repairportal.sowconfig.entity.CommercialView;

public interface TestService {
	
	CommercialView isAlive();

}
