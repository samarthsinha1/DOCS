/*
 * Copyright (c) 2014 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */
package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.IteratorUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Pageable;

import com.ge.oilandgas.repairportal.sowconfig.data.GenericDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.GenericCrudRepository;
import com.ge.oilandgas.repairportal.sowconfig.entity.GenericEntity;

/**
 * Created by 502776087 on 09/04/17.
 */
public abstract class GenericCrudDAOImpl<T extends GenericEntity<ID>, ID extends Serializable> implements GenericDAO<T, ID> {


    @Override
    public T save(T entity) {
        resolveChildReferences(entity);
        T savedEntity = getRepository().save(entity);
        return savedEntity;
    }

    @Override
    public T findOne(ID id) {
        T entity = getRepository().findOne(id);
        return entity;
    }

    @SuppressWarnings("unchecked")
	@Override
    public List<T> findAll() {
        Iterable<T> entityList = getRepository().findAll();
        return IteratorUtils.toList(entityList.iterator());
    }

    @SuppressWarnings("unchecked")
	@Override
    public List<T> findAll(Pageable pageable) {
        Iterable<T> entityList = getRepository().findAll(pageable);
        return IteratorUtils.toList(entityList.iterator());
    }

    @Override
    public List<T> save(List<T> entities) {
        List<T> result = new ArrayList<T>();
        if (entities == null) {
            return result;
        }
        for (T entity : entities) {
            result.add(save(entity));
        }
        return result;
    }
 
    @Override
    // @Transactional
    public T delete(ID id) {
        T entity = findOne(id);
        boolean found = entity != null;
        if (found) {
            getRepository().delete(entity);
        }
        return entity;
    }
    
    public List<T> delete(List<T> entities) {
        getRepository().delete(entities);
        return entities;
    }
    
    public List<T> update(List<T> entities) {
        getRepository().save(entities);
        return entities;
    }

    @Override
   // @Transactional
    public T update(T entity) {
        T savedEntity = findOne(entity.getId());
        T merged = null;
        boolean found = savedEntity != null;
        if (found) {
            updateChanges(entity, savedEntity);
            merged = getRepository().save(savedEntity);
        }
        return merged;
    }

    protected void resolveChildReferences(T entity) {
        // no implementation
    }

    protected void updateChanges(T source, T destination) {
        BeanUtils.copyProperties(source, destination);
    }


    public abstract  <S extends GenericCrudRepository<T,ID>> S getRepository();
}
