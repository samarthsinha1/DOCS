package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.oilandgas.repairportal.sowconfig.data.OperationTypeLovDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.OperationTypeLovRepository;
import com.ge.oilandgas.repairportal.sowconfig.entity.OperationTypeLov;

@Component
public class OperationTypeLovDAOImpl implements OperationTypeLovDAO{
	
	@Autowired
	private OperationTypeLovRepository operationTypeLovRepository;
	
	  public OperationTypeLovDAOImpl(OperationTypeLovRepository operationTypeLovRepository) {
	        this.operationTypeLovRepository = operationTypeLovRepository;
	    }
	  public OperationTypeLovDAOImpl() {
	       super();
	    }

	  @SuppressWarnings("unchecked")
	    public OperationTypeLovRepository getRepository() {
	        return operationTypeLovRepository;
	    }

	@Override
	public List<OperationTypeLov> findOperationTypeLov() {
		return operationTypeLovRepository.findOperationTypeLov();
	}
	
	

}
