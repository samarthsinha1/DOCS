package com.ge.oilandgas.repairportal.sowconfig.entity;

import java.util.LinkedList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name= "ong_sowcfg_std_module_operations_list_lov")
public class ModuleOperationList extends GenericEntity<Long>{

	
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SEQ_MODULE_OPERATION_LIST", sequenceName="ong_sowcfg_std_module_operations_list_sequence_id")
	@GeneratedValue(generator="SEQ_MODULE_OPERATION_LIST", strategy=GenerationType.SEQUENCE)
	@Column(name="module_operations_id")
	private Long id;
	
	@Column(name="plc_product_type")
	private String plcProductType;
	
	@Column(name="plc_code_routing")
	private String plcCodeRouting;
	
	@Column(name="engine")
	private String engine;
	
	@Column(name="module_code")
	private String module;
	
	@Column(name="num_operation")
	private Long numOperation;
	
	@Column(name="operation_name")
	private String operationName;
	
	@Column(name="operation_type")
	private String operationType;
	
	@Column(name="std_operation")
	private String stdOperation;
	
	@OneToMany(cascade = CascadeType.ALL,
			fetch = FetchType.EAGER, orphanRemoval=true)
	@JoinColumn(name="module_operations_id",referencedColumnName="module_operations_id", nullable=false)
	@OrderBy
	private List<ModuleOperationHrsLov> moduleOperationHrsList = new LinkedList<>();
		
	public String getPlcProductType() {
		return plcProductType;
	}

	public void setPlcProductType(String plcProductType) {
		this.plcProductType = plcProductType;
	}

	public String getPlcCodeRouting() {
		return plcCodeRouting;
	}

	public void setPlcCodeRouting(String plcCodeRouting) {
		this.plcCodeRouting = plcCodeRouting;
	}

	public Long getNumOperation() {
		return numOperation;
	}

	public void setNumOperation(Long numOperation) {
		this.numOperation = numOperation;
	}


	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getEngine() {
		return engine;
	}

	public void setEngine(String engine) {
		this.engine = engine;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	public String getStdOperation() {
		return stdOperation;
	}

	public void setStdOperation(String stdOperation) {
		this.stdOperation = stdOperation;
	}

	public List<ModuleOperationHrsLov> getModuleOperationHrsList() {
		return moduleOperationHrsList;
	}

	public void setModuleOperationHrsList(List<ModuleOperationHrsLov> moduleOperationHrsList) {
		this.moduleOperationHrsList = moduleOperationHrsList;
	}

}
