package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "ong_orp_user_sub_roles")
public class UserSubRole extends GenericEntity<Long>{
	
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="user_sub_role_id")
	private Long id;
	 
	@Column(name="user_role")
	private String userRole;
	
	@Column(name="user_sub_role")
	private String userSubRole;
	
	@Column(name="user_sub_role_description")
	private String userSubRoleDescription;
	
	@Column(name="user_sso")
	private long userSso;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getUserSubRole() {
		return userSubRole;
	}

	public void setUserSubRole(String userSubRole) {
		this.userSubRole = userSubRole;
	}

	public String getUserSubRoleDescription() {
		return userSubRoleDescription;
	}

	public void setUserSubRoleDescription(String userSubRoleDescription) {
		this.userSubRoleDescription = userSubRoleDescription;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public long getUserSso() {
		return userSso;
	}

	public void setUserSso(long userSso) {
		this.userSso = userSso;
	}
	
}
