package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.oilandgas.repairportal.sowconfig.data.NonStdTempMaterialsDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.NonStdTempMaterialsRepository;
import com.ge.oilandgas.repairportal.sowconfig.entity.MasterMaterialLovTemp;
@Component
public class NonStdTempMaterialsDAOImpl extends GenericCrudDAOImpl<MasterMaterialLovTemp, Long> implements NonStdTempMaterialsDAO {
		
	@Autowired
	private NonStdTempMaterialsRepository nonStdTempMaterialsRepository;
	
	public NonStdTempMaterialsDAOImpl(NonStdTempMaterialsRepository nonStdTempMaterialsRepository) {
        this.nonStdTempMaterialsRepository = nonStdTempMaterialsRepository;
    }
    public NonStdTempMaterialsDAOImpl() {
       super();
    }
    
    @SuppressWarnings("unchecked")
	@Override
    public NonStdTempMaterialsRepository getRepository() {
        return nonStdTempMaterialsRepository;
    }
	@Override
	public List<MasterMaterialLovTemp> getAllUserCreatedMaterials(String docName) {
		return nonStdTempMaterialsRepository.getAllUserCreatedMaterials(docName);
		
	}
	@Override
	public List<MasterMaterialLovTemp> getAllUserCreatedEngineMaterials(String docName, String engine) {
		return nonStdTempMaterialsRepository.getAllUserCreatedEngineMaterials(docName,engine);
	}
	@Override
	public List<MasterMaterialLovTemp> getAllUserCreatedModuleMaterials(String docName, String engine, String module) {
		return nonStdTempMaterialsRepository.getAllUserCreatedModuleMaterials(docName,engine,module);
	}
    
    
}
