package com.ge.oilandgas.repairportal.sowconfig.data;

import java.util.List;

import com.ge.oilandgas.repairportal.sowconfig.entity.ReportFields;

public interface ReportFieldsDAO extends GenericDAO<ReportFields, Long> {

	List<ReportFields> findReportFieldsByEngineInfoId(Long engineInfoId);
}
