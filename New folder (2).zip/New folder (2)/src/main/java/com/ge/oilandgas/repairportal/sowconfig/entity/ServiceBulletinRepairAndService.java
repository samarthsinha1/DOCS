package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ong_sowcfg_SB_repairAndService")
public class ServiceBulletinRepairAndService {

	@Id
    @Column(name = "repair_service_id")
	private Long repairServiceId;
	
	@Column(name="bulletin_sequence_id")
	private Long bulletinSeqId;

	@Column(name="component_description")
	private String componentDescription;
	
	@Column(name="component_code")
	private String componentCode;
	
	@Column(name="quantity_repairs")
	private Long quantityRepairs;

	@Column(name="repair_description")
	private String repairDescription;
	
	@Column(name="component_group")
	private String componentGroup;

	@Column(name="machine_model")
	private String machineModel;
	
	@Column(name="module")
	private String module;
	
	public Long getRepairServiceId() {
		return repairServiceId;
	}

	public void setRepairServiceId(Long repairServiceId) {
		this.repairServiceId = repairServiceId;
	}

	public Long getBulletinSeqId() {
		return bulletinSeqId;
	}

	public void setBulletinSeqId(Long bulletinSeqId) {
		this.bulletinSeqId = bulletinSeqId;
	}
	
	public String getComponentDescription() {
		return componentDescription;
	}

	public void setComponentDescription(String componentDescription) {
		this.componentDescription = componentDescription;
	}

	public String getComponentCode() {
		return componentCode;
	}

	public void setComponentCode(String componentCode) {
		this.componentCode = componentCode;
	}

	public Long getQuantityRepairs() {
		return quantityRepairs;
	}

	public void setQuantityRepairs(Long quantityRepairs) {
		this.quantityRepairs = quantityRepairs;
	}


	public String getRepairDescription() {
		return repairDescription;
	}

	public void setRepairDescription(String repairDescription) {
		this.repairDescription = repairDescription;
	}

	public String getComponentGroup() {
		return componentGroup;
	}

	public void setComponentGroup(String componentGroup) {
		this.componentGroup = componentGroup;
	}

	public String getMachineModel() {
		return machineModel;
	}

	public void setMachineModel(String machineModel) {
		this.machineModel = machineModel;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}
	
}
