package com.ge.oilandgas.repairportal.sowconfig.service.api;

import org.springframework.web.bind.annotation.RequestBody;

import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ServiceBulletinsDto;

public interface ServiceBulletinService {
	ResponseTemplateDto<ServiceBulletinsDto> getServiceBulletinsById(Long id);
	ResponseTemplateDto<ServiceBulletinsDto> saveUpdateServiceBulletins(@RequestBody ServiceBulletinsDto serviceBulletinsDto);
	ResponseTemplateDto<ServiceBulletinsDto> findServiceBulletinsByNumber(String sbNumber);
	
	
//	List<ServiceBulletinsDto> getAllServiceBulletin();
//	List<ServiceBulletinsDto> searchServiceBulletin(String serviceId);
}
