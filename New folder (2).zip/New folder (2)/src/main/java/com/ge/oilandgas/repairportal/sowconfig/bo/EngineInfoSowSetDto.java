package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

public class EngineInfoSowSetDto extends AuditDataDto implements Serializable {
	 
	/**
	 * 
	 */
	private static final long serialVersionUID = -4332228123991721460L;

	private Long id;
	
	private String sowSetCode;
	
	private String sowName;
	
	private String mandatoryFlag;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSowSetCode() {
		return sowSetCode;
	}

	public void setSowSetCode(String sowSetCode) {
		this.sowSetCode = sowSetCode;
	}

	public String getSowName() {
		return sowName;
	}

	public void setSowName(String sowName) {
		this.sowName = sowName;
	}

	public String getMandatoryFlag() {
		return mandatoryFlag;
	}

	public void setMandatoryFlag(String mandatoryFlag) {
		this.mandatoryFlag = mandatoryFlag;
	}

	
}
