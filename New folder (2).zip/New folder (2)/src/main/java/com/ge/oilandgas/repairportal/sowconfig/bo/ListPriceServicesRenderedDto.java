package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

public class ListPriceServicesRenderedDto implements Serializable  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	 private String priceListType;
	 private String serviceRendered;
	 private String supplier;	 

		public String getPriceListType() {
			return priceListType;
		}

		public void setPriceListType(String priceListType) {
			this.priceListType = priceListType;
		}


		public String getServiceRendered() {
			return serviceRendered;
		}

		public void setServiceRendered(String serviceRendered) {
			this.serviceRendered = serviceRendered;
		}

		public String getSupplier() {
			return supplier;
		}

		public void setSupplier(String supplier) {
			this.supplier = supplier;
		}

		
}
