package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;
import java.util.List;

public class UserRolesDto implements Serializable {
	 
	   /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String userRole;
	private String userRoleDes;
	private List<UserSubRoleDto> userSubRole;
	   
	
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public List<UserSubRoleDto> getUserSubRole() {
		return userSubRole;
	}
	public void setUserSubRole(List<UserSubRoleDto> userSubRole) {
		this.userSubRole = userSubRole;
	}
	public String getUserRoleDes() {
		return userRoleDes;
	}
	public void setUserRoleDes(String userRoleDes) {
		this.userRoleDes = userRoleDes;
	}
	   
	   

}
