package com.ge.oilandgas.repairportal.sowconfig.data;

import java.util.List;

import com.ge.oilandgas.repairportal.sowconfig.entity.EngineLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineModelLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.OpptyTypeLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.ProductLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.ProposalTypeLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.SowMasterMaterial;


public interface SowMasterMaterialDAO extends GenericDAO<SowMasterMaterial, Long>{
	
	List<SowMasterMaterial> findMaterialByEngine(String product,String model,String engine, String newRepair);

	List<SowMasterMaterial> findMaterialByModule(String product,String model,String engine,String module,String newRepair);

	List<SowMasterMaterial> getMaterialByModuleList(String product, String model, String engine, String newRepair);

	List<EngineLov> getEngineLovList(String product);

	List<OpptyTypeLov> getOpptyTypeList();

	List<ProposalTypeLov> getProposalTypeList();

	List<SowMasterMaterial> getGGTestModuleMaterialList(String product, String model, String engine, String priceCategory);
	List<SowMasterMaterial> getGGTestEngineMaterialList(String product, String model, String engine, String priceCategory);
	
	String getPlcModelCode(String product, String model);
	
	List<EngineModelLov> getAllEngineModelLov(String product);

	List<SowMasterMaterial> getAllMaterialByEngine(String product,String model,String engine);
	List<SowMasterMaterial> getAllMaterialByModuleList(String product, String model, String engine);
	List<SowMasterMaterial> getAllMaterialByModule(String product,String model,String engine,String module);
	ProductLov getProductDetails(String productCode);

	List<ProductLov> getProductList();
	
}
