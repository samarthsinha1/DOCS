/*package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.ge.oilandgas.repairportal.sowconfig.data.repository.GenericCrudRepository;

import com.ge.oilandgas.repairportal.sowconfig.data.repository.ServiceBulletinsRepository;
import com.ge.oilandgas.repairportal.sowconfig.entity.ServiceBulletinNewMaterials;
import com.ge.oilandgas.repairportal.sowconfig.entity.ServiceBulletinOperations;
import com.ge.oilandgas.repairportal.sowconfig.entity.ServiceBulletinRepairAndService;
import com.ge.oilandgas.repairportal.sowconfig.entity.ServiceBulletins;

@Component
public class ServiceBulletinAdminDAOImpl extends GenericCrudDAOImpl<ServiceBulletins, Long> implements ServiceBulletinAdminDAO {
//this is the implementation
	@Autowired
	private ServiceBulletinsRepository serviceBulletinsRepository;
	//not getting autowired with repository
	@Autowired
	private ServiceBulletinNewMaterialsRepository serviceBulletinNewMaterialsRepository;
	@Autowired
	private ServiceBulletinOperationsRepository serviceBulletinOperationsRepository;
	@Autowired
	private ServiceBulletinRepairAndServiceRepository serviceBulletinRepairAndServiceRepository;
	
	//I tried to create a parameterized constructor as well
	  public ServiceBulletinAdminDAOImpl(ServiceBulletinsRepository serviceBulletinsRepository,ServiceBulletinNewMaterialsRepository serviceBulletinNewMaterialsRepository,
			  ServiceBulletinOperationsRepository serviceBulletinOperationsRepository,ServiceBulletinRepairAndServiceRepository serviceBulletinRepairAndServiceRepository) {
	        this.serviceBulletinsRepository = serviceBulletinsRepository;
	        this.serviceBulletinNewMaterialsRepository=serviceBulletinNewMaterialsRepository;
	        this.serviceBulletinOperationsRepository=serviceBulletinOperationsRepository;
	        this.serviceBulletinRepairAndServiceRepository=serviceBulletinRepairAndServiceRepository;
	    }
	  
	  public ServiceBulletinAdminDAOImpl() {
		super();
	}

	@SuppressWarnings("unchecked")
	 public ServiceBulletinsRepository getRepository() {
        return serviceBulletinsRepository;
    }

	@Override
	public ServiceBulletinNewMaterials saveSbNewMaterial(ServiceBulletinNewMaterials serviceBulletinNewMaterials) {
		serviceBulletinNewMaterialsRepository.save(serviceBulletinNewMaterials);
		return serviceBulletinNewMaterials;
	}

	@Override
	public ServiceBulletinOperations saveSbOperation(ServiceBulletinOperations serviceBulletinOperations) {
		serviceBulletinOperationsRepository.save(serviceBulletinOperations);
		return serviceBulletinOperations;
	}

	@Override
	public ServiceBulletinRepairAndService saveSbRepairAndService(ServiceBulletinRepairAndService serviceBulletinRepairAndService) {
		serviceBulletinRepairAndServiceRepository.save(serviceBulletinRepairAndService);
		return serviceBulletinRepairAndService;
	}

	@Override
	public <S extends GenericCrudRepository<ServiceBulletins, Long>> S getRepository() {
		// TODO Auto-generated method stub
		return null;
	}
	

	
	@Override
	public <S extends GenericCrudRepository<ServiceBulletins, Long>> S getRepository() {
		return null;
	}

	
	
}
*/