package com.ge.oilandgas.repairportal.sowconfig.manager;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.oilandgas.repairportal.sowconfig.bo.CommercialViewDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineInfoDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineMaterialRepairDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineMaterialsDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineOperationsDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ModelEngineDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ModuleMaterialRepairDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ModuleMaterialsDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ModuleOperationsDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ModulePdfDetailsDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ModulesDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.PriceCategoryDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ServiceBulletinsDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.SummaryByModulePdfDetailsDto;
import com.ge.oilandgas.repairportal.sowconfig.data.EngineModuleDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.SowMasterMaterialDAO;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineLov;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineModule;
import com.ge.oilandgas.repairportal.sowconfig.utils.HeaderFooterPageEvent;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

@Service
public class PdfCreationManager {

	private static final String DISCOUNTABLE = "Discountable";
	private static final String TRUE = "true";
	private static final String FIXED_FIRM_PRICE = "Fixed Firm Price";
	private static final String TIME_MATERIAL = "Time&Material";
	private static final Logger LOGGER = LoggerFactory.getLogger(PdfCreationManager.class);
	private static final String[] OPERATION_HEADER = {"OPERATIONS"};
	private static final String[] OPERATION_HEADER_ENGINE = {"OPERATIONS","LABOR QUOTE PRICE"};
	private static final String[] TECHNICAL_MODULE_HEADER = {"LABOR QUOTE PRICE","NEW MATERIALS QUOTE PRICE","REPAIRS & OTHER SERVICES QUOTE PRICE","TOTAL QUOTE PRICE BY MODULE"};
	private static final String[] TECHNICAL_MODULE_HEADER_GRAND = {"ENGINES & SB","LABOR QUOTE PRICE","NEW MATERIALS QUOTE PRICE","REPAIRS & OTHER SERVICES QUOTE PRICE","TOTAL QUOTE PRICE BY ENGINES & SB"};
	private static final String[] NEW_MATERIAL_HEADER_FOR_T_AND_M = {"COMPONENT CODE","COMPONENT DESCRIPTION","QTY","FALL OUT%","UNIT QUOTE PRICE","TOTAL QUOTE PRICE","DISCOUNTABLE"};
	private static final String[] REPAIR_MATERIAL_HEADER_FOR_T_AND_M = {"COMPONENT CODE","COMPONENT DESCRIPTION","QTY","UNIT QUOTE PRICE","TOTAL QUOTE PRICE","REPAIR DESCRIPTION"};
	private static final String[] NEW_MATERIAL_HEADER_FOR_FFP = {"COMPONENT CODE","COMPONENT DESCRIPTION","QTY","DISCOUNTABLE"};
	private static final String[] REPAIR_MATERIAL_HEADER_FOR_FFP = {"COMPONENT CODE","COMPONENT DESCRIPTION","QTY","REPAIR DESCRIPTION"};
	private static final String[] SUMMARY_BY_MODULE_HEADER = {"MODULES","FALL OUT%","LABOR QUOTE PRICE","NEW MATERIALS QUOTE PRICE","REPAIRS & OTHER SERVICES QUOTE PRICE","TOTAL QUOTE PRICE BY MODULE"};
	private static final String[] TECHNICAL_MODULE_HEADER_GRAND_FFP = {"ENGINES & SB","TOTAL QUOTE PRICE"};
	
	BaseColor myColorpan = new BaseColor(46, 115, 186);   //#2e73ba
	Font textFont = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, true, 10, 0);
	Font textFontBold = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, true, 10, Font.BOLD);
	Font headerFont = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, true, 10, 0);
	Font headerFontWithBold = FontFactory.getFont("Arial", BaseFont.IDENTITY_H, true, 11, Font.BOLD);

	@Autowired
	HeaderFooterPageEvent headerFooterPageEvent;
	@Autowired
	EngineModuleDAO engineModuleDAO;
	@Autowired
	SowMasterMaterialDAO sowMasterMaterialDAO;
	
	/**
	 * @param engineInfoDto
	 * @param proposalType
	 * @return
	 */
	public byte[] createSowTechnicalDetailsPdf(Map<String, Object> technicalDetailsPdfInput, String proposalType) {
		LOGGER.debug("Class::PdfCreationManager, Method::createSowTechnicalDetailsPdf::Start");
		Document document = new Document();
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		try {
			PdfWriter writer = PdfWriter.getInstance(document, out);
			//PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(RESULT));
			writer.setPageEvent(headerFooterPageEvent);
			document.open();
			//extract inputs
			EngineInfoDto engineInfoDto = null;
			CommercialViewDto commercialViewDto = null;
			if(technicalDetailsPdfInput != null) {
				String engineInfoDtoString = (String)technicalDetailsPdfInput.get("engineInfo");
				String commercialViewDtoString = (String)technicalDetailsPdfInput.get("commercialView");
				ObjectMapper mapper = new ObjectMapper();
				engineInfoDto =  mapper.readValue(engineInfoDtoString, EngineInfoDto.class);
				commercialViewDto =  mapper.readValue(commercialViewDtoString, CommercialViewDto.class);
			}
	        // step 4
	        createSowTechnicalDetails(document,engineInfoDto,proposalType,writer,commercialViewDto);
	        // step 5
	        document.close();
		} catch (Exception e) {
			LOGGER.error("Exception while createSowTechnicalDetailsPdf call.",e);
		} 
		LOGGER.debug("Class::PdfCreationManager, Method::createSowTechnicalDetailsPdf::Exit");
		return out.toByteArray();
	}
	
	
	/**
	 * @param summaryByModuleDetails
	 * @return
	 */
	public byte[] createSummaryByModuleDetailsPdf(Map<String, Object> summaryByModuleDetails,String product) {
		LOGGER.debug("Class::PdfCreationManager, Method::createSummaryByModuleDetailsPdf::Start");
		Document document = new Document();
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		try {
			PdfWriter writer = PdfWriter.getInstance(document, out);
			writer.setPageEvent(headerFooterPageEvent);
			document.open();
	        // step 4
			createSummaryByModuleDetails(document,summaryByModuleDetails,product);
	        // step 5
	        document.close();
		} catch (Exception e) {
			LOGGER.error("Exception while createSummaryByModuleDetailsPdf call.",e);
		} 
		LOGGER.debug("Class::PdfCreationManager, Method::createSummaryByModuleDetailsPdf::Exit");
		return out.toByteArray();
	}
	

	/**
	 * @param engineInfoDto
	 * @return
	 */
	public byte[] createSummaryByModuleDetailsPdf(EngineInfoDto engineInfoDto) {
		LOGGER.debug("Class::PdfCreationManager, Method::createSummaryByModuleDetailsPdf::Start");
		Document document = new Document();
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		try {
			PdfWriter writer = PdfWriter.getInstance(document, out);
			writer.setPageEvent(headerFooterPageEvent);
			document.open();
	        // step 4
			createSummaryByModuleDetailsNew(document,engineInfoDto);
	        // step 5
	        document.close();
		} catch (Exception e) {
			LOGGER.error("Exception while createSummaryByModuleDetailsPdf call.",e);
		} 
		LOGGER.debug("Class::PdfCreationManager, Method::createSummaryByModuleDetailsPdf::Exit");
		return out.toByteArray();
	}
	
	/**
	 * @param document
	 * @param summaryByModuleDetails
	 * @throws ParseException
	 * @throws DocumentException
	 * @throws IOException 
	 * @throws JsonMappingException 
	 * @throws JsonParseException 
	 */
	@SuppressWarnings("unchecked")
	private void createSummaryByModuleDetails(Document document, Map<String, Object> summaryByModuleDetails,String product) throws ParseException, DocumentException, IOException {
		LOGGER.debug("Class::PdfCreationManager, Method::createSummaryByModuleDetails::Start");
		List<String> boldModules = new ArrayList<>(Arrays.asList("Service Bulletins","TOTAL QUOTE PRICE"));
		List<EngineLov> engineLovList= sowMasterMaterialDAO.getEngineLovList(product);
		List<EngineModule> engineModuleList= engineModuleDAO.findEngineModule(product);
		Map<String, EngineLov> engineLovMap = new HashMap<>();
		List<String> engineDisplayNameList = new ArrayList<>();
		if(engineLovList != null) {
			for(EngineLov engineLov : engineLovList) {
				//engineDisplayNameList.add(engineLov.getEngineDisplayName());
				boldModules.add(engineLov.getEngineDisplayName());
				boldModules.add("Total "+engineLov.getEngineDisplayName()+" Estimate");
				engineLovMap.put(engineLov.getEngine(), engineLov);
			}
		}
		List<String> engineList = new ArrayList<>();
		if(engineModuleList != null) {
			for(EngineModule engineModule : engineModuleList) {
				if(!engineList.contains(engineModule.getEngine())) {
					engineList.add(engineModule.getEngine());
				}
			}
		}
		for(String engine : engineList) {
			engineDisplayNameList.add(engineLovMap.get(engine).getEngineDisplayName());
		}
		Map<String,List<SummaryByModulePdfDetailsDto>> summaryByModuleDetailsMap = new HashMap<>();
		if(summaryByModuleDetails != null) {
			List<Map<String,String>> summaryDetailsList = (List<Map<String,String>>)summaryByModuleDetails.get("summaryDetails");
			boolean isNextModuleStarted = false;
			String moduleDisplayName = "";
			for(int count = 0; count < summaryDetailsList.size(); count++)
			{
				Map<String,String> summaryDetails = (Map<String,String>)summaryDetailsList.get(count);
			    SummaryByModulePdfDetailsDto summaryByModulePdfDetailsDto = new SummaryByModulePdfDetailsDto();
				summaryByModulePdfDetailsDto.setModules(summaryDetails.get("Modules"));
				summaryByModulePdfDetailsDto.setFallOut(summaryDetails.get("Fall Out%"));
				summaryByModulePdfDetailsDto.setLabor(summaryDetails.get("LABOR Quote Price"));
				summaryByModulePdfDetailsDto.setMaterials(summaryDetails.get("NEW MATERIALS Quote Price"));
				summaryByModulePdfDetailsDto.setSpecialServices(summaryDetails.get("REPAIRS & OTHER SERVICES Quote Price"));
				summaryByModulePdfDetailsDto.setTotalPrice(summaryDetails.get("TOTAL QUOTE PRICE BY MODULE"));
				if(isNextModuleStarted && engineDisplayNameList.contains(summaryByModulePdfDetailsDto.getModules()) && !moduleDisplayName.equalsIgnoreCase(summaryByModulePdfDetailsDto.getModules())) {
					isNextModuleStarted = false;
					moduleDisplayName = "";
				}
				if((summaryByModulePdfDetailsDto.getModules() != null && engineDisplayNameList.contains(summaryByModulePdfDetailsDto.getModules())) && !isNextModuleStarted) {
					List<SummaryByModulePdfDetailsDto> summaryByModuleList = new ArrayList<>();
					summaryByModuleList.add(summaryByModulePdfDetailsDto);
					summaryByModuleDetailsMap.put(summaryByModulePdfDetailsDto.getModules(), summaryByModuleList);
					isNextModuleStarted = true;
					moduleDisplayName = summaryByModulePdfDetailsDto.getModules();
				}else{
					List<SummaryByModulePdfDetailsDto> summaryByModuleList = summaryByModuleDetailsMap.get(moduleDisplayName);
					summaryByModuleList.add(summaryByModulePdfDetailsDto);
				}
				
			}
		}
		addSummaryTitle(document);
		String newPriceCategory = (String)summaryByModuleDetails.get("newPriceCategory");
		ObjectMapper mapper = new ObjectMapper();
		PriceCategoryDto[] priceCategoryList =  newPriceCategory != null ? mapper.readValue(newPriceCategory, PriceCategoryDto[].class) : null;
		if(summaryByModuleDetails != null) {
			List<Map<String,String>> summaryHeaderList = (List<Map<String,String>>)summaryByModuleDetails.get("summaryHeader");
			addSummaryHeaderDetails(document,summaryHeaderList);
		}
		//Set<String> summaryByModuleKeySet = summaryByModuleDetailsMap.keySet();
		int pageCount = 1;
		for(String key : engineDisplayNameList) {
			List<SummaryByModulePdfDetailsDto> tempList = summaryByModuleDetailsMap.get(key);
			if(pageCount > 1 && tempList!=null) {
				document.newPage();
			}else{
				document.add( new Phrase("\n") );
			}
			
			
			if(tempList!=null){
				createModuleBySummaryDetails(document, boldModules, tempList, priceCategoryList,engineDisplayNameList);
				pageCount++;
				
			}
			
			
		}
		
		LOGGER.debug("Class::PdfCreationManager, Method::createSummaryByModuleDetails::Exit");
	}


	/**
	 * @param document
	 * @param boldModules
	 * @param ptSummaryList
	 * @throws DocumentException
	 */
	private void createModuleBySummaryDetails(Document document, List<String> boldModules,
			List<SummaryByModulePdfDetailsDto> ptSummaryList,PriceCategoryDto[] priceCategoryList,List<String> engineDisplayNameList) throws DocumentException {
		LOGGER.debug("Class::PdfCreationManager, Method::createModuleBySummaryDetails::Start");
		PdfPTable table1 = new PdfPTable(6);
		table1.setWidthPercentage(100);
		table1.setTotalWidth(new float[]{ 110, 50,60,70,80,80 });
		table1.setHorizontalAlignment(Element.ALIGN_LEFT);
		createHeader(table1,SUMMARY_BY_MODULE_HEADER);
		boolean isFirstModuleBolded = false;
		for(SummaryByModulePdfDetailsDto summaryByModulePdfDetailsDto : ptSummaryList) {
			if(boldModules.contains(summaryByModulePdfDetailsDto.getModules()) || isNewPriceCategoryExist(priceCategoryList,summaryByModulePdfDetailsDto.getModules())) {
				if(!isFirstModuleBolded || !engineDisplayNameList.contains(summaryByModulePdfDetailsDto.getModules())) 
				{
					table1.addCell(createCellWithoutBorderAndBold(summaryByModulePdfDetailsDto.getModules(),1));
					isFirstModuleBolded = true;
				}else{
					table1.addCell(createCellWithoutBorder(summaryByModulePdfDetailsDto.getModules(),1));
				}
			}else{
				table1.addCell(createCellWithoutBorder(summaryByModulePdfDetailsDto.getModules(),1));
			}
			table1.addCell(createCellWithoutBorder(summaryByModulePdfDetailsDto.getFallOut(),1));
			table1.addCell(createCellWithoutBorder(summaryByModulePdfDetailsDto.getLabor(),1));
			table1.addCell(createCellWithoutBorder(summaryByModulePdfDetailsDto.getMaterials(),1));
			table1.addCell(createCellWithoutBorder(summaryByModulePdfDetailsDto.getSpecialServices(),1));
			table1.addCell(createCellWithoutBorder(summaryByModulePdfDetailsDto.getTotalPrice(),1));
		}	
		document.add(table1);
		LOGGER.debug("Class::PdfCreationManager, Method::createModuleBySummaryDetails::Exit");
	}


	/**
	 * @param document
	 * @param summaryHeaderList
	 * @throws DocumentException
	 */
	private void addSummaryHeaderDetails(Document document, List<Map<String, String>> summaryHeaderList) throws DocumentException {
		LOGGER.debug("Class::PdfCreationManager, Method::addSummaryHeaderDetails::Start");
		Map<String, String> engineDetails = summaryHeaderList.get(0);
		PdfPTable table = new PdfPTable(2);
		table.setHorizontalAlignment(Element.ALIGN_LEFT);
	    table.setWidthPercentage(50); 
		table.addCell(createCellWithoutBorder("Customer",1));
	    table.addCell(createCellWithoutBorder(engineDetails.get("Customer"),1));
	    table.addCell(createCellWithoutBorder("Oppty ID #",1));
	    table.addCell(createCellWithoutBorder(engineDetails.get("Oppty ID #"),1));
		table.addCell(createCellWithoutBorder("Oppty Rev#",1));
	    table.addCell(createCellWithoutBorder(engineDetails.get("Oppty Rev#"),1));
	    table.addCell(createCellWithoutBorder("Oppty Type",1));
	    table.addCell(createCellWithoutBorder(engineDetails.get("Oppty Type"),1)); 
	    table.addCell(createCellWithoutBorder("Oppty Date",1));
	    table.addCell(createCellWithoutBorder(engineDetails.get("Oppty Date"),1));
	    table.addCell(createCellWithoutBorder("Machine Model",1));
	    table.addCell(createCellWithoutBorder(engineDetails.get("Machine Model"),1));
	    table.addCell(createCellWithoutBorder("Serial Number",1));
	    table.addCell(createCellWithoutBorder(engineDetails.get("Serial Number"),1));
	    table.addCell(createCellWithoutBorder("Type",1));
	    table.addCell(createCellWithoutBorder(engineDetails.get("Type"),1));
	   	document.add(table);
	   	LOGGER.debug("Class::PdfCreationManager, Method::addSummaryHeaderDetails::Exit");
	}


	/**
	 * @param document
	 * @param engineInfoDto
	 * @param proposalType
	 * @param commercialViewDto 
	 * @throws DocumentException
	 * @throws MalformedURLException
	 * @throws IOException
	 */
	private void createSowTechnicalDetails(Document document, EngineInfoDto engineInfoDto, String proposalType,PdfWriter writer, CommercialViewDto commercialViewDto) throws DocumentException, MalformedURLException, IOException {
		LOGGER.debug("Class::PdfCreationManager, Method::createSowTechnicalDetails::Start");
		addTitle(document);
		addHeaderDetails(document,engineInfoDto);
		List<ModelEngineDto> modelEngineList = engineInfoDto.getModelEngineList();
		List<EngineModule> engineModuleList= engineModuleDAO.findEngineModule(engineInfoDto.getProduct());
		List<EngineLov> engineLovList= sowMasterMaterialDAO.getEngineLovList(engineInfoDto.getProduct());
		Map<String,String> engineModuleMap = getEngineModuleMap(engineModuleList);
		Map<String,String> engineLovMapWithDiscription = getEngineLovMapWithDiscription(engineLovList);
		Map<String,String> engineLovMapWithDisplayName = getEngineLovMapWithDisplayName(engineLovList);
		List<ServiceBulletinsDto> serviceBulletinsDtoList = engineInfoDto.getServiceBulletinList();
		List<ModulePdfDetailsDto> grandModuleTotalsList = new ArrayList<>();
		if(modelEngineList != null) {
			int count = 0;
			for(ModelEngineDto modelEngine : modelEngineList) {
				if(TRUE.equalsIgnoreCase(modelEngine.getEngineChecked())) {
					ModulePdfDetailsDto grandModuleTotalDto = new ModulePdfDetailsDto();
					
					if(count >= 1) {
						document.newPage();
					}
					document.add( new Phrase("\n") );
					document.add(new Phrase(modelEngine.getEngine()+" - "+engineLovMapWithDiscription.get(modelEngine.getEngine()),headerFontWithBold));
					List<EngineMaterialRepairDto> engineMaterialRepairList = modelEngine.getEngineMaterialRepairList();
					List<EngineMaterialsDto> engineMaterialsList =  modelEngine.getEngineMaterialsList();
					List<EngineOperationsDto> engineOperationsList = modelEngine.getEngineOperationsList();
					ModulePdfDetailsDto modulePdfDetailsDto = getEnginePriceDetails(modelEngine,engineLovMapWithDisplayName);
					grandModuleTotalDto.setModule(engineLovMapWithDisplayName.get(modelEngine.getEngine()));
					if(modulePdfDetailsDto != null) {
						checkRemainingSpaceAvailable(document,writer);
						createSummaryByModulesForEngine(document, grandModuleTotalDto, modulePdfDetailsDto,proposalType);
					}
					if(engineOperationsList != null && engineOperationsList.size() > 0) {
						checkRemainingSpaceAvailable(document,writer);
						if(TIME_MATERIAL.equalsIgnoreCase(proposalType)) {
							createEngineOperationsWithQuotePrice(document, engineOperationsList);
						}else if(FIXED_FIRM_PRICE.equalsIgnoreCase(proposalType)){
							createEngineOperations(document, engineOperationsList);
						}
					}
					if(engineMaterialsList != null && engineMaterialsList.size() > 0) {
						checkRemainingSpaceAvailable(document,writer);
						createEngineMaterials(document, proposalType, engineMaterialsList);
					}
					if(engineMaterialRepairList != null && engineMaterialRepairList.size() > 0) {
						checkRemainingSpaceAvailable(document,writer);
						createEngineRepairMaterials(document, proposalType, engineMaterialRepairList,engineMaterialsList);
					}
					
					List<ModulesDto> moduleList = modelEngine.getModuleList();
					if(moduleList != null) {
							for(ModulesDto modules : moduleList) {
								if(TRUE.equalsIgnoreCase(modules.getModuleChecked())) {
									checkRemainingSpaceAvailable(document,writer);
									document.add(new Phrase(modules.getModule()+" - "+engineModuleMap.get(modules.getModule()),headerFontWithBold));
									List<ModuleMaterialsDto> moduleMaterialsList = modules.getModuleMaterialsList();
									List<ModuleMaterialRepairDto> moduleMaterialsRepairList = modules.getModuleMaterialsRepairList();
									List<ModuleOperationsDto> moduleOperationsList = modules.getModuleOperationsList();
									ModulePdfDetailsDto modulePdfDetailsDtoForModule = getModulePriceDetails(modules,engineModuleMap);
									if(modulePdfDetailsDtoForModule != null) {
										checkRemainingSpaceAvailable(document,writer);
										createSummaryByModulesForEngine(document, grandModuleTotalDto,
												modulePdfDetailsDtoForModule,proposalType);
									}
									if(moduleOperationsList != null && moduleOperationsList.size() > 0) {
										checkRemainingSpaceAvailable(document,writer);
										createModuleOperations(document, moduleOperationsList);
									}
									
									if(moduleMaterialsList != null && moduleMaterialsList.size() >0) {
										checkRemainingSpaceAvailable(document,writer);
										createModuleMaterials(document, proposalType, moduleMaterialsList);
									}
									if(moduleMaterialsRepairList != null && moduleMaterialsRepairList.size() > 0) {
										checkRemainingSpaceAvailable(document,writer);
										createModuleRepairMaterials(document, proposalType, moduleMaterialsRepairList,moduleMaterialsList);
									}
									
							}
						}
					}
					count++;
					grandModuleTotalsList.add(grandModuleTotalDto);
				}
			}
			calculateSbPriceNewPriceCategoryAndGrantTotal(serviceBulletinsDtoList, grandModuleTotalsList,commercialViewDto);
			checkRemainingSpaceAvailable(document,writer);
			displayGrandTotals(document, grandModuleTotalsList,proposalType,commercialViewDto);
		}
		LOGGER.debug("Class::PdfCreationManager, Method::createSowTechnicalDetails::Exit");
	}

	/**
	 * @param document
	 * @param proposalType
	 * @param moduleMaterialsRepairList
	 * @throws DocumentException
	 */
	private void createModuleRepairMaterials(Document document, String proposalType,
			List<ModuleMaterialRepairDto> moduleMaterialsRepairList,List<ModuleMaterialsDto> moduleMaterialsList ) throws DocumentException {
		LOGGER.debug("Class::PdfCreationManager, Method::createModuleRepairMaterials::Start");
		document.add(new Phrase("REPAIRS & OTHER SERVICES",headerFontWithBold));
		PdfPTable table = null;
		if(TIME_MATERIAL.equalsIgnoreCase(proposalType)) {
			table = new PdfPTable(6);
			table.setWidthPercentage(100);
			table.setTotalWidth(new float[]{ 90, 100,50,90,90,100 });
			table.setHorizontalAlignment(Element.ALIGN_LEFT);
			createHeader(table,REPAIR_MATERIAL_HEADER_FOR_T_AND_M);
			table.setHeaderRows(1);
		}else if(FIXED_FIRM_PRICE.equalsIgnoreCase(proposalType)){
			table = new PdfPTable(4);
			table.setWidthPercentage(100);
			table.setTotalWidth(new float[]{100,110,50,100});
			table.setHorizontalAlignment(Element.ALIGN_LEFT);
			createHeader(table,REPAIR_MATERIAL_HEADER_FOR_FFP);
			table.setHeaderRows(1);
		}
		List<String> falloutNewMaterial = new ArrayList<>();
		for(ModuleMaterialsDto moduleMaterialsDto : moduleMaterialsList) {
			if(moduleMaterialsDto.getFallout() != null  && moduleMaterialsDto.getFallout() != 0) {
				falloutNewMaterial.add(moduleMaterialsDto.getPartNumber());
			}
		}					
		if(table != null) {
			for(ModuleMaterialRepairDto moduleMaterialRepair : moduleMaterialsRepairList) {
				table.addCell(createCellWithoutBorder(moduleMaterialRepair.getPartNumber(),1));
				table.addCell(createCellWithoutBorder(moduleMaterialRepair.getNomenclature(),1));
				if(TIME_MATERIAL.equalsIgnoreCase(proposalType)) {
					table.addCell(createCellWithoutBorder(String.valueOf(moduleMaterialRepair.getQuantity()),1));
					table.addCell(createCellWithoutBorder(convertNumberToCurrency(moduleMaterialRepair.getQuotePrice()),1));
					table.addCell(createCellWithoutBorder(convertNumberToCurrency(moduleMaterialRepair.getQuantity() * moduleMaterialRepair.getQuotePrice()),1));
				}else if(FIXED_FIRM_PRICE.equalsIgnoreCase(proposalType)){
					if(moduleMaterialRepair.getPartNumber() != null && !falloutNewMaterial.contains(moduleMaterialRepair.getPartNumber())) {
						table.addCell(createCellWithoutBorder(String.valueOf(moduleMaterialRepair.getQuantity()),1));
					}else if(moduleMaterialRepair.getPartNumber() != null && falloutNewMaterial.contains(moduleMaterialRepair.getPartNumber())) {
						table.addCell(createCellWithoutBorder("X",1));
					}
				}
				table.addCell(createCellWithoutBorder(moduleMaterialRepair.getServiceRendered(),1));
			}
			document.add(table);
		}
		
		LOGGER.debug("Class::PdfCreationManager, Method::createModuleRepairMaterials::Exit");
	}


	/**
	 * @param document
	 * @param proposalType
	 * @param moduleMaterialsList
	 * @throws DocumentException
	 */
	private void createModuleMaterials(Document document, String proposalType,
			List<ModuleMaterialsDto> moduleMaterialsList) throws DocumentException {
		LOGGER.debug("Class::PdfCreationManager, Method::createModuleMaterials::Start");
		document.add(new Phrase("NEW MATERIALS",headerFontWithBold));
		PdfPTable table = null;
		if(TIME_MATERIAL.equalsIgnoreCase(proposalType)) {
			table = new PdfPTable(7);
			table.setWidthPercentage(100);
			table.setTotalWidth(new float[]{ 80, 105,50,50,75,75,70 });
			table.setHorizontalAlignment(Element.ALIGN_LEFT);
			createHeader(table,NEW_MATERIAL_HEADER_FOR_T_AND_M);
			table.setHeaderRows(1);
		}else if(FIXED_FIRM_PRICE.equalsIgnoreCase(proposalType)){
			table = new PdfPTable(4);
			table.setWidthPercentage(80);
			table.setTotalWidth(new float[]{ 90, 110,50,70 });
			table.setHorizontalAlignment(Element.ALIGN_LEFT);
			createHeader(table,NEW_MATERIAL_HEADER_FOR_FFP);
			table.setHeaderRows(1);
		}
		if(table != null) {
			for(ModuleMaterialsDto moduleMaterials : moduleMaterialsList) {
				table.addCell(createCellWithoutBorder(moduleMaterials.getPartNumber(),1));
				table.addCell(createCellWithoutBorder(moduleMaterials.getNomenclature(),1));
				if(TIME_MATERIAL.equalsIgnoreCase(proposalType)) {
					table.addCell(createCellWithoutBorder(String.valueOf(moduleMaterials.getQuantity()),1));
					table.addCell(createCellWithoutBorder(String.valueOf(moduleMaterials.getFallout() != null ? moduleMaterials.getFallout() : ""),1));
					table.addCell(createCellWithoutBorder(convertNumberToCurrency(moduleMaterials.getQuotePrice()),1));
					table.addCell(createCellWithoutBorder(convertNumberToCurrency(moduleMaterials.getQuantity() * moduleMaterials.getQuotePrice()),1));
				}else{
					if(moduleMaterials.getFallout() == null) {
						table.addCell(createCellWithoutBorder(String.valueOf(moduleMaterials.getQuantity()),1));
					}else{
						table.addCell(createCellWithoutBorder("X",1));
					}
				}
				if(DISCOUNTABLE.equalsIgnoreCase(moduleMaterials.getPriceCategory())) {
					table.addCell(createCellWithoutBorder("Yes",1));
				}else{
					table.addCell(createCellWithoutBorder("No",1));
				}
			}
			document.add(table);
		}
		LOGGER.debug("Class::PdfCreationManager, Method::createModuleMaterials::Exit");
	}


	/**
	 * @param document
	 * @param moduleOperationsList
	 * @throws DocumentException
	 */
	private void createModuleOperations(Document document, List<ModuleOperationsDto> moduleOperationsList)
			throws DocumentException {
		LOGGER.debug("Class::PdfCreationManager, Method::createModuleOperations::Start");
		PdfPTable table = new PdfPTable(2);
		table.setHorizontalAlignment(Element.ALIGN_LEFT);
		table.setWidthPercentage(50); 
		createOperationHeader(table);
		table.setHeaderRows(1);
		for(ModuleOperationsDto moduleOperations : moduleOperationsList) {
			table.addCell(createCellWithoutBorder(moduleOperations.getOperations(),2));
		}
		document.add(table);
		LOGGER.debug("Class::PdfCreationManager, Method::createModuleOperations::Exit");
	}


	/**
	 * @param document
	 * @param proposalType
	 * @param engineMaterialRepairList
	 * @throws DocumentException
	 */
	private void createEngineRepairMaterials(Document document, String proposalType,
			List<EngineMaterialRepairDto> engineMaterialRepairList,List<EngineMaterialsDto> engineMaterialsList) throws DocumentException {
		LOGGER.debug("Class::PdfCreationManager, Method::createEngineRepairMaterials::Start");
		document.add(new Phrase("REPAIRS & OTHER SERVICES",headerFontWithBold));
		PdfPTable table = null;
		if(TIME_MATERIAL.equalsIgnoreCase(proposalType)) {
			table = new PdfPTable(6);
			table.setWidthPercentage(100);
			table.setTotalWidth(new float[]{90,100,50,90,90,100 });
			table.setHorizontalAlignment(Element.ALIGN_LEFT);
			createHeader(table,REPAIR_MATERIAL_HEADER_FOR_T_AND_M);
			table.setHeaderRows(1);
		}else if(FIXED_FIRM_PRICE.equalsIgnoreCase(proposalType)){
			table = new PdfPTable(4);
			table.setWidthPercentage(100);
			table.setTotalWidth(new float[]{ 100,110,50,100 });
			table.setHorizontalAlignment(Element.ALIGN_LEFT);
			createHeader(table,REPAIR_MATERIAL_HEADER_FOR_FFP);
			table.setHeaderRows(1);
		}
		List<String> falloutNewMaterial = new ArrayList<>();
		for(EngineMaterialsDto engineMaterialsDto : engineMaterialsList) {
			if(engineMaterialsDto.getFallout() != null  && engineMaterialsDto.getFallout() != 0) {
				falloutNewMaterial.add(engineMaterialsDto.getPartNumber());
			}
		}
		if(table != null) {
			for(EngineMaterialRepairDto engineMaterialRepair : engineMaterialRepairList) {
				table.addCell(createCellWithoutBorder(engineMaterialRepair.getPartNumber(),1));
				table.addCell(createCellWithoutBorder(engineMaterialRepair.getNomenclature(),1));
				if(TIME_MATERIAL.equalsIgnoreCase(proposalType)) {
					table.addCell(createCellWithoutBorder(String.valueOf(engineMaterialRepair.getQuantity()),1));
					table.addCell(createCellWithoutBorder(convertNumberToCurrency(engineMaterialRepair.getQuotePrice()),1));
					table.addCell(createCellWithoutBorder(convertNumberToCurrency(engineMaterialRepair.getQuantity() * engineMaterialRepair.getQuotePrice()),1));
				}else if(FIXED_FIRM_PRICE.equalsIgnoreCase(proposalType)){
					if(engineMaterialRepair.getPartNumber() != null && !falloutNewMaterial.contains(engineMaterialRepair.getPartNumber())) {
						table.addCell(createCellWithoutBorder(String.valueOf(engineMaterialRepair.getQuantity()),1));
					}else if(engineMaterialRepair.getPartNumber() != null && falloutNewMaterial.contains(engineMaterialRepair.getPartNumber())) {
						table.addCell(createCellWithoutBorder("X",1));
					}
				}
				table.addCell(createCellWithoutBorder(engineMaterialRepair.getServiceRendered(),1));
			}
			document.add(table);
		}
		LOGGER.debug("Class::PdfCreationManager, Method::createEngineRepairMaterials::Exit");
	}


	/**
	 * @param document
	 * @param proposalType
	 * @param engineMaterialsList
	 * @throws DocumentException
	 */
	private void createEngineMaterials(Document document, String proposalType,
			List<EngineMaterialsDto> engineMaterialsList) throws DocumentException {
		LOGGER.debug("Class::PdfCreationManager, Method::createEngineMaterials::Start");
		document.add(new Phrase("NEW MATERIALS",headerFontWithBold));
		PdfPTable table = null;
		if(TIME_MATERIAL.equalsIgnoreCase(proposalType)) {
			table = new PdfPTable(7);
			table.setWidthPercentage(100);
			table.setTotalWidth(new float[]{ 80, 105,50,50,75,75,70});
			table.setHorizontalAlignment(Element.ALIGN_LEFT);
			createHeader(table,NEW_MATERIAL_HEADER_FOR_T_AND_M);
			table.setHeaderRows(1);
		}else if(FIXED_FIRM_PRICE.equalsIgnoreCase(proposalType)){
			table = new PdfPTable(4);
			table.setWidthPercentage(100);
			table.setTotalWidth(new float[]{ 90, 110,50,70 });
			table.setHorizontalAlignment(Element.ALIGN_LEFT);
			createHeader(table,NEW_MATERIAL_HEADER_FOR_FFP);
			table.setHeaderRows(1);
		}
		if(table != null) {
			for(EngineMaterialsDto engineMaterials : engineMaterialsList) {
				table.addCell(createCellWithoutBorder(engineMaterials.getPartNumber(),1));
				table.addCell(createCellWithoutBorder(engineMaterials.getNomenclature(),1));
				if(TIME_MATERIAL.equalsIgnoreCase(proposalType)) {
					table.addCell(createCellWithoutBorder(String.valueOf(engineMaterials.getQuantity()),1));
					table.addCell(createCellWithoutBorder(String.valueOf(engineMaterials.getFallout() != null ? engineMaterials.getFallout() : ""),1));
					table.addCell(createCellWithoutBorder(convertNumberToCurrency(engineMaterials.getQuotePrice()),1));
					table.addCell(createCellWithoutBorder(convertNumberToCurrency(engineMaterials.getQuantity() * engineMaterials.getQuotePrice()),1));
				}else{
					if(engineMaterials.getFallout() == null) {
						table.addCell(createCellWithoutBorder(String.valueOf(engineMaterials.getQuantity()),1));
					}else{
						table.addCell(createCellWithoutBorder("X",1));
					}
				}
				if(DISCOUNTABLE.equalsIgnoreCase(engineMaterials.getPriceCategory())) {
					table.addCell(createCellWithoutBorder("Yes",1));
				}else{
					table.addCell(createCellWithoutBorder("No",1));
				}
			}
			document.add(table);
		}
		LOGGER.debug("Class::PdfCreationManager, Method::createEngineMaterials::Exit");
	}


	/**
	 * @param document
	 * @param engineOperationsList
	 * @throws DocumentException
	 */
	private void createEngineOperations(Document document, List<EngineOperationsDto> engineOperationsList)
			throws DocumentException {
		LOGGER.debug("Class::PdfCreationManager, Method::createEngineOperations::Start");
		PdfPTable table = new PdfPTable(2);
		table.setHorizontalAlignment(Element.ALIGN_LEFT);
		table.setWidthPercentage(50);
		createOperationHeader(table);
		table.setHeaderRows(1);
		for(EngineOperationsDto engineOperations : engineOperationsList) {
			table.addCell(createCellWithoutBorder(engineOperations.getOperations(),2));
		}
		document.add(table);
		LOGGER.debug("Class::PdfCreationManager, Method::createEngineOperations::Exit");
	}
	
	/**
	 * @param document
	 * @param engineOperationsList
	 * @throws DocumentException
	 */
	private void createEngineOperationsWithQuotePrice(Document document, List<EngineOperationsDto> engineOperationsList)
			throws DocumentException {
		LOGGER.debug("Class::PdfCreationManager, Method::createEngineOperations::Start");
		PdfPTable table = new PdfPTable(3);
		table.setHorizontalAlignment(Element.ALIGN_LEFT);
		table.setWidthPercentage(75);
		createOperationHeaderForEngine(table);
		table.setHeaderRows(1);
		for(EngineOperationsDto engineOperations : engineOperationsList) {
			table.addCell(createCellWithoutBorder(engineOperations.getOperations(),2));
			table.addCell(createCellWithoutBorder(convertNumberToCurrency(engineOperations.getLaborQuotePrice()),1));
		}
		document.add(table);
		LOGGER.debug("Class::PdfCreationManager, Method::createEngineOperations::Exit");
	}
	


	/**
	 * @param document
	 * @param grandModuleTotalsList
	 * @throws DocumentException
	 */
	private void displayGrandTotals(Document document, List<ModulePdfDetailsDto> grandModuleTotalsList,String proposalType,CommercialViewDto commercialViewDto)
			throws DocumentException {
		LOGGER.debug("Class::PdfCreationManager, Method::displayGrandTotals::Start");
		
		document.add(new Phrase("OVERALL SUMMARY",headerFontWithBold));
		if(TIME_MATERIAL.equalsIgnoreCase(proposalType)) {
			PdfPTable table = new PdfPTable(5);
			table.setTotalWidth(new float[]{ 120, 90,90,90,90 });
			table.setHorizontalAlignment(Element.ALIGN_LEFT);
			table.setWidthPercentage(100);
			createHeader(table,TECHNICAL_MODULE_HEADER_GRAND);
			for(ModulePdfDetailsDto temp : grandModuleTotalsList) {
				table.addCell(createCellWithoutBorderAndBold(temp.getModule(),1));
				if(temp.getLabor() != null) {
					table.addCell(createCellWithoutBorder(convertNumberToCurrency(temp.getLabor()),1));
				}else{
					 table.addCell(createCellWithoutBorder("",1));
				}
				if(temp.getMaterials() != null) {
					table.addCell(createCellWithoutBorder(convertNumberToCurrency(temp.getMaterials()),1));
				}else{
					 table.addCell(createCellWithoutBorder("",1));
				}
			    if(temp.getSpecialServices() != null) {
			    	table.addCell(createCellWithoutBorder(convertNumberToCurrency(temp.getSpecialServices()),1));
			    }else{
					 table.addCell(createCellWithoutBorder("",1));
				}
			    if("Total Quote Price".equalsIgnoreCase(temp.getModule())) {
			    	float overAllDiscount = commercialViewDto.getOverAllDiscount();
			    	Double discountedTotalPrice = temp.getTotalPrice() - temp.getTotalPrice() * (overAllDiscount/100); 
					table.addCell(createCellWithoutBorder(convertNumberToCurrency(discountedTotalPrice),1));
			    }else{
			    	table.addCell(createCellWithoutBorder(convertNumberToCurrency(temp.getTotalPrice()),1));
			    }
			}
			
			document.add(table);
		}else{
			PdfPTable table = new PdfPTable(2);
			table.setTotalWidth(new float[]{ 120, 100});
			table.setHorizontalAlignment(Element.ALIGN_LEFT);
			table.setWidthPercentage(50);
			float overAllDiscount = commercialViewDto.getOverAllDiscount();
			createHeader(table,TECHNICAL_MODULE_HEADER_GRAND_FFP);
			for(ModulePdfDetailsDto temp : grandModuleTotalsList) {
				if("Total Quote Price".equalsIgnoreCase(temp.getModule())) {
					table.addCell(createCellWithoutBorderAndBold(temp.getModule(),1));
					Double discountedTotalPrice = temp.getTotalPrice() - temp.getTotalPrice() * (overAllDiscount/100); 
					table.addCell(createCellWithoutBorder(convertNumberToCurrency(discountedTotalPrice),1));
				}else{
					table.addCell(createCellWithoutBorderAndBold(temp.getModule(),1));
					table.addCell(createCellWithoutBorder("",1));
				}
			}
			
			document.add(table);
		}
		LOGGER.debug("Class::PdfCreationManager, Method::displayGrandTotals::Exit");
	}


	/**
	 * @param serviceBulletinsDtoList
	 * @param grandModuleTotalsList
	 * @param commercialViewDto 
	 */
	private void calculateSbPriceNewPriceCategoryAndGrantTotal(List<ServiceBulletinsDto> serviceBulletinsDtoList,
			List<ModulePdfDetailsDto> grandModuleTotalsList, CommercialViewDto commercialViewDto) {
		if(serviceBulletinsDtoList != null && serviceBulletinsDtoList.size() > 0) {
			ModulePdfDetailsDto modulePdfDetailsDto= getSBModulePriceDetail(serviceBulletinsDtoList);
			if(modulePdfDetailsDto != null) {
				grandModuleTotalsList.add(modulePdfDetailsDto);
			}
		}
		List<PriceCategoryDto> priceCategoryList = commercialViewDto.getPriceCategoryList();
		if(priceCategoryList != null && priceCategoryList.size() > 0) {
			for(PriceCategoryDto priceCategoryDto : priceCategoryList) {
				ModulePdfDetailsDto modulePdfDetailsDto = new ModulePdfDetailsDto();
				modulePdfDetailsDto.setModule(priceCategoryDto.getPriceCategoryName());
				modulePdfDetailsDto.setTotalPrice(Double.valueOf(priceCategoryDto.getPriceCategoryQuotePrice()));
				grandModuleTotalsList.add(modulePdfDetailsDto);
			}
		}
		
		ModulePdfDetailsDto modulePdfDetailsDto2 = new ModulePdfDetailsDto();
		modulePdfDetailsDto2.setModule("Total Quote Price");
		modulePdfDetailsDto2.setTotalPrice(getGrandTotal(grandModuleTotalsList));
		grandModuleTotalsList.add(modulePdfDetailsDto2);
	}


	/**
	 * @param document
	 * @param grandModuleTotalDto
	 * @param modulePdfDetailsDto
	 * @throws DocumentException
	 */
	private void createSummaryByModulesForEngine(Document document, ModulePdfDetailsDto grandModuleTotalDto,
			ModulePdfDetailsDto modulePdfDetailsDto,String proposalType) throws DocumentException {
		LOGGER.debug("Class::PdfCreationManager, Method::createSummaryByModulesForEngine::Start");
		if(TIME_MATERIAL.equalsIgnoreCase(proposalType)) {
			PdfPTable table = new PdfPTable(4);
			table.setHorizontalAlignment(Element.ALIGN_LEFT);
			table.setWidthPercentage(100);
			createHeader(table,TECHNICAL_MODULE_HEADER);
			table.addCell(createCellWithoutBorderWithExtraBottonPadding(convertNumberToCurrency(modulePdfDetailsDto.getLabor()),1,10f));
			table.addCell(createCellWithoutBorderWithExtraBottonPadding(convertNumberToCurrency(modulePdfDetailsDto.getMaterials()),1,10f));
			table.addCell(createCellWithoutBorderWithExtraBottonPadding(convertNumberToCurrency(modulePdfDetailsDto.getSpecialServices()),1,10f));
			table.addCell(createCellWithoutBorderWithExtraBottonPadding(convertNumberToCurrency(modulePdfDetailsDto.getTotalPrice()),1,10f));
			document.add(table);
		}
		if(grandModuleTotalDto.getLabor() != null) {
			grandModuleTotalDto.setLabor(grandModuleTotalDto.getLabor() + modulePdfDetailsDto.getLabor());
		} else {
			grandModuleTotalDto.setLabor(modulePdfDetailsDto.getLabor());
		}
		if(grandModuleTotalDto.getMaterials() != null) {
			grandModuleTotalDto.setMaterials(grandModuleTotalDto.getMaterials() + modulePdfDetailsDto.getMaterials());
		}else{
			 grandModuleTotalDto.setMaterials(modulePdfDetailsDto.getMaterials());
		}
		
		if(grandModuleTotalDto.getSpecialServices() != null) {
			grandModuleTotalDto.setSpecialServices(grandModuleTotalDto.getSpecialServices() + modulePdfDetailsDto.getSpecialServices());
		}else{
			 grandModuleTotalDto.setSpecialServices(modulePdfDetailsDto.getSpecialServices());
		}
		if(grandModuleTotalDto.getTotalPrice() != null) {
			grandModuleTotalDto.setTotalPrice(grandModuleTotalDto.getTotalPrice() + modulePdfDetailsDto.getTotalPrice());
		}else{
			 grandModuleTotalDto.setTotalPrice( modulePdfDetailsDto.getTotalPrice());
		}
		LOGGER.debug("Class::PdfCreationManager, Method::createSummaryByModulesForEngine::Exit");
	}

	/**
	 * @param grandModuleTotalsList
	 * @return
	 */
	private double getGrandTotal(List<ModulePdfDetailsDto> grandModuleTotalsList) {
		double grandTotal = 0.0;
		for(ModulePdfDetailsDto modulePdfDetailsDto : grandModuleTotalsList) {
			grandTotal = grandTotal +modulePdfDetailsDto.getTotalPrice();
		}
		return grandTotal;
	}


	/**
	 * @param serviceBulletinsDtoList
	 * @return
	 */
	private ModulePdfDetailsDto getSBModulePriceDetail(List<ServiceBulletinsDto> serviceBulletinsDtoList) {
		ModulePdfDetailsDto modulePdfDetailsDto = null;
		if(serviceBulletinsDtoList != null && serviceBulletinsDtoList.size() > 0) {
			boolean isSbChecked =false;
			for(ServiceBulletinsDto serviceBulletinsDto : serviceBulletinsDtoList) {
				if(TRUE.equalsIgnoreCase(serviceBulletinsDto.getServiceBulletinChecked())) {
					if(modulePdfDetailsDto == null) {
						modulePdfDetailsDto = new ModulePdfDetailsDto();
					}
					isSbChecked = true;
					if(modulePdfDetailsDto.getTotalPrice() != null) {
						modulePdfDetailsDto.setTotalPrice(modulePdfDetailsDto.getTotalPrice() + serviceBulletinsDto.getPrice());
					} else{
						modulePdfDetailsDto.setTotalPrice(Double.valueOf(serviceBulletinsDto.getPrice()));
					}
				}
			}
			if(modulePdfDetailsDto != null) {
				modulePdfDetailsDto.setModule("Service Bulletin");
			}
			/*if(!isSbChecked) {
				modulePdfDetailsDto.setTotalPrice(0.0);
			}*/
		}
		return modulePdfDetailsDto;
	}


	/**
	 * @param modules
	 * @param engineModuleMap
	 * @return
	 */
	private ModulePdfDetailsDto getModulePriceDetails(ModulesDto modules, 	Map<String, String> engineModuleMap) {
		LOGGER.debug("Class::PdfCreationManager, Method::getModulePriceDetails::Start");
		ModulePdfDetailsDto modulePdfDetailsDto = new ModulePdfDetailsDto();
		List<ModuleMaterialsDto> moduleMaterialsList = modules.getModuleMaterialsList();
		List<ModuleMaterialRepairDto> moduleMaterialsRepairList = modules.getModuleMaterialsRepairList();
		List<ModuleOperationsDto> moduleOperationsList = modules.getModuleOperationsList();
		modulePdfDetailsDto.setModule(engineModuleMap.get(modules.getModule()));
		float totalLaborPrice = 0;
		float totalMaterialsPrice = 0;
		float totalRepairMaterialsPrice = 0;
		for(ModuleOperationsDto moduleOperationsDto: moduleOperationsList) {
			totalLaborPrice = totalLaborPrice + moduleOperationsDto.getLaborQuotePrice();
		}
		for(ModuleMaterialsDto moduleMaterialsDto: moduleMaterialsList) {
			totalMaterialsPrice = totalMaterialsPrice + moduleMaterialsDto.getQuotePrice() * moduleMaterialsDto.getQuantity();
		}
		for(ModuleMaterialRepairDto moduleMaterialRepairDto: moduleMaterialsRepairList) {
			totalRepairMaterialsPrice = totalRepairMaterialsPrice + moduleMaterialRepairDto.getQuotePrice() * moduleMaterialRepairDto.getQuantity();
		}
		modulePdfDetailsDto.setLabor(Double.valueOf(totalLaborPrice));
		modulePdfDetailsDto.setMaterials(Double.valueOf(totalMaterialsPrice));
		modulePdfDetailsDto.setSpecialServices(Double.valueOf(totalRepairMaterialsPrice));
		modulePdfDetailsDto.setTotalPrice(Double.valueOf(totalLaborPrice)+Double.valueOf(totalMaterialsPrice)+Double.valueOf(totalRepairMaterialsPrice));
		LOGGER.debug("Class::PdfCreationManager, Method::getModulePriceDetails::Exit");
		return modulePdfDetailsDto;
	}


	/**
	 * @param modelEngine
	 * @param engineLovMap
	 * @return
	 */
	private ModulePdfDetailsDto getEnginePriceDetails(ModelEngineDto modelEngine, Map<String, String> engineLovMap) {
		LOGGER.debug("Class::PdfCreationManager, Method::getEnginePriceDetails::Start");
		ModulePdfDetailsDto modulePdfDetailsDto = new ModulePdfDetailsDto();
		List<EngineMaterialRepairDto> engineMaterialRepairList = modelEngine.getEngineMaterialRepairList();
		List<EngineMaterialsDto> engineMaterialsList =  modelEngine.getEngineMaterialsList();
		List<EngineOperationsDto> engineOperationsList = modelEngine.getEngineOperationsList();
		modulePdfDetailsDto.setModule(engineLovMap.get(modelEngine.getEngine()));
		float totalLaborPrice = 0;
		float totalMaterialsPrice = 0;
		float totalRepairMaterialsPrice = 0;
		for(EngineOperationsDto engineOperationsDto: engineOperationsList) {
			totalLaborPrice = totalLaborPrice + engineOperationsDto.getLaborQuotePrice();
		}
		for(EngineMaterialsDto engineMaterialsDto: engineMaterialsList) {
			totalMaterialsPrice = totalMaterialsPrice + engineMaterialsDto.getQuotePrice() * engineMaterialsDto.getQuantity();
		}
		for(EngineMaterialRepairDto engineMaterialRepairDto: engineMaterialRepairList) {
			totalRepairMaterialsPrice = totalRepairMaterialsPrice + engineMaterialRepairDto.getQuotePrice() * engineMaterialRepairDto.getQuantity();
		}
		modulePdfDetailsDto.setLabor(Double.valueOf(totalLaborPrice));
		modulePdfDetailsDto.setMaterials(Double.valueOf(totalMaterialsPrice));
		modulePdfDetailsDto.setSpecialServices(Double.valueOf(totalRepairMaterialsPrice));
		modulePdfDetailsDto.setTotalPrice(Double.valueOf(totalLaborPrice)+Double.valueOf(totalMaterialsPrice)+Double.valueOf(totalRepairMaterialsPrice));
		LOGGER.debug("Class::PdfCreationManager, Method::getEnginePriceDetails::Exit");
		return modulePdfDetailsDto;
	}


	/**
	 * @param engineLovList
	 * @return
	 */
	private Map<String, String> getEngineLovMapWithDisplayName(List<EngineLov> engineLovList) {
		Map<String, String> returnMap = new TreeMap<>();
		for(EngineLov engineLov : engineLovList) {
			returnMap.put(engineLov.getEngine(), engineLov.getEngineDisplayName());
		}
		return returnMap;
	}
	
	/**
	 * @param engineLovList
	 * @return
	 */
	private Map<String, String> getEngineLovMapWithDiscription(List<EngineLov> engineLovList) {
		Map<String, String> returnMap = new TreeMap<>();
		for(EngineLov engineLov : engineLovList) {
			returnMap.put(engineLov.getEngine(), engineLov.getEngineDiscription());
		}
		return returnMap;
	}


	private Map<String, String> getEngineModuleMap(List<EngineModule> engineModuleList) {
		Map<String, String> returnMap = new TreeMap<>();
		for(EngineModule engineModule : engineModuleList) {
			returnMap.put(engineModule.getModuleCode(), engineModule.getModuleName());
		}
		return returnMap;
	}


	private void addTitle(Document document) throws DocumentException {
		Font headerFont = FontFactory.getFont(FontFactory.TIMES_ROMAN, 15,Font.BOLD);
		headerFont.setColor(myColorpan);
		PdfPTable table = new PdfPTable(3);
		table.setWidthPercentage(100);
		PdfPCell cell = new PdfPCell();
		cell.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell);		
		PdfPCell cell1 = new PdfPCell(new Phrase("SOW Technical Detail",headerFont));
		cell1.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell1);
		PdfPCell cell2 = new PdfPCell();
		cell2.setBorder(Rectangle.NO_BORDER);
		table.addCell(cell2);	
		document.add(table);
	}
	
	/**
	 * @param document
	 * @throws DocumentException
	 */
	private void addSummaryTitle(Document document) throws DocumentException {
		Font headerFont = FontFactory.getFont(FontFactory.TIMES_ROMAN, 15,Font.BOLD);
		headerFont.setColor(myColorpan);
		PdfPTable table = new PdfPTable(4);
		table.setWidthPercentage(100);
		PdfPCell cell = new PdfPCell();
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setPaddingTop(10f); 
		table.addCell(cell);		
		PdfPCell cell1 = new PdfPCell(new Phrase("Summary By Module",headerFont));
		cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell1.setColspan(2);
		cell1.setBorder(Rectangle.NO_BORDER);
		cell1.setPaddingTop(10f); 
		table.addCell(cell1);
		PdfPCell cell2 = new PdfPCell();
		cell2.setBorder(Rectangle.NO_BORDER);
		cell2.setPaddingTop(10f); 
		table.addCell(cell2);	
		document.add(table);
	}

	/**
	 * @param table
	 * @param headerList
	 */
	private void createHeader(PdfPTable table,String[] headerList) {
		for(String header :headerList) {
			headerFont.setColor(BaseColor.WHITE);
			PdfPCell cell = new PdfPCell(new Phrase(header,headerFont));
			cell.setBackgroundColor(myColorpan);
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setPaddingTop(5f); 
			cell.setPaddingBottom(5f); 
	        table.addCell(cell);
		}
	
	}

	/**
	 * @param table
	 */
	private void createOperationHeader(PdfPTable table) {
		for(String operation :OPERATION_HEADER) {
			headerFont.setColor(BaseColor.WHITE);
			PdfPCell cell = new PdfPCell(new Phrase(operation,headerFont));
			cell.setBorder(Rectangle.NO_BORDER);
			cell.setColspan(2);
	        cell.setBackgroundColor(myColorpan);
	        cell.setPaddingTop(5f); 
			cell.setPaddingBottom(5f); 
	        table.addCell(cell);
		}
	}
	
	/**
	 * @param table
	 */
	private void createOperationHeaderForEngine(PdfPTable table) {
		int count =0;
		for(String operation :OPERATION_HEADER_ENGINE) {
			headerFont.setColor(BaseColor.WHITE);
			PdfPCell cell = new PdfPCell(new Phrase(operation,headerFont));
			cell.setBorder(Rectangle.NO_BORDER);
			if(count ==0) {
				cell.setColspan(2);
			}else{
				cell.setColspan(1);
			}
	        cell.setBackgroundColor(myColorpan);
	        cell.setPaddingTop(5f); 
			cell.setPaddingBottom(5f); 
	        table.addCell(cell);
	        count++;
		}
	}
	
	/**
	 * @param document
	 * @param engineInfoDto
	 * @throws DocumentException
	 */
	private void addHeaderDetails(Document document, EngineInfoDto engineInfoDto) throws DocumentException {
		LOGGER.debug("Class::PdfCreationManager, Method::addHeaderDetails::Start");		
		PdfPTable table = new PdfPTable(2);
		table.setHorizontalAlignment(Element.ALIGN_LEFT);
	    table.setWidthPercentage(50); 
		table.addCell(createCellWithoutBorder("Customer",1));
	    table.addCell(createCellWithoutBorder(engineInfoDto.getCustomerName(),1));
	    table.addCell(createCellWithoutBorder("Oppty ID #",1));
	    table.addCell(createCellWithoutBorder(engineInfoDto.getOpptyId(),1));
		table.addCell(createCellWithoutBorder("Oppty Rev#",1));
	    table.addCell(createCellWithoutBorder(String.valueOf((int)engineInfoDto.getOpptyRev()),1));
	    table.addCell(createCellWithoutBorder("Oppty Type",1));
	    table.addCell(createCellWithoutBorder(engineInfoDto.getOpptyType(),1)); 
	    table.addCell(createCellWithoutBorder("Oppty Date",1));
	    table.addCell(createCellWithoutBorder(convertDateToString(engineInfoDto.getProposalDate()),1));
	    table.addCell(createCellWithoutBorder("Machine Model",1));
	    table.addCell(createCellWithoutBorder(engineInfoDto.getModel(),1));
	    table.addCell(createCellWithoutBorder("Serial Number",1));
	    table.addCell(createCellWithoutBorder(engineInfoDto.getSerialNumber(),1));
	    table.addCell(createCellWithoutBorder("Type",1));
	    table.addCell(createCellWithoutBorder(engineInfoDto.getSowDescription(),1));
	   	document.add(table);
	   	LOGGER.debug("Class::PdfCreationManager, Method::addHeaderDetails::Exit");	
	}
	
	private String convertDateToString(Date date) {
		String returnDate = "";
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MMM-dd");
		if(date != null){
			returnDate = formatter.format(date);
		}
		return returnDate;
	}
	private String convertNumberToCurrency(float value) {
		NumberFormat us = NumberFormat.getCurrencyInstance(Locale.US);
		return us.format(value);
	}
	
	private String convertNumberToCurrency(double value) {
		NumberFormat us = NumberFormat.getCurrencyInstance(Locale.US);
		return us.format(value);
	}
	
	/**
	 * @param value
	 * @param columnSpan
	 * @return
	 */
	private PdfPCell createCellWithoutBorder(String value, int columnSpan) {
		PdfPCell cell = new PdfPCell(new Phrase(value,textFont));
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setColspan(columnSpan);
		cell.setPaddingTop(5f); 
		cell.setPaddingBottom(5f); 
		return cell;
	}
	
	/**
	 * @param value
	 * @param columnSpan
	 * @param bottomPadValue
	 * @return
	 */
	private PdfPCell createCellWithoutBorderWithExtraBottonPadding(String value, int columnSpan,float bottomPadValue) {
		PdfPCell cell = new PdfPCell(new Phrase(value,textFont));
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setColspan(columnSpan);
		cell.setPaddingTop(5f); 
		cell.setPaddingBottom(bottomPadValue); 
		return cell;
	}
	
	/**
	 * @param value
	 * @param columnSpan
	 * @return
	 */
	private PdfPCell createCellWithoutBorderAndBold(String value, int columnSpan) {
		PdfPCell cell = new PdfPCell(new Phrase(value,textFontBold));
		cell.setBorder(Rectangle.NO_BORDER);
		cell.setColspan(columnSpan);
		cell.setPaddingTop(5f); 
		cell.setPaddingBottom(5f); 
		return cell;
	}

	/**
	 * @param document
	 * @param engineInfoDto
	 * @throws DocumentException
	 */
	private void createSummaryByModuleDetailsNew(Document document, EngineInfoDto engineInfoDto) throws DocumentException {
		LOGGER.debug("Class::PdfCreationManager, Method::createSummaryByModuleDetailsNew::Start");		
		addSummaryTitle(document);
		addHeaderDetails(document,engineInfoDto);
		List<ModelEngineDto> modelEngineList = engineInfoDto.getModelEngineList();
		List<EngineModule> engineModuleList= engineModuleDAO.findEngineModule(engineInfoDto.getProduct());
		List<EngineLov> engineLovList= sowMasterMaterialDAO.getEngineLovList(engineInfoDto.getProduct());
		Map<String,String> engineModuleMap = getEngineModuleMap(engineModuleList);
		Map<String,String> engineLovMapWithDiscription = getEngineLovMapWithDiscription(engineLovList);
		Map<String,String> engineLovMapWithDisplayName = getEngineLovMapWithDisplayName(engineLovList);
		List<ServiceBulletinsDto> serviceBulletinsDtoList = engineInfoDto.getServiceBulletinList();
		List<ModulePdfDetailsDto> grandModuleTotalsList = new ArrayList<>();
		int count = 0;
		if(modelEngineList != null) {
			for(ModelEngineDto modelEngine : modelEngineList) {
				if(TRUE.equalsIgnoreCase(modelEngine.getEngineChecked())) {
					ModulePdfDetailsDto grandModuleTotalDto = new ModulePdfDetailsDto();
					if(count == 1) {
						document.newPage();
					}
					PdfPTable table = new PdfPTable(6);
					table.setWidthPercentage(100);
					table.setHeaderRows(1);
					table.setTotalWidth(new float[]{ 110, 50,60,70,80,80 });
					table.setHorizontalAlignment(Element.ALIGN_LEFT);
					createHeader(table,SUMMARY_BY_MODULE_HEADER);
					table.addCell(createCellWithoutBorderAndBold(engineLovMapWithDisplayName.get(modelEngine.getEngine()),6));
					ModulePdfDetailsDto modulePdfDetailsDto = getEnginePriceDetails(modelEngine,engineLovMapWithDiscription);
					grandModuleTotalDto.setModule(engineLovMapWithDisplayName.get(modelEngine.getEngine()));
					if(modulePdfDetailsDto != null) {
						createSummaryByModulesForEngine(table,document, grandModuleTotalDto, modulePdfDetailsDto);
					}
					
					List<ModulesDto> moduleList = modelEngine.getModuleList();
					if(moduleList != null) {
							for(ModulesDto modules : moduleList) {
								if(TRUE.equalsIgnoreCase(modules.getModuleChecked())) {
									ModulePdfDetailsDto modulePdfDetailsDtoForModule = getModulePriceDetails(modules,engineModuleMap);
									if(modulePdfDetailsDtoForModule != null) {
										createSummaryByModulesForEngine(table,document, grandModuleTotalDto,
												modulePdfDetailsDtoForModule);
									}
								}
							}
					}
					createTotalEngineEstimate(table,grandModuleTotalDto,engineLovMapWithDisplayName.get(modelEngine.getEngine()));
					grandModuleTotalsList.add(grandModuleTotalDto);
					if(count == modelEngineList.size()-1) {
						ModulePdfDetailsDto modulePdfDetailsDtoForSb= getSBModulePriceDetail(serviceBulletinsDtoList);
						table.addCell(createCellWithoutBorderAndBold("Service Bulletins",1));
						table.addCell(createCellWithoutBorderAndBold("",1));
						if(modulePdfDetailsDtoForSb != null) {
							if(modulePdfDetailsDtoForSb.getLabor() != null) {
								table.addCell(createCellWithoutBorder(convertNumberToCurrency(modulePdfDetailsDtoForSb.getLabor()),1));
							}else{
								 table.addCell(createCellWithoutBorder("",1));
							}
							if(modulePdfDetailsDtoForSb.getMaterials() != null) {
								table.addCell(createCellWithoutBorder(convertNumberToCurrency(modulePdfDetailsDtoForSb.getMaterials()),1));
							}else{
								 table.addCell(createCellWithoutBorder("",1));
							}
						    if(modulePdfDetailsDtoForSb.getSpecialServices() != null) {
						    	table.addCell(createCellWithoutBorder(convertNumberToCurrency(modulePdfDetailsDtoForSb.getSpecialServices()),1));
						    }else{
								 table.addCell(createCellWithoutBorder("",1));
							}
						    table.addCell(createCellWithoutBorder(convertNumberToCurrency(modulePdfDetailsDtoForSb.getTotalPrice()),1));
					    
						    ModulePdfDetailsDto modulePdfDetailsDtoForGrant = createGrandTotalDto(grandModuleTotalsList,modulePdfDetailsDtoForSb);
						    table.addCell(createCellWithoutBorderAndBold(modulePdfDetailsDtoForGrant.getModule(),1));
							table.addCell(createCellWithoutBorderAndBold("",1));
							if(modulePdfDetailsDtoForGrant.getLabor() != null) {
								table.addCell(createCellWithoutBorder(convertNumberToCurrency(modulePdfDetailsDtoForGrant.getLabor()),1));
							}else{
								 table.addCell(createCellWithoutBorder("",1));
							}
							if(modulePdfDetailsDtoForGrant.getMaterials() != null) {
								table.addCell(createCellWithoutBorder(convertNumberToCurrency(modulePdfDetailsDtoForGrant.getMaterials()),1));
							}else{
								 table.addCell(createCellWithoutBorder("",1));
							}
						    if(modulePdfDetailsDtoForGrant.getSpecialServices() != null) {
						    	table.addCell(createCellWithoutBorder(convertNumberToCurrency(modulePdfDetailsDtoForGrant.getSpecialServices()),1));
						    }else{
								 table.addCell(createCellWithoutBorder("",1));
							}
						    table.addCell(createCellWithoutBorder(convertNumberToCurrency(modulePdfDetailsDtoForGrant.getTotalPrice()),1));  
						}
					    
						document.add(table);
					}else{
						document.add(table);
					}
				}
				count++;
			}
		}
		LOGGER.debug("Class::PdfCreationManager, Method::createSummaryByModuleDetailsNew::Exit");
	}

	/**
	 * @param grandModuleTotalsList
	 * @param modulePdfDetailsDtoForSb
	 * @return
	 */
	private ModulePdfDetailsDto createGrandTotalDto(List<ModulePdfDetailsDto> grandModuleTotalsList,ModulePdfDetailsDto modulePdfDetailsDtoForSb) {
		LOGGER.debug("Class::PdfCreationManager, Method::createGrandTotalDto::Start");		
		ModulePdfDetailsDto modulePdfDetailsDtoForGrant = new ModulePdfDetailsDto();
		modulePdfDetailsDtoForGrant.setModule("TOTAL QUOTE PRICE");
		for(ModulePdfDetailsDto temp : grandModuleTotalsList) {
			if(modulePdfDetailsDtoForGrant.getLabor() != null) {
				modulePdfDetailsDtoForGrant.setLabor(modulePdfDetailsDtoForGrant.getLabor() + temp.getLabor());
			} else {
				modulePdfDetailsDtoForGrant.setLabor(temp.getLabor());
			}
			if(modulePdfDetailsDtoForGrant.getMaterials() != null) {
				modulePdfDetailsDtoForGrant.setMaterials(modulePdfDetailsDtoForGrant.getMaterials() + temp.getMaterials());
			}else{
				modulePdfDetailsDtoForGrant.setMaterials(temp.getMaterials());
			}
			
			if(modulePdfDetailsDtoForGrant.getSpecialServices() != null) {
				modulePdfDetailsDtoForGrant.setSpecialServices(modulePdfDetailsDtoForGrant.getSpecialServices() + temp.getSpecialServices());
			}else{
				modulePdfDetailsDtoForGrant.setSpecialServices(temp.getSpecialServices());
			}
			if(modulePdfDetailsDtoForGrant.getTotalPrice() != null) {
				modulePdfDetailsDtoForGrant.setTotalPrice(modulePdfDetailsDtoForGrant.getTotalPrice() + temp.getTotalPrice());
			}else{
				modulePdfDetailsDtoForGrant.setTotalPrice( temp.getTotalPrice());
			}
			
		}
		if(modulePdfDetailsDtoForGrant.getLabor() != null && modulePdfDetailsDtoForSb.getLabor() != null) {
			modulePdfDetailsDtoForGrant.setLabor(modulePdfDetailsDtoForGrant.getLabor() + modulePdfDetailsDtoForSb.getLabor());
		} 
		if(modulePdfDetailsDtoForGrant.getMaterials() != null && modulePdfDetailsDtoForSb.getMaterials() != null) {
			modulePdfDetailsDtoForGrant.setMaterials(modulePdfDetailsDtoForGrant.getMaterials() + modulePdfDetailsDtoForSb.getMaterials());
		}
		
		if(modulePdfDetailsDtoForGrant.getSpecialServices() != null && modulePdfDetailsDtoForSb.getSpecialServices() != null) {
			modulePdfDetailsDtoForGrant.setSpecialServices(modulePdfDetailsDtoForGrant.getSpecialServices() + modulePdfDetailsDtoForSb.getSpecialServices());
		}
		if(modulePdfDetailsDtoForGrant.getTotalPrice() != null && modulePdfDetailsDtoForSb.getTotalPrice() != null) {
			modulePdfDetailsDtoForGrant.setTotalPrice(modulePdfDetailsDtoForGrant.getTotalPrice() + modulePdfDetailsDtoForSb.getTotalPrice());
		}
		LOGGER.debug("Class::PdfCreationManager, Method::createGrandTotalDto::Exit");		
	    return modulePdfDetailsDtoForGrant;
	}


	/**
	 * @param table
	 * @param grandModuleTotalDto
	 * @param moduleName
	 */
	private void createTotalEngineEstimate(PdfPTable table, ModulePdfDetailsDto grandModuleTotalDto, String moduleName) {
		table.addCell(createCellWithoutBorderAndBold("Total "+moduleName+" Estimate",1));
		table.addCell(createCellWithoutBorder(grandModuleTotalDto.getFallOut(),1));
		table.addCell(createCellWithoutBorder(convertNumberToCurrency(grandModuleTotalDto.getLabor()),1));
		table.addCell(createCellWithoutBorder(convertNumberToCurrency(grandModuleTotalDto.getMaterials()),1));
		table.addCell(createCellWithoutBorder(convertNumberToCurrency(grandModuleTotalDto.getSpecialServices()),1));
		table.addCell(createCellWithoutBorder(convertNumberToCurrency(grandModuleTotalDto.getTotalPrice()),1));
		
	}


	/**
	 * @param table
	 * @param document
	 * @param grandModuleTotalDto
	 * @param modulePdfDetailsDto
	 * @throws DocumentException
	 */
	private void createSummaryByModulesForEngine(PdfPTable table, Document document, ModulePdfDetailsDto grandModuleTotalDto,
			ModulePdfDetailsDto modulePdfDetailsDto) throws DocumentException {
		LOGGER.debug("Class::PdfCreationManager, Method::createSummaryByModulesForEngine::Start");	
		table.addCell(createCellWithoutBorder(modulePdfDetailsDto.getModule(),1));
		table.addCell(createCellWithoutBorder(modulePdfDetailsDto.getFallOut(),1));
		table.addCell(createCellWithoutBorder(convertNumberToCurrency(modulePdfDetailsDto.getLabor()),1));
		table.addCell(createCellWithoutBorder(convertNumberToCurrency(modulePdfDetailsDto.getMaterials()),1));
		table.addCell(createCellWithoutBorder(convertNumberToCurrency(modulePdfDetailsDto.getSpecialServices()),1));
		table.addCell(createCellWithoutBorder(convertNumberToCurrency(modulePdfDetailsDto.getTotalPrice()),1));
		if(grandModuleTotalDto.getLabor() != null) {
			grandModuleTotalDto.setLabor(grandModuleTotalDto.getLabor() + modulePdfDetailsDto.getLabor());
		} else {
			grandModuleTotalDto.setLabor(modulePdfDetailsDto.getLabor());
		}
		if(grandModuleTotalDto.getMaterials() != null) {
			grandModuleTotalDto.setMaterials(grandModuleTotalDto.getMaterials() + modulePdfDetailsDto.getMaterials());
		}else{
			 grandModuleTotalDto.setMaterials(modulePdfDetailsDto.getMaterials());
		}
		
		if(grandModuleTotalDto.getSpecialServices() != null) {
			grandModuleTotalDto.setSpecialServices(grandModuleTotalDto.getSpecialServices() + modulePdfDetailsDto.getSpecialServices());
		}else{
			 grandModuleTotalDto.setSpecialServices(modulePdfDetailsDto.getSpecialServices());
		}
		if(grandModuleTotalDto.getTotalPrice() != null) {
			grandModuleTotalDto.setTotalPrice(grandModuleTotalDto.getTotalPrice() + modulePdfDetailsDto.getTotalPrice());
		}else{
			 grandModuleTotalDto.setTotalPrice( modulePdfDetailsDto.getTotalPrice());
		}
		LOGGER.debug("Class::PdfCreationManager, Method::createSummaryByModulesForEngine::Exit");
	}
	
	private void checkRemainingSpaceAvailable(Document document,PdfWriter writer) {
		float availableSpace = writer.getVerticalPosition(false) - document.bottomMargin();
		if(availableSpace <= 75) {
			document.newPage();
		}
	}
	

	private boolean isNewPriceCategoryExist(PriceCategoryDto[] priceCategoryList, String modules) {
		boolean returnValue = false;
		if(priceCategoryList != null && priceCategoryList.length >0) {
			for(PriceCategoryDto temp : priceCategoryList) {
				if(temp.getPriceCategoryName() != null && temp.getPriceCategoryName().equalsIgnoreCase(modules)) {
					returnValue = true;
				}
			}
		}
		return returnValue;
	}


	
}
