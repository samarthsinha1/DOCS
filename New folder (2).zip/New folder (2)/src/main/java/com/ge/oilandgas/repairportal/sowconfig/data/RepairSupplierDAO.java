package com.ge.oilandgas.repairportal.sowconfig.data;

import java.util.List;

import com.ge.oilandgas.repairportal.sowconfig.entity.RepairSupplier;



public interface RepairSupplierDAO {
	
	// EngineInfo findByModel(String model);
	 List<RepairSupplier> findAllRS();

}
