package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "ong_sowcfg_std_Engine_lov")
public class EngineLov {
	
	@Id

	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private Long id;
	
	@Column(name="engine")
	private String engine;
	
	@Column(name="engine_display_name")
	private String engineDisplayName;

	@Column(name="engine_discription")
	private String engineDiscription;
	
	@Column(name="plc_engine_code")
	private String plcEngineCode;
	
	@Column(name="plc_product_type")
	private String product;


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEngine() {
		return engine;
	}

	public void setEngine(String engine) {
		this.engine = engine;
	}

	public String getEngineDisplayName() {
		return engineDisplayName;
	}

	public void setEngineDisplayName(String engineDisplayName) {
		this.engineDisplayName = engineDisplayName;
	}

	public String getEngineDiscription() {
		return engineDiscription;
	}

	public void setEngineDiscription(String engineDiscription) {
		this.engineDiscription = engineDiscription;
	}

	public String getPlcEngineCode() {
		return plcEngineCode;
	}

	public void setPlcEngineCode(String plcEngineCode) {
		this.plcEngineCode = plcEngineCode;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}
	
	

}
