package com.ge.oilandgas.repairportal.sowconfig.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ge.oilandgas.repairportal.sowconfig.entity.ReportFields;


@Repository
public interface ReportFieldsRepository  extends GenericCrudRepository<ReportFields, Long> {
	
	@Query("SELECT s from ReportFields s where s.engineInfoId=?1")
	List<ReportFields> findReportFieldsByEngineInfoId(Long engineInfoId);
	

}
