package com.ge.oilandgas.repairportal.sowconfig.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ge.oilandgas.repairportal.sowconfig.bo.CommonPostDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineModuleDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineOperationListDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ListPriceDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ModuleOperationListDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.OperationTypeLovDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.OpptyTypeLovDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ProductLovDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ProposalTypeLovDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.RepairSupplierDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ServiceRenderedDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ShopDetailDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.SowMasterMaterialDtoForUI;
import com.ge.oilandgas.repairportal.sowconfig.bo.StdSbLovDto;
import com.ge.oilandgas.repairportal.sowconfig.manager.SowMasterManager;
import com.ge.oilandgas.repairportal.sowconfig.service.api.SowMasterService;

@RequestMapping("/service/sowconfigurator")
@RestController
public class SowMasterServiceImpl implements SowMasterService{
	
	@Autowired
	SowMasterManager sowMasterManager;

	@RequestMapping(value="/shopDetail/{engineModel}/{product}", method= RequestMethod.GET,produces = "application/json")
	public ResponseTemplateDto<ShopDetailDto> getEngineModelShopDetails(@PathVariable("engineModel") String engineModel, @PathVariable("product") String product) {
		return sowMasterManager.getEngineModelShopDetails(engineModel, product);
	}


	@RequestMapping(value="/serviceRendered", method= RequestMethod.GET,produces = "application/json")
	public ResponseTemplateDto<ServiceRenderedDto> getServices() {
	
		return sowMasterManager.getServices();
	}

	@RequestMapping(value="/repairSupplier", method= RequestMethod.GET,produces = "application/json")
	public ResponseTemplateDto<RepairSupplierDto> getRepairSupplier() {
		
		return sowMasterManager.getRepairSupplier();
	}


	@RequestMapping(value="/engineModule/{product}", method= RequestMethod.GET,produces = "application/json")
	public ResponseTemplateDto<EngineModuleDto> getEngineModule(@PathVariable("product") String product) {

		return sowMasterManager.getEngineModule(product);

	}
	

	@RequestMapping(value="/engineOperations/{product}/{engine}", method= RequestMethod.GET,produces = "application/json")
	public ResponseTemplateDto<List<EngineOperationListDto>> getEngineOperationList(@PathVariable("product") String product,@PathVariable("engine") String engine) {

		return sowMasterManager.getEngineOperationList(engine,product);
	}
	@RequestMapping(value="/moduleOperations/{product}/{engine}/{module}", method= RequestMethod.GET,produces = "application/json")
	public ResponseTemplateDto<List<ModuleOperationListDto>> getModuleOperationList(@PathVariable("product") String product,@PathVariable("engine") String engine,@PathVariable("module") String module) {

		return sowMasterManager.getModuleOperationList(engine, module,product);
	}


    @RequestMapping(value="/getMaterialByEngine/{product}/{model}/{engine}/{newRepair}/{docName}/{sowStatus}", method= RequestMethod.GET,produces = "application/json")
    public ResponseTemplateDto<SowMasterMaterialDtoForUI> getMaterialByEngine(@PathVariable("product") String product,@PathVariable("model") String model,@PathVariable("engine") String engine, @PathVariable("newRepair") String newRepair,@PathVariable("docName")String docName,@PathVariable("sowStatus") String sowStatus) {
	
		return sowMasterManager.getMaterialByEngine(product,model,engine,newRepair,docName,sowStatus);
	}


    @RequestMapping(value="/getMaterialByModule/{product}/{model}/{engine}/{module}/{newRepair}/{docName}/{sowStatus}", method= RequestMethod.GET,produces = "application/json")
    public ResponseTemplateDto<SowMasterMaterialDtoForUI> getMaterialByModule(@PathVariable("product")String product,@PathVariable("model") String model,@PathVariable("engine") String engine,@PathVariable("module") String module,
			@PathVariable("newRepair") String newRepair,@PathVariable("docName")String docName,@PathVariable("sowStatus") String sowStatus) {
		
		return sowMasterManager.getMaterialByModule(product, model, engine, module, newRepair,docName,sowStatus);
	}


    @RequestMapping(value="/getMaterialByModuleList/{product}/{model}/{engine}/{moduleList}/{newRepair}", method= RequestMethod.GET,produces = "application/json")
	public ResponseTemplateDto<Map<String,List<SowMasterMaterialDtoForUI>>> getMaterialByModuleList(@PathVariable("product")String product,@PathVariable("model") String model,@PathVariable("engine") String engine,@PathVariable("moduleList")  List<String> moduleList,@PathVariable("newRepair") String newRepair) {
		return sowMasterManager.getMaterialByModuleList(product, model, engine, moduleList, newRepair);
	}

    @RequestMapping(value="/getOpptyTypeList", method= RequestMethod.GET,produces = "application/json")
	public ResponseTemplateDto<List<OpptyTypeLovDto>> getOpptyTypeList() {
    	return sowMasterManager.getOpptyTypeList();
	}

    @RequestMapping(value="/getProposalTypeList", method= RequestMethod.GET,produces = "application/json")
	public ResponseTemplateDto<List<ProposalTypeLovDto>> getProposalTypeList() {
    	return sowMasterManager.getProposalTypeList();
	}
    

	@RequestMapping(value="/saveEngineOperationList", method= RequestMethod.POST, produces = "application/json", consumes = "application/json" )
	public ResponseTemplateDto<EngineOperationListDto> saveEngineOperationList(@RequestBody List<EngineOperationListDto> engineOperationListDto) {
		return sowMasterManager.saveEngineOperationList(engineOperationListDto);
	}


	@RequestMapping(value="/saveModuleOperationList", method= RequestMethod.POST, produces = "application/json", consumes = "application/json" )
	public ResponseTemplateDto<ModuleOperationListDto> saveModuleOperationList(@RequestBody List<ModuleOperationListDto> moduleOperationListDto) {
		return sowMasterManager.saveModuleOperationList(moduleOperationListDto);
	}
    
	@RequestMapping(value="/suggestedNextValueForModuleOperationList/{product}/{engine}/{module}", method= RequestMethod.GET, produces = "application/json")
	public ResponseTemplateDto<Long> suggestedNextValueForModuleOperationList(@PathVariable("product")String product,@PathVariable("engine")String engine,@PathVariable("module")String module) {
		return sowMasterManager.suggestedNextValueForModuleOperationList(engine,module,product);
	}

	
	@RequestMapping(value="/suggestedNextValueForEngineOperationList/{product}/{engine}", method= RequestMethod.GET, produces = "application/json")
	public ResponseTemplateDto<Long> suggestedNextValueForEngineOperationList(@PathVariable("product")String product,@PathVariable("engine")String engine) {
		return sowMasterManager.suggestedNextValueForEngineOperationList(engine,product);
	}
	
	@RequestMapping(value="/getOperationTypeLov", method= RequestMethod.GET, produces = "application/json" )
	public ResponseTemplateDto<OperationTypeLovDto> getOperationTypeLov() {
		return sowMasterManager.getOperationTypeLov();
	}


	@Override
	@RequestMapping(value="/getListPriceMaterialPriceDetails", method= RequestMethod.POST, produces = "application/json", consumes = "application/json" )
	public ResponseTemplateDto<ListPriceDto> getListPriceMaterialPriceDetails(@RequestBody CommonPostDto commonPostDto) {
		return sowMasterManager.getListPriceMaterialPriceDetails(commonPostDto.getPartNumber(),commonPostDto.getNewRepair());
	}

	@RequestMapping(value = "/getPartMaterialList", method= RequestMethod.POST,produces = "application/json", consumes = "application/json")
	public ResponseTemplateDto<List<ListPriceDto>> getPartMaterialList(@RequestBody CommonPostDto commonPostDto) {
		return sowMasterManager.getPartMaterialList(commonPostDto.getPriceListType(),commonPostDto.getSupplierType(),commonPostDto.getSupplier(),commonPostDto.getPartNumber());
	}
	
	//the entity here is changed, check this api
	@RequestMapping(value="/getStdSbLov", method= RequestMethod.GET, produces = "application/json" )
	public ResponseTemplateDto<List<StdSbLovDto>> getStdSbLov() {
		return sowMasterManager.getStdSbLov();
	}


	@RequestMapping(value="/getProductList", method= RequestMethod.GET, produces = "application/json" )
	public ResponseTemplateDto<List<ProductLovDto>> getProductList() {
		return sowMasterManager.getProductList();
	}

}









