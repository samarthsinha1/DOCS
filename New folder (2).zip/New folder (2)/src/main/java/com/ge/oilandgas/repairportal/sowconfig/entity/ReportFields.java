package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name= "ong_sowcfg_trx_report_fields")
public class ReportFields extends GenericEntity<Long>{
	
	
		private static final long serialVersionUID = 1L;

		@Id
		@SequenceGenerator(name="SEQ_REPORT_FIELDS", sequenceName="ong_sowcfg_trx_report_fields_sequence_id")
		@GeneratedValue(generator="SEQ_REPORT_FIELDS", strategy=GenerationType.SEQUENCE)
		@Column(name="id")
		private Long id;
		
		@Column(name="info_sequence_id")
		private Long engineInfoId;
		

		@Column(name="payment_terms")
		private String paymentTerms;
		
		@Column(name="incoterms")
		private String incoterms;
		
		@Column(name="terms_and_conditions")
		private String termsAndconditions;
	

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

	

		public Long getEngineInfoId() {
			return engineInfoId;
		}

		public void setEngineInfoId(Long engineInfoId) {
			this.engineInfoId = engineInfoId;
		}

		public String getPaymentTerms() {
			return paymentTerms;
		}

		public void setPaymentTerms(String paymentTerms) {
			this.paymentTerms = paymentTerms;
		}

		public String getIncoterms() {
			return incoterms;
		}

		public void setIncoterms(String incoterms) {
			this.incoterms = incoterms;
		}

		public String getTermsAndconditions() {
			return termsAndconditions;
		}

		public void setTermsAndconditions(String termsAndconditions) {
			this.termsAndconditions = termsAndconditions;
		}
	
	
}
