package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.oilandgas.repairportal.sowconfig.data.EngineModuleDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.EngineModuleRepository;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineModule;


@Component
public class EngineModuleDAOImpl implements EngineModuleDAO {
	
	@Autowired
	private EngineModuleRepository engineModuleRepository;
	
	  public EngineModuleDAOImpl(EngineModuleRepository engineModuleRepository) {
	        this.engineModuleRepository = engineModuleRepository;
	    }
	  public EngineModuleDAOImpl() {
	       super();
	    }
	
	    public EngineModuleRepository getRepository() {
	        return engineModuleRepository;
	    }


/*	@Override
	public EngineModule update(EngineModule entity) {
		// TODO Auto-generated method stub
		return null;
	}
*/

	@Override
	public List<EngineModule> findEngineModule(String product) {
		// TODO Auto-generated method stub
		return engineModuleRepository.findEngineModule(product);
	}



	/*@Override
	public <S extends GenericCrudRepository<EngineModule, Long>> S getRepository() {
		// TODO Auto-generated method stub
		return null;
	}*/


}
