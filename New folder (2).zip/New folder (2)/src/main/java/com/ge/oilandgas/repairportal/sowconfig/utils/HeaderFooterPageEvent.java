package com.ge.oilandgas.repairportal.sowconfig.utils;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfWriter;

@Component
public class HeaderFooterPageEvent extends PdfPageEventHelper {

	private static final Logger LOGGER = LoggerFactory.getLogger(HeaderFooterPageEvent.class);
	
    public void onStartPage(PdfWriter writer, Document document) {
   	try {
			 ClassLoader cl = this.getClass().getClassLoader();
			 URL url = cl.getResource("images/BHGElogo.jpg");
			 Image image= Image.getInstance(url);
			 image.scaleAbsolute(230, 90);
			 document.add(image);
	         if(document.getPageNumber() >1) {
	        	document.add( new Phrase("\n") );
	        }
		} catch (BadElementException e) {
			LOGGER.error("Exception while setting the PDF header ",e);
		} catch (DocumentException e) {
			LOGGER.error("Exception while setting the PDF header ",e);
		} catch (MalformedURLException e) {
			LOGGER.error("Exception while setting the PDF header ",e);
		} catch (IOException e) {
			LOGGER.error("Exception while setting the PDF header ",e);
		}
		
    }

    public void onEndPage(PdfWriter writer, Document document) {
    	//Font textFont = FontFactory.getFont(FontFactory.TIMES_ROMAN, 9);
    	Font textFont = FontFactory.getFont(FontFactory.TIMES_ROMAN, 10);
      //  ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_CENTER, new Phrase("© 2017 Baker Hughes, a GE company, LLC – All rights reserved. Confidential, for BHGE Internal Use only",textFont), 230, 15, 0);
       ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_CENTER, new Phrase("Page " + document.getPageNumber(),textFont), 550, 15, 0);
    }

}