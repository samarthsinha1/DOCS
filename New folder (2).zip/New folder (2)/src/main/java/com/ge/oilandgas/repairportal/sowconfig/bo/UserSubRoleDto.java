package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

public class UserSubRoleDto implements Serializable{
	
	   /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
    private String userRole;
    private String userSubRole;
    private String userSubRoleDescription;
    private long userSso;
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getUserSubRole() {
		return userSubRole;
	}
	public void setUserSubRole(String userSubRole) {
		this.userSubRole = userSubRole;
	}
	public String getUserSubRoleDescription() {
		return userSubRoleDescription;
	}
	public void setUserSubRoleDescription(String userSubRoleDescription) {
		this.userSubRoleDescription = userSubRoleDescription;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public long getUserSso() {
		return userSso;
	}
	public void setUserSso(long userSso) {
		this.userSso = userSso;
	}
	   
	   

}
