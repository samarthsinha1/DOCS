package com.ge.oilandgas.repairportal.sowconfig.data.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.ge.oilandgas.repairportal.sowconfig.entity.ShopDetail;

@Repository
public interface ShopDetailRepository extends JpaRepository<ShopDetail, Long>{

	@Query("SELECT s from ShopDetail s where s.engineModel= ?1 and s.product=?2")
	List<ShopDetail> findByEngineModel(String engineModel,String product);
	
}
