package com.ge.oilandgas.repairportal.sowconfig.data;

import java.util.List;
import java.util.Set;

import com.ge.oilandgas.repairportal.sowconfig.bo.EngineInfoForAllSowDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineInfoSowSetDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineInfo;

public interface EngineInfoDAO extends GenericDAO<EngineInfo, Long>{

	  /**
     * Retrieves EngineInfo by model
     * @param model
     * @return
     */
	 EngineInfo findByModel(String model,String product,String scopeType,String versionName);
	 EngineInfo createEngine(EngineInfo engineInfo);
	 EngineInfo findByComponentSequenceId(Long componentSequenceId,String model, String product);
	 EngineInfo getEngineInfoDetails(Long componentSequenceId,String model, String product, float version);
	 Object[] getVersionStatusList(Long componentSequenceId, String model, String product);
	 Float getLatestSowVersion(Long componentSequenceId, String product, String model);
	 Long getLatestComponentId();
	 List<EngineInfoForAllSowDto> getAllEngineInfo();
	 Set<String> getDocNameList(String docType, String model, String product);
	 Set<String> getDocNames(String docType, String product);
	 void deleteEngineInfo(Long id);
	// Object[] getStdSowVersions(String docType, String docName, String product, String model);
	 EngineInfo getEngineInfoDetails(String docType, String docName, String product, String model, float version);
	 Set<String> getCompletedDocNameList(String docType, String model, String product);
	 float getLatestCompletedSowVersion(String docType, String docName, String product, String model);
	 Float getLatestSowVersion(String docType, String docName, String product, String model);
	 Object[] getNextStatusAndRevisionsList(String product, String model, String docName);
	List<EngineInfoSowSetDto> getAllSowSet();
	
}
