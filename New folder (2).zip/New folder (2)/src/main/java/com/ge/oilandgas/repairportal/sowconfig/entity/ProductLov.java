package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "ong_sowcfg_std_product_lov")
public class ProductLov {
	
	@Id

	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private Long id;
	
	@Column(name="plc_product_type")
	private String plcProductType;
	
	@Column(name="product")
	private String product;
	
	@Column(name="prefix_counter")
	private String prefixCounter;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPlcProductType() {
		return plcProductType;
	}

	public void setPlcProductType(String plcProductType) {
		this.plcProductType = plcProductType;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getPrefixCounter() {
		return prefixCounter;
	}

	public void setPrefixCounter(String prefixCounter) {
		this.prefixCounter = prefixCounter;
	}


}
