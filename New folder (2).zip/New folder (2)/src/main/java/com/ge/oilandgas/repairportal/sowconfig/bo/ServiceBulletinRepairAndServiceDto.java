package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

public class ServiceBulletinRepairAndServiceDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long repairServiceId;
	private Long bulletinSeqId;
	private String componentDescription;
	private String componentCode;
	private Long quantityRepairs;
	private String repairDescription;
	private String componentGroup;
	private String machineModel;
	private String module;

	public Long getRepairServiceId() {
		return repairServiceId;
	}
	public void setRepairServiceId(Long repairServiceId) {
		this.repairServiceId = repairServiceId;
	}
	public Long getBulletinSeqId() {
		return bulletinSeqId;
	}
	public void setBulletinSeqId(Long bulletinSeqId) {
		this.bulletinSeqId = bulletinSeqId;
	}

	public String getComponentDescription() {
		return componentDescription;
	}
	public void setComponentDescription(String componentDescription) {
		this.componentDescription = componentDescription;
	}
	public String getComponentCode() {
		return componentCode;
	}
	public void setComponentCode(String componentCode) {
		this.componentCode = componentCode;
	}

	public Long getQuantityRepairs() {
		return quantityRepairs;
	}
	public void setQuantityRepairs(Long quantityRepairs) {
		this.quantityRepairs = quantityRepairs;
	}

	public String getRepairDescription() {
		return repairDescription;
	}
	public void setRepairDescription(String repairDescription) {
		this.repairDescription = repairDescription;
	}
	public String getComponentGroup() {
		return componentGroup;
	}
	public void setComponentGroup(String componentGroup) {
		this.componentGroup = componentGroup;
	}
	public String getMachineModel() {
		return machineModel;
	}
	public void setMachineModel(String machineModel) {
		this.machineModel = machineModel;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	@Override
	public String toString() {
		return "ServiceBulletinRepairAndServiceDto [repairServiceId=" + repairServiceId + ", bulletinSeqId="
				+ bulletinSeqId + ", componentDescription=" + componentDescription + ", componentCode=" + componentCode
				+ ", quantityRepairs=" + quantityRepairs + ", repairDescription=" + repairDescription
				+ ", componentGroup=" + componentGroup + ", machineModel=" + machineModel + ", module=" + module + "]";
	}

	
}
