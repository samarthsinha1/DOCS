package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.oilandgas.repairportal.sowconfig.data.ServiceRenderedDAO;

import com.ge.oilandgas.repairportal.sowconfig.data.repository.GenericCrudRepository;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.ServiceRenderedRepository;
import com.ge.oilandgas.repairportal.sowconfig.entity.ServiceRendered;



@Component
public class ServiceRenderedDAOImpl implements ServiceRenderedDAO{

	

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ServiceRenderedDAOImpl.class);
	@Autowired
	private ServiceRenderedRepository service_renderedRepository;
	
	  public ServiceRenderedDAOImpl(ServiceRenderedRepository service_renderedRepository) {
	        this.service_renderedRepository = service_renderedRepository;
	    }
	  public ServiceRenderedDAOImpl() {
	       super();
	    }

	  @SuppressWarnings("unchecked")

	    public ServiceRenderedRepository getRepository() {
	        return service_renderedRepository;
	    }




	@Override
	public List<ServiceRendered> findByService() {
		//LOGGER.debug("Class::Shop_detailsDAOImpl, Method::findByEngineModel::model"+engine_model);
		//LOGGER.debug("Class::Shop_detailsDAOImpl, Method::findByEngineModel::shop_detailsRepository.findByEngineModel(engine_model)"+shop_detailsRepository.findByEngineModel(engine_model));
		return service_renderedRepository.findByService();
	}


	
}
