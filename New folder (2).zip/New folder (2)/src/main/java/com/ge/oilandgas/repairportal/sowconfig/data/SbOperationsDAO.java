package com.ge.oilandgas.repairportal.sowconfig.data;

public interface SbOperationsDAO {
	
}
