package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EngineOperationsDto extends AuditDataDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private long engineModelSequenceId;
	private String operations;
	private float laborHours;
	private float laborCost;
	private float laborPrice;
	private float laborQuotePrice;
	private String operationType;
	private Long numOperation;
	private float baseLaborHours;
	 
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public long getEngineModelSequenceId() {
		return engineModelSequenceId;
	}
	public void setEngineModelSequenceId(long engineModelSequenceId) {
		this.engineModelSequenceId = engineModelSequenceId;
	}
	public String getOperations() {
		return operations;
	}
	public void setOperations(String operations) {
		this.operations = operations;
	}
	public float getLaborHours() {
		return laborHours;
	}
	public void setLaborHours(float laborHours) {
		this.laborHours = laborHours;
	}
	public float getLaborCost() {
		return laborCost;
	}
	public void setLaborCost(float laborCost) {
		this.laborCost = laborCost;
	}
	public float getLaborPrice() {
		return laborPrice;
	}
	public void setLaborPrice(float laborPrice) {
		this.laborPrice = laborPrice;
	}
	public float getLaborQuotePrice() {
		return laborQuotePrice;
	}
	public void setLaborQuotePrice(float laborQuotePrice) {
		this.laborQuotePrice = laborQuotePrice;
	}
	@Override
	public String toString() {
		return "EngineOperationsDto [id=" + id + ", engineModelSequenceId=" + engineModelSequenceId + ", operations="
				+ operations + ", laborHours=" + laborHours + ", laborCost=" + laborCost + ", laborPrice=" + laborPrice
				+ ", laborQuotePrice=" + laborQuotePrice + "]";
	}
	public String getOperationType() {
		return operationType;
	}
	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}
	public Long getNumOperation() {
		return numOperation;
	}
	public void setNumOperation(Long numOperation) {
		this.numOperation = numOperation;
	}
	public float getBaseLaborHours() {
		return baseLaborHours;
	}
	public void setBaseLaborHours(float baseLaborHours) {
		this.baseLaborHours = baseLaborHours;
	}
	
	
	
}
