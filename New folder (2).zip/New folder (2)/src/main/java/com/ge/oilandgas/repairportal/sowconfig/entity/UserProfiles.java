package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "ong_orp_user_profiles")
public class UserProfiles extends GenericEntity<Long>{

	/**
	 * 
	 */
	private static final long serialVersionUID = -735713149662363280L;

	@Id

	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="user_seq_id")
	private Long id;
	
	@Column(name="user_sso")
	private Integer userSso;
	@Column(name="user_first_name")
	private String userFirstName;
	@Column(name="user_last_name")
	private String userLastName;
	@Column(name="user_middle_name")
	private String userMiddleName;
	@Column(name="user_email")
	private String userEmail;
	@Column(name="user_phone")
	private String userPhone;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Integer getUserSso() {
		return userSso;
	}
	public void setUserSso(Integer userSso) {
		this.userSso = userSso;
	}
	public String getUserFirstName() {
		return userFirstName;
	}
	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}
	public String getUserLastName() {
		return userLastName;
	}
	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}
	public String getUserMiddleName() {
		return userMiddleName;
	}
	public void setUserMiddleName(String userMiddleName) {
		this.userMiddleName = userMiddleName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}
	
	
	
}
