package com.ge.oilandgas.repairportal.sowconfig.common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.dozer.DozerBeanMapper;
import org.springframework.stereotype.Component;

@Component
public class EntityBoMapper {

	static DozerBeanMapper mapper = new DozerBeanMapper();
	static{
		List<String> mappingFiles = Arrays.asList("dozer-bean-mappings.xml");
		mapper.setMappingFiles(mappingFiles);
	}
	
	
	public <T, U> List<U> map(final List<T> source, final Class<U> destType) {
		final List<U> dest = new ArrayList<U>();
		if (source == null) {
			return null;
		}
		for (T element : source) {
			if (element == null) {
				continue;
			}
			dest.add(map(element, destType));
		}
		// finally remove all null values if any
		List s1 = new ArrayList();
		s1.add(null);
		dest.removeAll(s1);
		return dest;
	}

	public <T, U> U map(final T source, final Class<U> destType) {
		if (source == null) {
			return null;
		}
		U desObj = null;
		desObj = mapper.map(source, destType);
		return desObj;
	}
	
}
