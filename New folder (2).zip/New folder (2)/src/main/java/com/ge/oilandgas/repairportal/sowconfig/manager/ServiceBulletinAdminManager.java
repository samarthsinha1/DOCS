package com.ge.oilandgas.repairportal.sowconfig.manager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ServiceBulletinMasterDto;
import com.ge.oilandgas.repairportal.sowconfig.common.EntityBoMapper;
import com.ge.oilandgas.repairportal.sowconfig.data.SbNewMaterialsDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.SbOperationsDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.SbRepairAndServiceDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.StdSbLovDAO;


@Service
public class ServiceBulletinAdminManager{

	private static final Logger LOGGER = LoggerFactory.getLogger(ServiceBulletinAdminManager.class);
	
	@Autowired
	private EntityBoMapper entityBoMapper;
	@Autowired
	StdSbLovDAO stdSbLovDAO;
	@Autowired
	SbNewMaterialsDAO sbNewMaterialsDao;
	@Autowired
	SbOperationsDAO sbOperationsDao;
	@Autowired
	SbRepairAndServiceDAO sbRepairAndServiceDao;



	public ResponseTemplateDto<ServiceBulletinMasterDto> saveNewServiceBulletin(ServiceBulletinMasterDto serviceBulletinsMasterDto) {
		/*LOGGER.info("Class::ServiceBulletinAdminManager, Method::saveNewServiceBulletin::ENTER");
		ResponseTemplateDto<ServiceBulletinMasterDto> response = new ResponseTemplateDto<>();
		List<ServiceBulletinNewMaterialsDto> serviceBulletinNewMaterialsList = new ArrayList<>();
		List<ServiceBulletinOperationsDto> serviceBulletinOperationsList = new ArrayList<>();
		List<ServiceBulletinRepairAndServiceDto> serviceBulletinRepairAndServiceList = new ArrayList<>();
		try{
			LOGGER.info("Class::ServiceBulletinAdminManager, Method::saveNewServiceBulletin::ENTER, in TRY method");
			ServiceBulletins serviceBulletins =  entityBoMapper.map(serviceBulletinsMasterDto.getStdSbLovDto(), ServiceBulletins.class);
			if(serviceBulletins.getId() == null){
				//saved service bulletin details
				serviceBulletinAdminDao.save(serviceBulletins);
				//insertingNewMaterials
				if(!serviceBulletinsMasterDto.getSbNewMaterialList().isEmpty()){
					for (ServiceBulletinNewMaterialsDto serviceBulletinNewMaterialsDto : serviceBulletinNewMaterialsList) {
						ServiceBulletinNewMaterials serviceBulletinNewMaterials=entityBoMapper.map(serviceBulletinNewMaterialsDto, ServiceBulletinNewMaterials.class);
					    //serviceBulletinNewMaterials is saved here 
						serviceBulletinAdminDao.saveSbNewMaterial(serviceBulletinNewMaterials);
						//serviceBulletinNewMaterialsRepository.save(serviceBulletinNewMaterials);
					}
				}
				//inserting SB Operation Details
				if(!serviceBulletinsMasterDto.getSbOperationsList().isEmpty()){
					for (ServiceBulletinOperationsDto serviceBulletinOperationsDto : serviceBulletinOperationsList) {
						ServiceBulletinOperations serviceBulletinOperations= entityBoMapper.map(serviceBulletinOperationsDto, ServiceBulletinOperations.class);
					    //serviceBulletinOperations is saved here
						serviceBulletinAdminDao.saveSbOperation(serviceBulletinOperations);
						//serviceBulletinOperationsRepository.save(serviceBulletinOperations);
					}
				}
				if(serviceBulletinsMasterDto.getSbRepairAndServiceList().isEmpty()){
					for (ServiceBulletinRepairAndServiceDto serviceBulletinRepairAndServiceDto : serviceBulletinRepairAndServiceList) {
						ServiceBulletinRepairAndService serviceBulletinRepairAndService = entityBoMapper.map(serviceBulletinRepairAndServiceDto, ServiceBulletinRepairAndService.class);
					    //serviceBulletinRepairAndService save code goes here
						serviceBulletinAdminDao.saveSbRepairAndService(serviceBulletinRepairAndService);
						//serviceBulletinRepairAndServiceRepository.save(serviceBulletinRepairAndService);
					}
				}
			}
			response.setSuccess(true);
		}catch(Exception e){
			LOGGER.error("Issue in creating service bulletin", e);
			response.setStatusMsg("Issue in creating service bulletin");
			response.setSuccess(false);
		}*/
		return null;
	}
	
	
	
}
