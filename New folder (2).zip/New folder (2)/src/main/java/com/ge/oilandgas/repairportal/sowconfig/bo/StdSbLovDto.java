package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

public class StdSbLovDto extends AuditDataDto implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2228299347608629773L;
	private Long id;
	private String sbId;
	private String title;
	private String sbDescription;
	private String category;
	private String isNewSbFlag;
	private String sbNumber;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getSbDescription() {
		return sbDescription;
	}
	public void setSbDescription(String sbDescription) {
		this.sbDescription = sbDescription;
	}
	public String getSbId() {
		return sbId;
	}
	public void setSbId(String sbId) {
		this.sbId = sbId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getIsNewSbFlag() {
		return isNewSbFlag;
	}
	public void setIsNewSbFlag(String isNewSbFlag) {
		this.isNewSbFlag = isNewSbFlag;
	}
	public String getSbNumber() {
		return sbNumber;
	}
	public void setSbNumber(String sbNumber) {
		this.sbNumber = sbNumber;
	}
	@Override
	public String toString() {
		return "StdSbLovDto [id=" + id + ", sbId=" + sbId + ", title=" + title + ", sbDescription=" + sbDescription
				+ ", category=" + category + ", isNewSbFlag=" + isNewSbFlag + ", sbNumber=" + sbNumber + "]";
	}
	
	
	
}
