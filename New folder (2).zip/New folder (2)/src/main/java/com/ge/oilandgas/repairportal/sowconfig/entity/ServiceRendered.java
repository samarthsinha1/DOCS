package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "ong_sowcfg_std_service_rendered_lov")

public class ServiceRendered{
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private Long id;
	
	@Column(name="service_rendered")
	private String serviceRendered;
	
	@Column(name="unit_price")
	private Long unitPrice;


	

	public String getServiceRendered() {
		return serviceRendered;
	}


	public void setServiceRendered(String serviceRendered) {
		this.serviceRendered = serviceRendered;
	}


	public Long getUnitPrice() {
		return unitPrice;
	}


	public void setUnitPrice(Long unitPrice) {
		this.unitPrice = unitPrice;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	public Long getId() {
		// TODO Auto-generated method stub
		return null;
	}

	
	public void setId(Long id) {
		// TODO Auto-generated method stub
		
	}

}
