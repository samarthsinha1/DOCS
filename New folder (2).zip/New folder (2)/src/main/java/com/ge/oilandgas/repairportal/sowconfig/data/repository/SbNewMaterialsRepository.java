package com.ge.oilandgas.repairportal.sowconfig.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ge.oilandgas.repairportal.sowconfig.entity.ServiceBulletinNewMaterials;

@Repository
public interface SbNewMaterialsRepository extends JpaRepository<ServiceBulletinNewMaterials, Long>{

}
