package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name= "ong_sowcfg_trx_saved_preference")
public class SavedPreference extends GenericEntity<Long>{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	
	@Id
	@SequenceGenerator(name="SEQ_SAVED_PREFERENCE", sequenceName="ong_sowcfg_trx_saved_preference_sequence_id")
	@GeneratedValue(generator="SEQ_SAVED_PREFERENCE", strategy=GenerationType.SEQUENCE)
	@Column(name="id")
	private Long id;
	
	@Column(name="sso_id")
	private Long ssoId;

	@Column(name="saved_data")
	private String savedData;
	
	
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getSsoId() {
		return ssoId;
	}

	public void setSsoId(Long ssoId) {
		this.ssoId = ssoId;
	}

	public String getSavedData() {
		return savedData;
	}

	public void setSavedData(String savedData) {
		this.savedData = savedData;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
