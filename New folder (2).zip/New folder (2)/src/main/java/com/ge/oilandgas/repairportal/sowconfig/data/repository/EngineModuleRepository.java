package com.ge.oilandgas.repairportal.sowconfig.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ge.oilandgas.repairportal.sowconfig.entity.EngineModule;


@Repository
public interface EngineModuleRepository extends JpaRepository<EngineModule, Long>{

	@Query("SELECT s from EngineModule s where s.product = ?1 order by s.id ")
	List<EngineModule> findEngineModule(String product);
	
}

