package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.ge.oilandgas.repairportal.sowconfig.data.StdSbLovDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.StdSbLovRepository;
import com.ge.oilandgas.repairportal.sowconfig.entity.StdSbLov;

@Component
public class StdSbLovDAOImpl extends GenericCrudDAOImpl<StdSbLov, Long> implements StdSbLovDAO {
	
	private static final Logger logger = LoggerFactory
			.getLogger(StdSbLovDAOImpl.class);
	@Autowired
	private StdSbLovRepository stdSbLovRepository;
	
	  public StdSbLovDAOImpl(StdSbLovRepository stdSbLovRepository) {
	        this.stdSbLovRepository = stdSbLovRepository;
	    }
	  public StdSbLovDAOImpl() {
	       super();
	    }

	  @SuppressWarnings("unchecked")	
	    public StdSbLovRepository getRepository() {
	        return stdSbLovRepository;
	    }
	@Override
	public List<StdSbLov> getStdSbLov() {
		logger.debug("Class::StdSbLovDAOImpl, Method::getStdSbLov");
		return stdSbLovRepository.getStdSbLov();
	}

}
