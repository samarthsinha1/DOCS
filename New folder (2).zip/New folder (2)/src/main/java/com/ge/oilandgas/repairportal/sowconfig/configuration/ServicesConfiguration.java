package com.ge.oilandgas.repairportal.sowconfig.configuration;

import javax.persistence.EntityManagerFactory;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages={"com.ge.oilandgas"},entityManagerFactoryRef="entityManagerFactory")
public class ServicesConfiguration {
	
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyLocalConfigIn() {
		return new PropertySourcesPlaceholderConfigurer();
    }
	
	@Bean
	public PlatformTransactionManager transactionManager(EntityManagerFactory entityManagerFactory) throws Exception {
	   return new JpaTransactionManager(entityManagerFactory);
	}
}
