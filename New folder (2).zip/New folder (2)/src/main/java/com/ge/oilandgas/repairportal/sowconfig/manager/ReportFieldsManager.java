package com.ge.oilandgas.repairportal.sowconfig.manager;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.oilandgas.repairportal.sowconfig.bo.ReportFieldsDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;
import com.ge.oilandgas.repairportal.sowconfig.common.EntityBoMapper;
import com.ge.oilandgas.repairportal.sowconfig.data.ReportFieldsDAO;
import com.ge.oilandgas.repairportal.sowconfig.entity.ReportFields;

@Service
public class ReportFieldsManager {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CommercialViewManager.class);
	private EntityBoMapper entityBoMapper;
	private ReportFieldsDAO reportFieldsDAO;
		
	@Autowired
	public ReportFieldsManager(EntityBoMapper entityBoMapper, ReportFieldsDAO reportFieldsDAO) {
		this.entityBoMapper = entityBoMapper;
		this.reportFieldsDAO = reportFieldsDAO;	
	}

	/**
	 * @param engineInfoId
	 * @return
	 */
	public ResponseTemplateDto<ReportFieldsDto> getReportFieldsByEngineInfoId(Long engineInfoId) {
		LOGGER.debug("Class::ReportFieldsManager, Method::getReportFieldsByEngineInfoId::ENTER");
		ResponseTemplateDto<ReportFieldsDto> response = new ResponseTemplateDto<>();
		try{
			LOGGER.debug("Class::ReportFieldsManager, Method::getReportFieldsByEngineInfoId::id"+engineInfoId);
			List<ReportFields> reportFieldsList= reportFieldsDAO.findReportFieldsByEngineInfoId(engineInfoId);
			List<ReportFieldsDto> reportFieldsDtoList = entityBoMapper.map(reportFieldsList,ReportFieldsDto.class);				
			response.setDataList(reportFieldsDtoList);
			response.setOverallCount(new Long(reportFieldsDtoList.size()));
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Issue in retrieving Report fields by id", e);
			response.setStatusMsg("Issue in retrieving Report fields by id");
			response.setSuccess(false);
		}
		LOGGER.debug("Class::ReportFieldsManager, Method::getReportFieldsByEngineInfoId::EXIT");
		return response;
		
	}
	
	
	/**
	 * @param reportFieldsDto
	 * @return
	 */
	public ResponseTemplateDto<ReportFieldsDto> saveUpdateReportFields(ReportFieldsDto reportFieldsDto) {
		LOGGER.debug("Class::ReportFieldsManager, Method::saveUpdateReportFields::ENTER");
		ResponseTemplateDto<ReportFieldsDto> response = new ResponseTemplateDto<>();
		try{
			ReportFields reportFields =  entityBoMapper.map(reportFieldsDto, ReportFields.class);
			if(reportFields.getId() == null) {
				reportFields=reportFieldsDAO.save(reportFields);
			}else{
				reportFields.setLastUpdateDate(new Date());
				reportFields=reportFieldsDAO.update(reportFields);
			}
			reportFieldsDto=entityBoMapper.map(reportFields, ReportFieldsDto.class);
			response.setData(reportFieldsDto);
			response.setSuccess(true);
			response.setStatusMsg("Success");
		}catch (Exception e) {
			LOGGER.error("Issue in saving the report fields" , e);
			response.setSuccess(false);
			response.setStatusMsg("Issue in saving the report fields");
		}
		LOGGER.debug("Class::ReportFieldsManager, Method::saveUpdateReportFields::EXIT");
		return response;
	}

	
	/**
	 * @param engineInfoId
	 * @return
	 */
	public ResponseTemplateDto<ReportFieldsDto> deleteReportFields(Long engineInfoId) {
		LOGGER.debug("Class::ReportFieldsManager, Method::deleteReportFields::ENTER");
		ResponseTemplateDto<ReportFieldsDto> response = new ResponseTemplateDto<>();
		try{
			ReportFields reportFields=reportFieldsDAO.delete(engineInfoId);
			ReportFieldsDto reportFieldsDto=entityBoMapper.map(reportFields, ReportFieldsDto.class);
			reportFields.setLastUpdateDate(new Date());
			response.setData(reportFieldsDto);
			response.setSuccess(true);
			response.setStatusMsg("Success");
		}catch (Exception e) {
			LOGGER.error("Issue in deleting the report fields" , e);
			response.setSuccess(false);
			response.setStatusMsg("Issue in deleting the report fields");
		}
		LOGGER.debug("Class::ReportFieldsManager, Method::deleteReportFields::EXIT");
		return response;
	}

}
