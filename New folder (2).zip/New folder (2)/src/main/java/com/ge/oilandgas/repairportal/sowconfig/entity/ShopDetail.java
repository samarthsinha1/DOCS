package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "ong_sowcfg_std_shop_details_lov")

public class ShopDetail {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private Long id;
	
	@Column(name="engine_model")
	private String engineModel;
	
	@Column(name="plc_product_type")
	private String product;
	
	@Column(name="shop_name")
	private String shopName;
	
	@Column(name="shop_labor_hour_unit_price")
	private Float shopLaborHourUnitPrice;
	
	@Column(name="Labor_Hour_Unit_Cost")
	private Float laborHourUnitCost;
	
	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}
	
	public Long getId() {
		return id;
	}
	 

	public void setId(Long id) {
		this.id = id;
	}

	public String getEngineModel() {
		return engineModel;
	}

	public void setEngineModel(String engineModel) {
		this.engineModel = engineModel;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public Float getShopLaborHourUnitPrice() {
		return shopLaborHourUnitPrice;
	}

	public void setShopLaborHourUnitPrice(Float shopLaborHourUnitPrice) {
		this.shopLaborHourUnitPrice = shopLaborHourUnitPrice;
	}

	public Float getLaborHourUnitCost() {
		return laborHourUnitCost;
	}

	public void setLaborHourUnitCost(Float laborHourUnitCost) {
		this.laborHourUnitCost = laborHourUnitCost;
	}
    
}
