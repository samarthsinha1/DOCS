package com.ge.oilandgas.repairportal.sowconfig.manager;

import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ge.oilandgas.repairportal.sowconfig.bo.CommercialViewDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;
import com.ge.oilandgas.repairportal.sowconfig.common.EntityBoMapper;
import com.ge.oilandgas.repairportal.sowconfig.data.CommercialViewDAO;
import com.ge.oilandgas.repairportal.sowconfig.entity.CommercialView;

@Service
public class CommercialViewManager {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CommercialViewManager.class);
	private EntityBoMapper entityBoMapper;
	private CommercialViewDAO commercialViewDAO;
		
	@Autowired
	public CommercialViewManager(EntityBoMapper entityBoMapper, CommercialViewDAO commercialViewDAO) {
		this.entityBoMapper = entityBoMapper;
		this.commercialViewDAO = commercialViewDAO;	
	}
	
	/**
	 * @param engineInfoId
	 * @return
	 */
	public ResponseTemplateDto<CommercialViewDto> getCommercialViewByEngineInfoId(Long engineInfoId) {
		LOGGER.debug("Class::CommercialViewManager, Method::getCommercialViewByEngineInfoId::ENTER");
		ResponseTemplateDto<CommercialViewDto> response = new ResponseTemplateDto<>();
		try{
			LOGGER.debug("Class::CommercialViewManager, Method::getCommercialViewByEngineInfoId::id"+engineInfoId);
			List<CommercialView> commercialViewList= commercialViewDAO.findCommercialViewByEngineInfoId(engineInfoId);
			List<CommercialViewDto> commercialViewDtoList = entityBoMapper.map(commercialViewList,CommercialViewDto.class);				
			response.setDataList(commercialViewDtoList);
			response.setOverallCount(new Long(commercialViewDtoList.size()));
			response.setSuccess(true);
		} catch (Exception e) {
			LOGGER.error("Issue in retrieving CommercialView by id", e);
			response.setStatusMsg("Issue in retrieving CommercialView by id");
			response.setSuccess(false);
		}
		LOGGER.debug("Class::CommercialViewManager, Method::getCommercialViewByEngineInfoId::EXIT");
		return response;
		
	}
	
	/**
	 * @param commercialViewDto
	 * @return
	 */
	public ResponseTemplateDto<CommercialViewDto> saveUpdateCommercialView(CommercialViewDto commercialViewDto) {
		LOGGER.debug("Class::CommercialViewManager, Method::saveUpdateCommercialView::ENTER");
		ResponseTemplateDto<CommercialViewDto> response = new ResponseTemplateDto<>();
		try{
			CommercialView commercialView =  entityBoMapper.map(commercialViewDto, CommercialView.class);
			if(commercialView.getId() == null) {
				commercialView=commercialViewDAO.save(commercialView);
			}else{
				commercialView.setLastUpdateDate(new Date());
				commercialView=commercialViewDAO.update(commercialView);
			}
			commercialViewDto=entityBoMapper.map(commercialView, CommercialViewDto.class);
			response.setData(commercialViewDto);
			response.setSuccess(true);
			response.setStatusMsg("Success");
		}catch (Exception e) {
			LOGGER.error("Issue in saving the commercial view" , e);
			response.setSuccess(false);
			response.setStatusMsg("Issue in saving the commercial view");
		}
		LOGGER.debug("Class::CommercialViewManager, Method::saveUpdateCommercialView::EXIT");
		return response;
	}

}
