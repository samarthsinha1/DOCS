package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "ong_sowcfg_std_oppty_type_lov")
public class OpptyTypeLov {
	
	@Id

	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="oppty_type_id")
	private Long id;
	
	@Column(name="oppty_type_name")
	private String opptyTypeName;
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOpptyTypeName() {
		return opptyTypeName;
	}

	public void setOpptyTypeName(String opptyTypeName) {
		this.opptyTypeName = opptyTypeName;
	}


}
