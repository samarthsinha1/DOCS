package com.ge.oilandgas.repairportal.sowconfig.entity;

import java.util.LinkedList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name= "ong_sowcfg_trx_modules")
public class Modules extends GenericEntity<Long>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SEQ_MODULE", sequenceName="ong_sowcfg_trx_modules_sequence_id")
	@GeneratedValue(generator="SEQ_MODULE", strategy=GenerationType.SEQUENCE)
	@Column(name="MODULE_SEQUENCE_ID")
	private Long id;
	
	@Column(name="ENGINE")
	private String engine;
	
	@Column(name="MODULE")
	private String module;
	
	@Column(name="CHECKED")
	private String moduleChecked;
	
	@Column(name="additional_comment")
	private String additionalComment;
	
	
	@OneToMany(cascade = CascadeType.ALL,
			fetch = FetchType.EAGER, orphanRemoval=true)
	@JoinColumn(name="MODULE_SEQUENCE_ID",referencedColumnName="MODULE_SEQUENCE_ID", nullable=false)
	@OrderBy
	private List<ModuleOperations> moduleOperationsList = new LinkedList<>();
	
	@OneToMany(cascade = CascadeType.ALL,
			fetch = FetchType.EAGER, orphanRemoval=true)
	@JoinColumn(name="MODULE_SEQUENCE_ID",referencedColumnName="MODULE_SEQUENCE_ID", nullable=false)
	@OrderBy
	List<ModuleMaterials> moduleMaterialsList= new LinkedList<>();
	
	@OneToMany(cascade = CascadeType.ALL,
			fetch = FetchType.EAGER, orphanRemoval=true)
	@JoinColumn(name="MODULE_SEQUENCE_ID",referencedColumnName="MODULE_SEQUENCE_ID", nullable=false)
	@OrderBy
	List<ModuleMaterialRepair> moduleMaterialsRepairList= new LinkedList<>();
	
	
	
	public List<ModuleMaterialRepair> getModuleMaterialsRepairList() {
		return moduleMaterialsRepairList;
	}

	public void setModuleMaterialsRepairList(List<ModuleMaterialRepair> moduleMaterialsRepairList) {
		this.moduleMaterialsRepairList = moduleMaterialsRepairList;
	}

	public List<ModuleMaterials> getModuleMaterialsList() {
		return moduleMaterialsList;
	}

	public void setModuleMaterialsList(List<ModuleMaterials> moduleMaterialsList) {
		this.moduleMaterialsList = moduleMaterialsList;
	}

	public String getEngine() {
		return engine;
	}

	public void setEngine(String engine) {
		this.engine = engine;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	@Override
	public Long getId() {
		return id;
	}

	@Override
	public void setId(Long id) {
		this.id=id;
	}
	

	public String getModuleChecked() {
		return moduleChecked;
	}

	public void setModuleChecked(String moduleChecked) {
		this.moduleChecked = moduleChecked;
	}

	public List<ModuleOperations> getModuleOperationsList() {
		return moduleOperationsList;
	}

	public void setModuleOperationsList(List<ModuleOperations> moduleOperationsList) {
		this.moduleOperationsList = moduleOperationsList;
	}

	public String getAdditionalComment() {
		return additionalComment;
	}

	public void setAdditionalComment(String additionalComment) {
		this.additionalComment = additionalComment;
	}
	
}
