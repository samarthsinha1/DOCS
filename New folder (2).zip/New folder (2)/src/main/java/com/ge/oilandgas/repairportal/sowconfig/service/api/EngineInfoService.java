package com.ge.oilandgas.repairportal.sowconfig.service.api;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.ge.oilandgas.repairportal.sowconfig.bo.EngineInfoDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineInfoForAllSowDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineInfoSowSetDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ListPriceDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.PartNumberListDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseStatusDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.UserProfilesDto;

public interface EngineInfoService {

	/**
	 * Gets the Engine Info based on request
	 */
	ResponseTemplateDto<EngineInfoDto> getEngineInfo(Long componentSequenceId,String model,String product);
	
	ResponseTemplateDto<EngineInfoDto> getEngineInfoDetails(Long componentSequenceId, String model,String product, float version);
	
	ResponseTemplateDto<EngineInfoDto> getEngineInfoDetailsFromMaster(String docType,String docName, String model,String product,String eventType);
	
	ResponseTemplateDto<List<String>> getDocNameListFromMaster(String docType, String model,String product);
	
	ResponseTemplateDto<EngineInfoDto> saveEngineInfo(@RequestBody EngineInfoDto engineInfoDto);
	
	ResponseTemplateDto<EngineInfoDto> submitEngineInfo(@RequestBody EngineInfoDto engineInfoDto);
	
	ResponseTemplateDto<List<EngineInfoForAllSowDto>> getAllEngineInfo();
	
	ResponseTemplateDto<EngineInfoDto> getEngineInfoById(Long id);
	
	ResponseStatusDto deleteEngineInfo(Long id,String docName);
	
	ResponseTemplateDto<EngineInfoDto> copyEngineInfo(Long id);
	ResponseTemplateDto<EngineInfoDto> updateEngineInfo(Long id);
	
	ResponseTemplateDto<List<EngineInfoSowSetDto>> getAllSowSet();
	
	ResponseTemplateDto<List<ListPriceDto>> getAllNewPriceList(PartNumberListDto partNumerList);
	ResponseTemplateDto<List<ListPriceDto>> getAllRepairPriceList(PartNumberListDto partNumerList);
	
	ResponseTemplateDto<UserProfilesDto> getUserInfo(Integer sso);
		
}
