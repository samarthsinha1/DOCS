package com.ge.oilandgas.repairportal.sowconfig.common;

import org.dozer.BeanFactory;

public class DozerCustomBeanFactory implements BeanFactory {

	@Override
	public Object createBean(Object source, Class<?> sourceClass, String targetBeanId) {
		// TODO Auto-generated method stub
		return null;
	}

}
