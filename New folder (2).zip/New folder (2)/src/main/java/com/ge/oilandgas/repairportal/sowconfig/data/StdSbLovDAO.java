package com.ge.oilandgas.repairportal.sowconfig.data;

import java.util.List;
import com.ge.oilandgas.repairportal.sowconfig.entity.StdSbLov;

public interface StdSbLovDAO extends GenericDAO<StdSbLov, Long>  {
	
	 List<StdSbLov> getStdSbLov();

}
