package com.ge.oilandgas.repairportal.sowconfig.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ge.oilandgas.repairportal.sowconfig.bo.ReportFieldsDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ServiceBulletinsDto;
import com.ge.oilandgas.repairportal.sowconfig.manager.ReportFieldsManager;
import com.ge.oilandgas.repairportal.sowconfig.manager.ServiceBulletinsManager;
import com.ge.oilandgas.repairportal.sowconfig.service.api.ServiceBulletinService;

@RequestMapping("/service/sowconfigurator")
@RestController
public class ServiceBulletinServiceImpl implements ServiceBulletinService{
	
	@Autowired
	ServiceBulletinsManager serviceBulletinsManager;


	@RequestMapping(value="/getServiceBulletinsById/{id}", method= RequestMethod.GET, produces = "application/json" )
	public ResponseTemplateDto<ServiceBulletinsDto> getServiceBulletinsById(@PathVariable("id") Long id) {
		return serviceBulletinsManager.getServiceBulletinsById(id);
	}
	

	@RequestMapping(value="/saveUpdateServiceBulletins", method= RequestMethod.POST, produces = "application/json", consumes = "application/json" )
	public ResponseTemplateDto<ServiceBulletinsDto> saveUpdateServiceBulletins(@RequestBody ServiceBulletinsDto serviceBulletinsDto) {
		return serviceBulletinsManager.saveUpdateServiceBulletins(serviceBulletinsDto);
	}

	@RequestMapping(value="/findServiceBulletinsByNumber/{sbNumber}", method= RequestMethod.GET, produces = "application/json" )
	public ResponseTemplateDto<ServiceBulletinsDto> findServiceBulletinsByNumber(@PathVariable("sbNumber") String sbNumber) {
		return serviceBulletinsManager.findServiceBulletinsByNumber(sbNumber);
	}
}
