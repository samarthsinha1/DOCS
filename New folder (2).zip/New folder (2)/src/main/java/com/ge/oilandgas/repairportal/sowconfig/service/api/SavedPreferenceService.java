package com.ge.oilandgas.repairportal.sowconfig.service.api;

import org.springframework.web.bind.annotation.RequestBody;

import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.SavedPreferenceDto;

public interface SavedPreferenceService {
	
	ResponseTemplateDto<SavedPreferenceDto> getDetailsBySsoId(Long ssoId);
	
	ResponseTemplateDto<SavedPreferenceDto> saveUpdateDetails(@RequestBody SavedPreferenceDto savedPreferenceDto);

}
