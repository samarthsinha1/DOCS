package com.ge.oilandgas.repairportal.sowconfig.data;

import java.util.List;

import com.ge.oilandgas.repairportal.sowconfig.entity.OperationTypeLov;

public interface OperationTypeLovDAO {

	List<OperationTypeLov> findOperationTypeLov();
}
