package com.ge.oilandgas.repairportal.sowconfig.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;

@Component
public class GenericRestTemplate {
	
	@Autowired
	private PredixTokenUtil predixTokenUtil;
	
	@Autowired
	private RestProxyTemplate restProxyTemplate;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public <T> ResponseTemplateDto<T> getRestApi(String url)throws Exception{
		ResponseTemplateDto<T> response = new ResponseTemplateDto<>();
		RestTemplate restTemplate = restProxyTemplate.getRestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "Bearer "+predixTokenUtil.getToken());
		HttpEntity entity = new HttpEntity(headers);
		ResponseEntity<ResponseTemplateDto> responseEntity= restTemplate.exchange(url,HttpMethod.GET, entity,ResponseTemplateDto.class);
		response = responseEntity.getBody();
		/*response = restTemplate.getForObject(url, ResponseTemplateDto.class);*/
		
		return response;
	}

}
