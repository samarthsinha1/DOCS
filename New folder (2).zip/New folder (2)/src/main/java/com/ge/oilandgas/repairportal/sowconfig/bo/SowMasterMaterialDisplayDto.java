package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

public class SowMasterMaterialDisplayDto implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	   private String partNumber;
	   private String nomenclature;
		
		public String getPartNumber() {
			return partNumber;
		}
		public void setPartNumber(String partNumber) {
			this.partNumber = partNumber;
		}
		public String getNomenclature() {
			return nomenclature;
		}
		public void setNomenclature(String nomenclature) {
			this.nomenclature = nomenclature;
		}
		
		

}
