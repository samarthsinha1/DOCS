package com.ge.oilandgas.repairportal.sowconfig.data;

public interface SbNewMaterialsDAO {

	
	
}
