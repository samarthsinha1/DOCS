package com.ge.oilandgas.repairportal.sowconfig.data;

import java.util.List;

import com.ge.oilandgas.repairportal.sowconfig.entity.ListPrice;

public interface ListPriceDAO extends GenericDAO<ListPrice, Long>{

	List<ListPrice> findListPriceByPriceListType(String priceListType);
	List<ListPrice> findListPriceByPriceListType(String priceListType,List<String> partNumerList);
	List<ListPrice> getListPriceMaterialPriceDetails(String partNumber, String newRepair);
	List<ListPrice> getPartListWithOutSupplier(List<String> priceListTypeList, List<String> supplierTypeList,
			String partNumberString);
	List<ListPrice> getPartListWithSupplier(List<String> priceListTypeList, List<String> supplierTypeList,
			String supplier, String partNumberString);
	ListPrice getListPriceByPartNumber(String partNumber);
}
