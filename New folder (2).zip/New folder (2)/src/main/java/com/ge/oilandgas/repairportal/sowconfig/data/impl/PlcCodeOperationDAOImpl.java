package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.oilandgas.repairportal.sowconfig.data.PlcCodeOperationDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.PlcCodeOperationRepository;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineOperationList;
import com.ge.oilandgas.repairportal.sowconfig.entity.ModuleOperationList;
import com.ge.oilandgas.repairportal.sowconfig.entity.PlcCodeOperation;


@Component
public class PlcCodeOperationDAOImpl extends GenericCrudDAOImpl<PlcCodeOperation, Long> implements PlcCodeOperationDAO{

	@Autowired
	private PlcCodeOperationRepository plcCodeOperationRepository;
	
    public PlcCodeOperationDAOImpl(PlcCodeOperationRepository plcCodeOperationRepository) {
        this.plcCodeOperationRepository = plcCodeOperationRepository;
    }
    
	public PlcCodeOperationDAOImpl() {
		super();

	}
	@SuppressWarnings("unchecked")
	public PlcCodeOperationRepository getRepository() {
        return plcCodeOperationRepository;
    }

	@Override
	public List<EngineOperationList> getAllEngineOperationList(String product) {
		return plcCodeOperationRepository.getAllEngineOperationList(product);
	}

	@Override
	public List<ModuleOperationList> getAllModuleOperationList(String product) {
		return plcCodeOperationRepository.getAllModuleOperationList(product);
	}
	
	@Override
	public List<ModuleOperationList> getAllModuleOperationList(String module,String product) {
		return plcCodeOperationRepository.getAllModuleOperationList(module,product);
	}

}
