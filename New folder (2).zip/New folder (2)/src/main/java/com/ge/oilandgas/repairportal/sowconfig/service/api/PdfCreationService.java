package com.ge.oilandgas.repairportal.sowconfig.service.api;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.ge.oilandgas.repairportal.sowconfig.bo.EngineInfoDto;

public interface PdfCreationService {
	void createSowTechnicalDetailsPdf(Map<String, Object> technicalDetailsPdfInput,String proposalType, HttpServletResponse response);
	void createSummaryByModuleDetailsPdf(Map<String, Object> summaryByModuleDetails,  HttpServletResponse response,String product);
	void createSummaryByModuleDetailsPdfNew(EngineInfoDto engineInfoDto,  HttpServletResponse response);
}
