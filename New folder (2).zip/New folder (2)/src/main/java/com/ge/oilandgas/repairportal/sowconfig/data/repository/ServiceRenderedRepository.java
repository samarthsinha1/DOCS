package com.ge.oilandgas.repairportal.sowconfig.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ge.oilandgas.repairportal.sowconfig.entity.ServiceRendered;

@Repository
public interface ServiceRenderedRepository  extends JpaRepository<ServiceRendered, Long>{

	@Query("SELECT s from ServiceRendered s")
	List<ServiceRendered> findByService();
	
}