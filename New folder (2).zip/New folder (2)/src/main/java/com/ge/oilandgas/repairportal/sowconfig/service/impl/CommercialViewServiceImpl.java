package com.ge.oilandgas.repairportal.sowconfig.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ge.oilandgas.repairportal.sowconfig.bo.CommercialViewDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;
import com.ge.oilandgas.repairportal.sowconfig.manager.CommercialViewManager;
import com.ge.oilandgas.repairportal.sowconfig.service.api.CommercialViewService;

@RequestMapping("/service/sowconfigurator")
@RestController
public class CommercialViewServiceImpl implements CommercialViewService{
	
	@Autowired
	CommercialViewManager commercialViewManager;

	@RequestMapping(value="/getCommercialViewByEngineInfoId/{engineInfoId}", method= RequestMethod.GET,produces = "application/json")
    public ResponseTemplateDto<CommercialViewDto> getCommercialViewByEngineInfoId(@PathVariable("engineInfoId") Long engineInfoId) {

		return commercialViewManager.getCommercialViewByEngineInfoId(engineInfoId);
	}
	
	@RequestMapping(value="/saveUpdateCommercialView", method= RequestMethod.POST, produces = "application/json", consumes = "application/json" )
	public ResponseTemplateDto<CommercialViewDto> saveUpdateCommercialView(@RequestBody CommercialViewDto commercialViewDto) {
		return commercialViewManager.saveUpdateCommercialView(commercialViewDto);
	}


}
