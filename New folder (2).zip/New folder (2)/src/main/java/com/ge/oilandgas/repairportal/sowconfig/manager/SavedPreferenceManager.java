package com.ge.oilandgas.repairportal.sowconfig.manager;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.SavedPreferenceDto;
import com.ge.oilandgas.repairportal.sowconfig.common.EntityBoMapper;
import com.ge.oilandgas.repairportal.sowconfig.data.SavedPreferenceDAO;
import com.ge.oilandgas.repairportal.sowconfig.entity.SavedPreference;

@Service
public class SavedPreferenceManager {
	
private static final Logger LOGGER = LoggerFactory.getLogger(SavedPreferenceManager.class);
	
	private EntityBoMapper entityBoMapper;
	private SavedPreferenceDAO savedPreferenceDAO;

	
	@Autowired
	public SavedPreferenceManager(EntityBoMapper entityBoMapper, SavedPreferenceDAO savedPreferenceDAO) {
		this.entityBoMapper = entityBoMapper;
		this.savedPreferenceDAO = savedPreferenceDAO;		
	}
	
	
	/**
	 * @param ssoId
	 * @return
	 */
	public ResponseTemplateDto<SavedPreferenceDto> getDetailsBySsoId(Long ssoId) {
		LOGGER.debug("Class::SavedPreferenceManager, Method::getDetailsBySsoId::ENTER");
		ResponseTemplateDto<SavedPreferenceDto> response = new ResponseTemplateDto<>();
		try{
			LOGGER.debug("Class::SavedPreferenceManager, Method::getDetailsBySsoId::ssoId"+ssoId);
			List<SavedPreference> savedPreferenceList= savedPreferenceDAO.findDetailsBySsoId(ssoId);
			List<SavedPreferenceDto> savedPreferenceDtoList = entityBoMapper.map(savedPreferenceList,SavedPreferenceDto.class);				
			response.setDataList(savedPreferenceDtoList);
			response.setOverallCount(new Long(savedPreferenceDtoList.size()));
			response.setSuccess(true);
			
		} catch (Exception e) {
			LOGGER.error("Error retrieving details for ssoId " + ssoId, e);
			response.setStatusMsg("Error retrieving details for ssoId  " + ssoId);
			response.setSuccess(false);
		}
		LOGGER.debug("Class::SavedPreferenceManager, Method::getDetailsBySsoId::EXIT");
		return response;
		
	}
	
	
	
	/**
	 * @param savedPreferenceDto
	 * @return
	 */
	public ResponseTemplateDto<SavedPreferenceDto> saveUpdateDetails(SavedPreferenceDto savedPreferenceDto) {
		LOGGER.debug("Class::SavedPreferenceManager, Method::saveUpdateDetails::ENTER");
		ResponseTemplateDto<SavedPreferenceDto> response = new ResponseTemplateDto<>();
		try{
			SavedPreference savedPreference =  entityBoMapper.map(savedPreferenceDto, SavedPreference.class);
			if(savedPreference.getId() == null) {
				savedPreference=savedPreferenceDAO.save(savedPreference);
			}else{
				savedPreference.setLastUpdateDate(new Date());
				savedPreference=savedPreferenceDAO.update(savedPreference);
			}
			savedPreferenceDto=entityBoMapper.map(savedPreference, SavedPreferenceDto.class);
			response.setData(savedPreferenceDto);
			response.setSuccess(true);
			response.setStatusMsg("Success");
		}catch (Exception e) {
			LOGGER.error("Issue in saving the Details" , e);
			response.setSuccess(false);
			response.setStatusMsg("Issue in saving the Details");
		}
		LOGGER.debug("Class::SavedPreferenceManager, Method::saveUpdateDetails::EXIT");
		return response;
	}



}
