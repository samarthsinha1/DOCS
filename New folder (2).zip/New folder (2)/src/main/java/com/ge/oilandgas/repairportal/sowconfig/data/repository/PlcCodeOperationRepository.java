package com.ge.oilandgas.repairportal.sowconfig.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.ge.oilandgas.repairportal.sowconfig.entity.EngineOperationList;
import com.ge.oilandgas.repairportal.sowconfig.entity.ModuleOperationList;
import com.ge.oilandgas.repairportal.sowconfig.entity.PlcCodeOperation;

@Repository
public interface PlcCodeOperationRepository  extends GenericCrudRepository<PlcCodeOperation, Long>{

	@Query("SELECT s from EngineOperationList s where s.plcProductType = ?1")
	List<EngineOperationList> getAllEngineOperationList(String product);
	@Query("SELECT s from ModuleOperationList s where s.plcProductType = ?1")
	List<ModuleOperationList> getAllModuleOperationList(String product);
	@Query("SELECT s from ModuleOperationList s where s.module =?1 and s.plcProductType = ?2")
	List<ModuleOperationList> getAllModuleOperationList(String module,String product);

}
