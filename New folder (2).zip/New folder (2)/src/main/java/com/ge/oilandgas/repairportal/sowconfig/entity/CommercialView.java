package com.ge.oilandgas.repairportal.sowconfig.entity;

import java.util.LinkedList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name= "ong_sowcfg_trx_commercial_view")
public class CommercialView extends GenericEntity<Long>{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SEQ_COMMERCIAL_VIEW", sequenceName="ong_sowcfg_trx_commercial_view_sequence_id")
	@GeneratedValue(generator="SEQ_COMMERCIAL_VIEW", strategy=GenerationType.SEQUENCE)
	@Column(name="commercial_view_id")
	private Long id;
	
	@Column(name="info_sequence_id")
	private Long engineInfoId;

	@Column(name="parts_discountable_cost_escalation")
	private float partsDiscountableCostEscalation;
	
	@Column(name="parts_non_discountable_cost_escalation")
	private float partsNonDiscountableCostEscalation;
	
	@Column(name="parts_consumables_cost_escalation")
	private float partsConsumablesCostEscalation;
	
	@Column(name="sb_cost_escalation")
	private float sbCostEscalation;
	
	@Column(name="labor_cost_escalation")
	private float laborCostEscalation;
	
	@Column(name="out_sourcing_repair_ge_airfolls_cost_escalation")
	private float outSourcingRepairGeAirfollsCostEscalation;
	
	@Column(name="out_sourcing_repair_vendor_cost_escalation")
	private float outSourcingRepairVendorCostEscalation;
	
	@Column(name="parts_discountable_cost")
	private float partsDiscountableCost;
	
	@Column(name="parts_non_discountable_cost")
	private float partsNonDiscountableCost;
	
	@Column(name="parts_consumables_cost")
	private float partsConsumablesCost;
	
	@Column(name="sb_cost")
	private float sbCost;
	
	@Column(name="labor_cost")
	private float laborCost;
	

	@Column(name="out_sourcing_repair_ge_airfolls_cost")
	private float outSourcingRepairGeAirfollsCost;
	
	@Column(name="out_sourcing_repair_vendor_cost")
	private float outSourcingRepairVendorCost;
		
	@Column(name="depot_test_cost")
	private float depotTestCost;

	@Column(name="out_sourcing_repair_ge_airfolls_markup")
	private float outSourcingRepairGeAirfollsMarkup;
	
	@Column(name="out_sourcing_repair_vendor_markup")
	private float outSourcingRepairVendorMarkup;
	
	@Column(name="parts_discountable_price_escalation")
	private float partsDiscountablePriceEscalation;
	
	@Column(name="parts_non_discountable_price_escalation")
	private float partsNonDiscountablePriceEscalation;
	
	@Column(name="parts_consumables_price_escalation")
	private float partsConsumablesPriceEscalation;
	
	@Column(name="sb_price_escalation")
	private float sbPriceEscalation;
	
	@Column(name="labor_price_escalation")
	private float laborPriceEscalation;
	
	@Column(name="out_sourcing_repair_ge_airfolls_price_escalation")
	private float outSourcingRepairGeAirfollsPriceEscalation;
	
	@Column(name="out_sourcing_repair_vendor_price_escalation")
	private float outSourcingRepairVendorPriceEscalation;

	@Column(name="parts_discountable_discount")
	private float partsDiscountableDiscount;
	
	@Column(name="parts_non_discountable_discount")
	private float partsNonDiscountableDiscount;
	
	@Column(name="parts_consumables_discount")
	private float partsConsumablesDiscount;
	
	@Column(name="sb_discount")
	private float sbDiscount;
	
	@Column(name="labor_discount")
	private float laborDiscount;
	
	@Column(name="depot_test_discount")
	private float depotTestDiscount;

	@Column(name="parts_discountable_quote_price")
	private float partsDiscountableQuotePrice;
	
	@Column(name="parts_non_discountable_quote_price")
	private float partsNonDiscountableQuotePrice;
	
	@Column(name="parts_consumables_quote_price")
	private float partsConsumablesQuotePrice;
	
	@Column(name="sb_quote_price")
	private float sbQuotePrice;
	
	@Column(name="labor_quote_price")
	private float laborQuotePrice;

	@Column(name="out_sourcing_repair_ge_airfolls_quote_price")
	private float outSourcingRepairGeAirfollsQuotePrice;
	
	@Column(name="out_sourcing_repair_vendor_quote_price")
	private float outSourcingRepairVendorQuotePrice;
		
	@Column(name="depot_test_quote_price")
	private float depotTestQuotePrice;
	
	@Column(name="parts_discountable_cm")
	private float partsDiscountableCm;
	
	@Column(name="parts_non_discountable_cm")
	private float partsNonDiscountableCm;
	
	@Column(name="parts_consumables_cm")
	private float partsConsumablesCm;
	
	@Column(name="sb_cm")
	private float sbCm;
	
	@Column(name="labor_cm")
	private float laborCm;
	
	@Column(name="out_sourcing_repair_ge_airfolls_cm")
	private float outSourcingRepairGeAirfollsCm;
	
	@Column(name="out_sourcing_repair_vendor_cm")
	private float outSourcingRepairVendorCm;
	
	@Column(name="depot_test_cm")
	private float depotTestCm;

	@Column(name="parts_discountable_cm_percentage")
	private float partsDiscountableCmPercentage;
	
	@Column(name="parts_non_discountable_cm_percentage")
	private float partsNonDiscountableCmPercentage;
	
	@Column(name="parts_consumables_cm_percentage")
	private float partsConsumablesCmPercentage;
	
	@Column(name="sb_cm_percentage")
	private float sbCmPercentage;
	
	@Column(name="labor_cm_percentage")
	private float laborCmPercentage;
	
	@Column(name="out_sourcing_repair_ge_airfolls_cm_percentage")
	private float outSourcingRepairGeAirfollsCmPercentage;
	
	@Column(name="out_sourcing_repair_vendor_cm_percentage")
	private float outSourcingRepairVendorCmPercentage;
	
	@Column(name="depot_test_cm_percentage")
	private float depotTestCmPercentage;
	
	//------------------
	@Column(name="parts_discountable_cost_sum")
	private float partsDiscountableCostSum;
	
	@Column(name="parts_non_discountable_cost_sum")
	private float partsNonDiscountableCostSum;
	
	@Column(name="parts_consumables_cost_sum")
	private float partsConsumablesCostSum;
	
	@Column(name="sb_cost_sum")
	private float sbCostSum;
	
	@Column(name="labor_cost_sum")
	private float laborCostSum;
	
	@Column(name="out_sourcing_repair_ge_airfolls_cost_sum")
	private float outSourcingRepairGeAirfollsCostSum;
	
	@Column(name="out_sourcing_repair_vendor_cost_sum")
	private float outSourcingRepairVendorCostSum;
	
	@Column(name="depot_test_cost_sum")
	private float depotTestCostSum;
	//------------------
	
	@Column(name="parts_discountable_price_sum")
	private float partsDiscountablePriceSum;
	
	@Column(name="parts_non_discountable_price_sum")
	private float partsNonDiscountablePriceSum;
	
	@Column(name="parts_consumables_price_sum")
	private float partsConsumablesPriceSum;
	
	@Column(name="sb_price_sum")
	private float sbPriceSum;
	
	@Column(name="labor_price_sum")
	private float laborPriceSum;
	
	@Column(name="out_sourcing_repair_ge_airfolls_price_sum")
	private float outSourcingRepairGeAirfollsPriceSum;
	
	@Column(name="out_sourcing_repair_vendor_price_sum")
	private float outSourcingRepairVendorPriceSum;

	@Column(name="depot_test_price_sum")
	private float depotTestPriceSum;
	
	@Column(name="over_all_discount")
	private float overAllDiscount;
	
	@Column(name="labor_supervising")
	private float laborSupervising;
	
	@Column(name="depot_test_cost_escalation")
	private float depotTestCostEscalation;
	
	@Column(name="depot_test_price_escalation")
	private float depotTestPriceEscalation;
	
	@Column(name="labor_hrs_sum")
	private float laborHrsSum;
	
	
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER, orphanRemoval=true)
	@JoinColumn(name="commercial_view_id",referencedColumnName="commercial_view_id", nullable=false)
	@OrderBy
	private List<PriceCategory> priceCategoryList = new LinkedList<>();
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
		

	public Long getEngineInfoId() {
		return engineInfoId;
	}

	public void setEngineInfoId(Long engineInfoId) {
		this.engineInfoId = engineInfoId;
	}

	public float getPartsDiscountableCostEscalation() {
		return partsDiscountableCostEscalation;
	}

	public void setPartsDiscountableCostEscalation(float partsDiscountableCostEscalation) {
		this.partsDiscountableCostEscalation = partsDiscountableCostEscalation;
	}

	public float getPartsNonDiscountableCostEscalation() {
		return partsNonDiscountableCostEscalation;
	}

	public void setPartsNonDiscountableCostEscalation(float partsNonDiscountableCostEscalation) {
		this.partsNonDiscountableCostEscalation = partsNonDiscountableCostEscalation;
	}

	public float getPartsConsumablesCostEscalation() {
		return partsConsumablesCostEscalation;
	}

	public void setPartsConsumablesCostEscalation(float partsConsumablesCostEscalation) {
		this.partsConsumablesCostEscalation = partsConsumablesCostEscalation;
	}

	public float getLaborCostEscalation() {
		return laborCostEscalation;
	}

	public void setLaborCostEscalation(float laborCostEscalation) {
		this.laborCostEscalation = laborCostEscalation;
	}

	public float getOutSourcingRepairGeAirfollsCostEscalation() {
		return outSourcingRepairGeAirfollsCostEscalation;
	}

	public void setOutSourcingRepairGeAirfollsCostEscalation(float outSourcingRepairGeAirfollsCostEscalation) {
		this.outSourcingRepairGeAirfollsCostEscalation = outSourcingRepairGeAirfollsCostEscalation;
	}

	public float getOutSourcingRepairVendorCostEscalation() {
		return outSourcingRepairVendorCostEscalation;
	}

	public void setOutSourcingRepairVendorCostEscalation(float outSourcingRepairVendorCostEscalation) {
		this.outSourcingRepairVendorCostEscalation = outSourcingRepairVendorCostEscalation;
	}

	public float getPartsDiscountableCost() {
		return partsDiscountableCost;
	}

	public void setPartsDiscountableCost(float partsDiscountableCost) {
		this.partsDiscountableCost = partsDiscountableCost;
	}

	public float getPartsNonDiscountableCost() {
		return partsNonDiscountableCost;
	}

	public void setPartsNonDiscountableCost(float partsNonDiscountableCost) {
		this.partsNonDiscountableCost = partsNonDiscountableCost;
	}

	public float getPartsConsumablesCost() {
		return partsConsumablesCost;
	}

	public void setPartsConsumablesCost(float partsConsumablesCost) {
		this.partsConsumablesCost = partsConsumablesCost;
	}

	public float getLaborCost() {
		return laborCost;
	}

	public void setLaborCost(float laborCost) {
		this.laborCost = laborCost;
	}

	public float getOutSourcingRepairGeAirfollsCost() {
		return outSourcingRepairGeAirfollsCost;
	}

	public void setOutSourcingRepairGeAirfollsCost(float outSourcingRepairGeAirfollsCost) {
		this.outSourcingRepairGeAirfollsCost = outSourcingRepairGeAirfollsCost;
	}

	public float getOutSourcingRepairVendorCost() {
		return outSourcingRepairVendorCost;
	}

	public void setOutSourcingRepairVendorCost(float outSourcingRepairVendorCost) {
		this.outSourcingRepairVendorCost = outSourcingRepairVendorCost;
	}

	public float getDepotTestCost() {
		return depotTestCost;
	}

	public void setDepotTestCost(float depotTestCost) {
		this.depotTestCost = depotTestCost;
	}

	public float getOutSourcingRepairGeAirfollsMarkup() {
		return outSourcingRepairGeAirfollsMarkup;
	}

	public void setOutSourcingRepairGeAirfollsMarkup(float outSourcingRepairGeAirfollsMarkup) {
		this.outSourcingRepairGeAirfollsMarkup = outSourcingRepairGeAirfollsMarkup;
	}

	public float getOutSourcingRepairVendorMarkup() {
		return outSourcingRepairVendorMarkup;
	}

	public void setOutSourcingRepairVendorMarkup(float outSourcingRepairVendorMarkup) {
		this.outSourcingRepairVendorMarkup = outSourcingRepairVendorMarkup;
	}

	public float getPartsDiscountablePriceEscalation() {
		return partsDiscountablePriceEscalation;
	}

	public void setPartsDiscountablePriceEscalation(float partsDiscountablePriceEscalation) {
		this.partsDiscountablePriceEscalation = partsDiscountablePriceEscalation;
	}

	public float getPartsNonDiscountablePriceEscalation() {
		return partsNonDiscountablePriceEscalation;
	}

	public void setPartsNonDiscountablePriceEscalation(float partsNonDiscountablePriceEscalation) {
		this.partsNonDiscountablePriceEscalation = partsNonDiscountablePriceEscalation;
	}

	public float getPartsConsumablesPriceEscalation() {
		return partsConsumablesPriceEscalation;
	}

	public void setPartsConsumablesPriceEscalation(float partsConsumablesPriceEscalation) {
		this.partsConsumablesPriceEscalation = partsConsumablesPriceEscalation;
	}

	public float getLaborPriceEscalation() {
		return laborPriceEscalation;
	}

	public void setLaborPriceEscalation(float laborPriceEscalation) {
		this.laborPriceEscalation = laborPriceEscalation;
	}

	public float getOutSourcingRepairGeAirfollsPriceEscalation() {
		return outSourcingRepairGeAirfollsPriceEscalation;
	}

	public void setOutSourcingRepairGeAirfollsPriceEscalation(float outSourcingRepairGeAirfollsPriceEscalation) {
		this.outSourcingRepairGeAirfollsPriceEscalation = outSourcingRepairGeAirfollsPriceEscalation;
	}

	public float getOutSourcingRepairVendorPriceEscalation() {
		return outSourcingRepairVendorPriceEscalation;
	}

	public void setOutSourcingRepairVendorPriceEscalation(float outSourcingRepairVendorPriceEscalation) {
		this.outSourcingRepairVendorPriceEscalation = outSourcingRepairVendorPriceEscalation;
	}

	public float getPartsDiscountableDiscount() {
		return partsDiscountableDiscount;
	}

	public void setPartsDiscountableDiscount(float partsDiscountableDiscount) {
		this.partsDiscountableDiscount = partsDiscountableDiscount;
	}

	public float getPartsNonDiscountableDiscount() {
		return partsNonDiscountableDiscount;
	}

	public void setPartsNonDiscountableDiscount(float partsNonDiscountableDiscount) {
		this.partsNonDiscountableDiscount = partsNonDiscountableDiscount;
	}

	public float getPartsConsumablesDiscount() {
		return partsConsumablesDiscount;
	}

	public void setPartsConsumablesDiscount(float partsConsumablesDiscount) {
		this.partsConsumablesDiscount = partsConsumablesDiscount;
	}

	public float getLaborDiscount() {
		return laborDiscount;
	}

	public void setLaborDiscount(float laborDiscount) {
		this.laborDiscount = laborDiscount;
	}

	public float getDepotTestDiscount() {
		return depotTestDiscount;
	}

	public void setDepotTestDiscount(float depotTestDiscount) {
		this.depotTestDiscount = depotTestDiscount;
	}

	public float getPartsDiscountableQuotePrice() {
		return partsDiscountableQuotePrice;
	}

	public void setPartsDiscountableQuotePrice(float partsDiscountableQuotePrice) {
		this.partsDiscountableQuotePrice = partsDiscountableQuotePrice;
	}

	public float getPartsNonDiscountableQuotePrice() {
		return partsNonDiscountableQuotePrice;
	}

	public void setPartsNonDiscountableQuotePrice(float partsNonDiscountableQuotePrice) {
		this.partsNonDiscountableQuotePrice = partsNonDiscountableQuotePrice;
	}

	public float getPartsConsumablesQuotePrice() {
		return partsConsumablesQuotePrice;
	}

	public void setPartsConsumablesQuotePrice(float partsConsumablesQuotePrice) {
		this.partsConsumablesQuotePrice = partsConsumablesQuotePrice;
	}

	public float getLaborQuotePrice() {
		return laborQuotePrice;
	}

	public void setLaborQuotePrice(float laborQuotePrice) {
		this.laborQuotePrice = laborQuotePrice;
	}

	public float getOutSourcingRepairGeAirfollsQuotePrice() {
		return outSourcingRepairGeAirfollsQuotePrice;
	}

	public void setOutSourcingRepairGeAirfollsQuotePrice(float outSourcingRepairGeAirfollsQuotePrice) {
		this.outSourcingRepairGeAirfollsQuotePrice = outSourcingRepairGeAirfollsQuotePrice;
	}

	public float getOutSourcingRepairVendorQuotePrice() {
		return outSourcingRepairVendorQuotePrice;
	}

	public void setOutSourcingRepairVendorQuotePrice(float outSourcingRepairVendorQuotePrice) {
		this.outSourcingRepairVendorQuotePrice = outSourcingRepairVendorQuotePrice;
	}

	public float getDepotTestQuotePrice() {
		return depotTestQuotePrice;
	}

	public void setDepotTestQuotePrice(float depotTestQuotePrice) {
		this.depotTestQuotePrice = depotTestQuotePrice;
	}

	public float getPartsDiscountableCm() {
		return partsDiscountableCm;
	}

	public void setPartsDiscountableCm(float partsDiscountableCm) {
		this.partsDiscountableCm = partsDiscountableCm;
	}

	public float getPartsNonDiscountableCm() {
		return partsNonDiscountableCm;
	}

	public void setPartsNonDiscountableCm(float partsNonDiscountableCm) {
		this.partsNonDiscountableCm = partsNonDiscountableCm;
	}

	public float getPartsConsumablesCm() {
		return partsConsumablesCm;
	}

	public void setPartsConsumablesCm(float partsConsumablesCm) {
		this.partsConsumablesCm = partsConsumablesCm;
	}

	public float getLaborCm() {
		return laborCm;
	}

	public void setLaborCm(float laborCm) {
		this.laborCm = laborCm;
	}

	public float getOutSourcingRepairGeAirfollsCm() {
		return outSourcingRepairGeAirfollsCm;
	}

	public void setOutSourcingRepairGeAirfollsCm(float outSourcingRepairGeAirfollsCm) {
		this.outSourcingRepairGeAirfollsCm = outSourcingRepairGeAirfollsCm;
	}

	public float getOutSourcingRepairVendorCm() {
		return outSourcingRepairVendorCm;
	}

	public void setOutSourcingRepairVendorCm(float outSourcingRepairVendorCm) {
		this.outSourcingRepairVendorCm = outSourcingRepairVendorCm;
	}

	public float getDepotTestCm() {
		return depotTestCm;
	}

	public void setDepotTestCm(float depotTestCm) {
		this.depotTestCm = depotTestCm;
	}

	public float getPartsDiscountableCmPercentage() {
		return partsDiscountableCmPercentage;
	}

	public void setPartsDiscountableCmPercentage(float partsDiscountableCmPercentage) {
		this.partsDiscountableCmPercentage = partsDiscountableCmPercentage;
	}

	public float getPartsNonDiscountableCmPercentage() {
		return partsNonDiscountableCmPercentage;
	}

	public void setPartsNonDiscountableCmPercentage(float partsNonDiscountableCmPercentage) {
		this.partsNonDiscountableCmPercentage = partsNonDiscountableCmPercentage;
	}

	public float getPartsConsumablesCmPercentage() {
		return partsConsumablesCmPercentage;
	}

	public void setPartsConsumablesCmPercentage(float partsConsumablesCmPercentage) {
		this.partsConsumablesCmPercentage = partsConsumablesCmPercentage;
	}

	public float getLaborCmPercentage() {
		return laborCmPercentage;
	}

	public void setLaborCmPercentage(float laborCmPercentage) {
		this.laborCmPercentage = laborCmPercentage;
	}

	public float getOutSourcingRepairGeAirfollsCmPercentage() {
		return outSourcingRepairGeAirfollsCmPercentage;
	}

	public void setOutSourcingRepairGeAirfollsCmPercentage(float outSourcingRepairGeAirfollsCmPercentage) {
		this.outSourcingRepairGeAirfollsCmPercentage = outSourcingRepairGeAirfollsCmPercentage;
	}

	public float getOutSourcingRepairVendorCmPercentage() {
		return outSourcingRepairVendorCmPercentage;
	}

	public void setOutSourcingRepairVendorCmPercentage(float outSourcingRepairVendorCmPercentage) {
		this.outSourcingRepairVendorCmPercentage = outSourcingRepairVendorCmPercentage;
	}

	public float getDepotTestCmPercentage() {
		return depotTestCmPercentage;
	}

	public void setDepotTestCmPercentage(float depotTestCmPercentage) {
		this.depotTestCmPercentage = depotTestCmPercentage;
	}

	public float getPartsDiscountableCostSum() {
		return partsDiscountableCostSum;
	}

	public void setPartsDiscountableCostSum(float partsDiscountableCostSum) {
		this.partsDiscountableCostSum = partsDiscountableCostSum;
	}

	public float getPartsNonDiscountableCostSum() {
		return partsNonDiscountableCostSum;
	}

	public void setPartsNonDiscountableCostSum(float partsNonDiscountableCostSum) {
		this.partsNonDiscountableCostSum = partsNonDiscountableCostSum;
	}

	public float getPartsConsumablesCostSum() {
		return partsConsumablesCostSum;
	}

	public void setPartsConsumablesCostSum(float partsConsumablesCostSum) {
		this.partsConsumablesCostSum = partsConsumablesCostSum;
	}

	public float getLaborCostSum() {
		return laborCostSum;
	}

	public void setLaborCostSum(float laborCostSum) {
		this.laborCostSum = laborCostSum;
	}

	public float getOutSourcingRepairGeAirfollsCostSum() {
		return outSourcingRepairGeAirfollsCostSum;
	}

	public void setOutSourcingRepairGeAirfollsCostSum(float outSourcingRepairGeAirfollsCostSum) {
		this.outSourcingRepairGeAirfollsCostSum = outSourcingRepairGeAirfollsCostSum;
	}

	public float getOutSourcingRepairVendorCostSum() {
		return outSourcingRepairVendorCostSum;
	}

	public void setOutSourcingRepairVendorCostSum(float outSourcingRepairVendorCostSum) {
		this.outSourcingRepairVendorCostSum = outSourcingRepairVendorCostSum;
	}

	public float getDepotTestCostSum() {
		return depotTestCostSum;
	}

	public void setDepotTestCostSum(float depotTestCostSum) {
		this.depotTestCostSum = depotTestCostSum;
	}

	public float getPartsDiscountablePriceSum() {
		return partsDiscountablePriceSum;
	}

	public void setPartsDiscountablePriceSum(float partsDiscountablePriceSum) {
		this.partsDiscountablePriceSum = partsDiscountablePriceSum;
	}

	public float getPartsNonDiscountablePriceSum() {
		return partsNonDiscountablePriceSum;
	}

	public void setPartsNonDiscountablePriceSum(float partsNonDiscountablePriceSum) {
		this.partsNonDiscountablePriceSum = partsNonDiscountablePriceSum;
	}

	public float getPartsConsumablesPriceSum() {
		return partsConsumablesPriceSum;
	}

	public void setPartsConsumablesPriceSum(float partsConsumablesPriceSum) {
		this.partsConsumablesPriceSum = partsConsumablesPriceSum;
	}

	public float getLaborPriceSum() {
		return laborPriceSum;
	}

	public void setLaborPriceSum(float laborPriceSum) {
		this.laborPriceSum = laborPriceSum;
	}

	public float getOutSourcingRepairGeAirfollsPriceSum() {
		return outSourcingRepairGeAirfollsPriceSum;
	}

	public void setOutSourcingRepairGeAirfollsPriceSum(float outSourcingRepairGeAirfollsPriceSum) {
		this.outSourcingRepairGeAirfollsPriceSum = outSourcingRepairGeAirfollsPriceSum;
	}

	public float getOutSourcingRepairVendorPriceSum() {
		return outSourcingRepairVendorPriceSum;
	}

	public void setOutSourcingRepairVendorPriceSum(float outSourcingRepairVendorPriceSum) {
		this.outSourcingRepairVendorPriceSum = outSourcingRepairVendorPriceSum;
	}

	public float getDepotTestPriceSum() {
		return depotTestPriceSum;
	}

	public void setDepotTestPriceSum(float depotTestPriceSum) {
		this.depotTestPriceSum = depotTestPriceSum;
	}

	public float getOverAllDiscount() {
		return overAllDiscount;
	}

	public void setOverAllDiscount(float overAllDiscount) {
		this.overAllDiscount = overAllDiscount;
	}

	public List<PriceCategory> getPriceCategoryList() {
		return priceCategoryList;
	}

	public void setPriceCategoryList(List<PriceCategory> priceCategoryList) {
		this.priceCategoryList = priceCategoryList;
	}

	public float getSbCostEscalation() {
		return sbCostEscalation;
	}

	public void setSbCostEscalation(float sbCostEscalation) {
		this.sbCostEscalation = sbCostEscalation;
	}

	public float getSbCost() {
		return sbCost;
	}

	public void setSbCost(float sbCost) {
		this.sbCost = sbCost;
	}

	public float getSbPriceEscalation() {
		return sbPriceEscalation;
	}

	public void setSbPriceEscalation(float sbPriceEscalation) {
		this.sbPriceEscalation = sbPriceEscalation;
	}

	public float getSbDiscount() {
		return sbDiscount;
	}

	public void setSbDiscount(float sbDiscount) {
		this.sbDiscount = sbDiscount;
	}

	public float getSbQuotePrice() {
		return sbQuotePrice;
	}

	public void setSbQuotePrice(float sbQuotePrice) {
		this.sbQuotePrice = sbQuotePrice;
	}

	public float getSbCm() {
		return sbCm;
	}

	public void setSbCm(float sbCm) {
		this.sbCm = sbCm;
	}

	public float getSbCmPercentage() {
		return sbCmPercentage;
	}

	public void setSbCmPercentage(float sbCmPercentage) {
		this.sbCmPercentage = sbCmPercentage;
	}

	public float getSbCostSum() {
		return sbCostSum;
	}

	public void setSbCostSum(float sbCostSum) {
		this.sbCostSum = sbCostSum;
	}

	public float getSbPriceSum() {
		return sbPriceSum;
	}

	public void setSbPriceSum(float sbPriceSum) {
		this.sbPriceSum = sbPriceSum;
	}

	public float getLaborSupervising() {
		return laborSupervising;
	}

	public void setLaborSupervising(float laborSupervising) {
		this.laborSupervising = laborSupervising;
	}

	public float getDepotTestCostEscalation() {
		return depotTestCostEscalation;
	}

	public void setDepotTestCostEscalation(float depotTestCostEscalation) {
		this.depotTestCostEscalation = depotTestCostEscalation;
	}

	public float getDepotTestPriceEscalation() {
		return depotTestPriceEscalation;
	}

	public void setDepotTestPriceEscalation(float depotTestPriceEscalation) {
		this.depotTestPriceEscalation = depotTestPriceEscalation;
	}

	public float getLaborHrsSum() {
		return laborHrsSum;
	}

	public void setLaborHrsSum(float laborHrsSum) {
		this.laborHrsSum = laborHrsSum;
	}
	

}
