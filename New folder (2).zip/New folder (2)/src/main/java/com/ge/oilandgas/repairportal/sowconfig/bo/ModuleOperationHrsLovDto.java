package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

public class ModuleOperationHrsLovDto  extends AuditDataDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5662977857607383201L;
	private Long id;
	private String model;
	private float operationHrs;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public float getOperationHrs() {
		return operationHrs;
	}
	public void setOperationHrs(float operationHrs) {
		this.operationHrs = operationHrs;
	}
	
	
}
