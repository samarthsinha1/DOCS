package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;
import java.util.Date;


public class EngineInfoForAllSowDto extends AuditDataDto implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3678725233244497891L;
	private Long id;
	private String docName;
	private String scopeType;
	private Float stdDocRev;
	private Float sowDocRev;
	private String product;
	private String model;
	private Long componentSequenceId; 
	private String customerName;
	private Date engineDate;
	private String serialNumber;
	private String status;
	private String sowDescription;
	private String opptyId;
	private Float opptyRev;
	private String opptyType;
	private String proposalType;
	private String userFirstName;
	private String userLastName;
	private String userMiddleName;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public String getScopeType() {
		return scopeType;
	}
	public void setScopeType(String scopeType) {
		this.scopeType = scopeType;
	}
	public Float getSowDocRev() {
		return sowDocRev;
	}
	public void setSowDocRev(Float sowDocRev) {
		this.sowDocRev = sowDocRev;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public Long getComponentSequenceId() {
		return componentSequenceId;
	}
	public void setComponentSequenceId(Long componentSequenceId) {
		this.componentSequenceId = componentSequenceId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Date getEngineDate() {
		return engineDate;
	}
	public void setEngineDate(Date engineDate) {
		this.engineDate = engineDate;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSowDescription() {
		return sowDescription;
	}
	public void setSowDescription(String sowDescription) {
		this.sowDescription = sowDescription;
	}
	public String getOpptyId() {
		return opptyId;
	}
	public void setOpptyId(String opptyId) {
		this.opptyId = opptyId;
	}
	public Float getOpptyRev() {
		return opptyRev;
	}
	public void setOpptyRev(Float opptyRev) {
		this.opptyRev = opptyRev;
	}
	public String getOpptyType() {
		return opptyType;
	}
	public void setOpptyType(String opptyType) {
		this.opptyType = opptyType;
	}
	public String getProposalType() {
		return proposalType;
	}
	public void setProposalType(String proposalType) {
		this.proposalType = proposalType;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public Float getStdDocRev() {
		return stdDocRev;
	}
	public void setStdDocRev(Float stdDocRev) {
		this.stdDocRev = stdDocRev;
	}
	public String getUserFirstName() {
		return userFirstName;
	}
	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}
	public String getUserLastName() {
		return userLastName;
	}
	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}
	public String getUserMiddleName() {
		return userMiddleName;
	}
	public void setUserMiddleName(String userMiddleName) {
		this.userMiddleName = userMiddleName;
	}
	
	
	
}
