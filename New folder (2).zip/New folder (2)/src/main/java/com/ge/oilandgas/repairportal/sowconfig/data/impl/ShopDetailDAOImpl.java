package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.oilandgas.repairportal.sowconfig.data.ShopDetailDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.ShopDetailRepository;
import com.ge.oilandgas.repairportal.sowconfig.entity.ShopDetail;


@Component
public class ShopDetailDAOImpl implements ShopDetailDAO {
	
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ShopDetailDAOImpl.class);
	@Autowired
	private ShopDetailRepository shopDetailRepository;
	
	  public ShopDetailDAOImpl(ShopDetailRepository shopDetailRepository) {
	        this.shopDetailRepository = shopDetailRepository;
	    }
	  public ShopDetailDAOImpl() {
	       super();
	    }

	  @SuppressWarnings("unchecked")
	
	    public ShopDetailRepository getRepository() {
	        return shopDetailRepository;
	    }

	@Override
	public List<ShopDetail> findByEngineModel(String engineModel,String product) {
		
		LOGGER.debug("Class::ShopDetailDAOImpl, Method::findByEngineModel::model"+engineModel);
		LOGGER.debug("Class::ShopDetailDAOImpl, Method::findByEngineModel::shopDetailRepository.findByEngineModel(engineModel)"+shopDetailRepository.findByEngineModel(engineModel,product));
		return shopDetailRepository.findByEngineModel(engineModel,product);
	}




}
