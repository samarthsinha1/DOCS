package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.ge.oilandgas.repairportal.sowconfig.data.SbOperationsDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.SbOperationsRepository;

@Component
public class SbOperationsDAOImpl implements SbOperationsDAO {

	private static final Logger logger = LoggerFactory.getLogger(SbOperationsDAOImpl.class);
	
	@Autowired
	private SbOperationsRepository sbOperationsRepository;
	
	public SbOperationsDAOImpl(SbOperationsRepository sbOperationsRepository){
		this.sbOperationsRepository=sbOperationsRepository;
	}
	
	public SbOperationsDAOImpl(){
		super();
	}
	
	public SbOperationsRepository getRepository(){
		return sbOperationsRepository;
	}
	
}
