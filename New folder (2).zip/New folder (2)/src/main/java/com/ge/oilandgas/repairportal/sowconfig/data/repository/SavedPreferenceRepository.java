package com.ge.oilandgas.repairportal.sowconfig.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ge.oilandgas.repairportal.sowconfig.entity.SavedPreference;

@Repository
public interface SavedPreferenceRepository extends GenericCrudRepository<SavedPreference, Long>{

	@Query("SELECT s from SavedPreference s where s.ssoId=?1")
	List<SavedPreference> findDetailsBySsoId(Long ssoId);
	
}
