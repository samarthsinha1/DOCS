package com.ge.oilandgas.repairportal.sowconfig.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ge.oilandgas.repairportal.sowconfig.entity.ListPrice;

@Repository
public interface ListPriceRepository extends GenericCrudRepository<ListPrice, Long>{

	@Query("SELECT s FROM ListPrice s WHERE s.priceListType=?1 order by s.partNumber")
	List<ListPrice> findByPriceListType(String priceListType);
	
	@Query("SELECT s FROM ListPrice s WHERE LOWER(s.partNumber)= LOWER(?1) and s.priceListType=?2 order by s.partNumber")
	List<ListPrice> getListPriceMaterialPriceDetails(String partNumber, String newRepair);

	@Query("SELECT s from ListPrice s where s.priceListType in :priceListTypeList and s.supplierType in :supplierTypeList and LOWER(s.partNumber) like :partNumberString% order by s.partNumber")
	List<ListPrice> getPartListWithOutSupplier(@Param("priceListTypeList")List<String> priceListTypeList, @Param("supplierTypeList")List<String> supplierTypeList,
			@Param("partNumberString")String partNumberString);
	
	@Query("SELECT s from ListPrice s where s.priceListType in :priceListTypeList and s.supplierType in :supplierTypeList and LOWER(s.supplier) = LOWER(:supplier) and LOWER(s.partNumber) like :partNumberString% order by s.partNumber")
	List<ListPrice> getPartListWithSupplier(@Param("priceListTypeList") List<String> priceListTypeList, @Param("supplierTypeList") List<String> supplierTypeList,
			@Param("supplier")String supplier,@Param("partNumberString") String partNumberString);
	
	@Query("SELECT s FROM ListPrice s WHERE s.priceListType=?1 and LOWER(s.partNumber) in ?2 order by s.partNumber")
	List<ListPrice> findByPriceListType(String priceListType, List<String> partNumerList);

	@Query("SELECT s FROM ListPrice s WHERE LOWER(s.partNumber)= LOWER(?1)")
	ListPrice getListPriceByPartNumber(String partNumber);
}
