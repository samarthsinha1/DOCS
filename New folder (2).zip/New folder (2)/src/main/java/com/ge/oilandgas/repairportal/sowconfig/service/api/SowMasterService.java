package com.ge.oilandgas.repairportal.sowconfig.service.api;

import java.util.List;
import java.util.Map;

import com.ge.oilandgas.repairportal.sowconfig.bo.CommonPostDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineModuleDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.EngineOperationListDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ListPriceDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ModuleOperationListDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.OperationTypeLovDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.OpptyTypeLovDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ProductLovDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ProposalTypeLovDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.RepairSupplierDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ResponseTemplateDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ServiceRenderedDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.ShopDetailDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.SowMasterMaterialDtoForUI;
import com.ge.oilandgas.repairportal.sowconfig.bo.StdSbLovDto;

public interface SowMasterService {
	
	ResponseTemplateDto<ShopDetailDto> getEngineModelShopDetails( String engineModel, String product  );
		
	ResponseTemplateDto<ServiceRenderedDto> getServices();
	
	ResponseTemplateDto<RepairSupplierDto> getRepairSupplier();
	
	ResponseTemplateDto<EngineModuleDto> getEngineModule( String product);
	
	ResponseTemplateDto<List<EngineOperationListDto>> getEngineOperationList( String product, String engine);
	
	ResponseTemplateDto<List<ModuleOperationListDto>> getModuleOperationList( String product, String engine, String module);

	ResponseTemplateDto<SowMasterMaterialDtoForUI> getMaterialByEngine(String product, String model, String engine, String newRepair,String docName, String sowStatus);

	ResponseTemplateDto<SowMasterMaterialDtoForUI> getMaterialByModule(String product, String model, String engine, String module, String newRepair,String docName, String sowStatus);
	
	ResponseTemplateDto<Map<String,List<SowMasterMaterialDtoForUI>>> getMaterialByModuleList(String product, String model, String engine, List<String> moduleList, String newRepair);
	
	ResponseTemplateDto<List<OpptyTypeLovDto>> getOpptyTypeList();
	
	ResponseTemplateDto<List<ProposalTypeLovDto>> getProposalTypeList();
	
	ResponseTemplateDto<Long> suggestedNextValueForModuleOperationList(String product,String engine,String module);
	
	ResponseTemplateDto<Long> suggestedNextValueForEngineOperationList(String product,String engine);
	
    ResponseTemplateDto<EngineOperationListDto> saveEngineOperationList(List<EngineOperationListDto> engineOperationListDto);	

	ResponseTemplateDto<ModuleOperationListDto> saveModuleOperationList(List<ModuleOperationListDto> moduleOperationListDto);

	ResponseTemplateDto<OperationTypeLovDto> getOperationTypeLov();
	
	ResponseTemplateDto<ListPriceDto> getListPriceMaterialPriceDetails(CommonPostDto commonPostDto);

	ResponseTemplateDto<List<ListPriceDto>> getPartMaterialList(CommonPostDto commonPostDto);
	
	ResponseTemplateDto<List<StdSbLovDto>> getStdSbLov();
	
	ResponseTemplateDto<List<ProductLovDto>> getProductList();
}
