package com.ge.oilandgas.repairportal.sowconfig.configuration;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

//@SuppressWarnings("deprecation")
@Configuration
@Profile(value={"local"})
public class LocalDataSourceConfiguration {
		
	 @Bean(name="entityManagerFactory")
    public LocalContainerEntityManagerFactoryBean localContainerEntityManagerFactoryBean( DataSource dataSource  ) throws Exception {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource( dataSource );
//        em.setPersistenceProvider(new PersistenceProviderImpl());
//        em.setPackagesToScan("com.ge.aviation.epa.swat"); //The packages to search for Entities, line required to avoid looking into the persistence.xml
//        em.setPersistenceUnitName("workScope");
        
//        em.setPersistenceProvider(new PersistenceProviderImpl());
       /* Map<String, String> p = new HashMap<String, String>();
        p.put(org.hibernate.cfg.Environment.DIALECT, HSQLDialect.class.getName());
        p.put(org.hibernate.cfg.Environment.SHOW_SQL, "true");
        em.setJpaPropertyMap(p);*/
       
        
        return em;
    }
    
}

