package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ListPriceDto  extends AuditDataDto implements Serializable {

	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String partNumber;
	private String nomenclature;
	private List<ListPriceSuppliersDto> supplierList=new ArrayList<>();
	private List<ListPriceServicesRenderedDto> serviceRenderedList = new ArrayList<>();
	
	
	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getNomenclature() {
		return nomenclature;
	}

	public void setNomenclature(String nomenclature) {
		this.nomenclature = nomenclature;
	}

	public List<ListPriceSuppliersDto> getSupplierList() {
		return supplierList;
	}

	public void setSupplierList(List<ListPriceSuppliersDto> supplierList) {
		this.supplierList = supplierList;
	}

	public List<ListPriceServicesRenderedDto> getServiceRenderedList() {
		return serviceRenderedList;
	}

	public void setServiceRenderedList(List<ListPriceServicesRenderedDto> serviceRenderedList) {
		this.serviceRenderedList = serviceRenderedList;
	}
	 
	 

}
