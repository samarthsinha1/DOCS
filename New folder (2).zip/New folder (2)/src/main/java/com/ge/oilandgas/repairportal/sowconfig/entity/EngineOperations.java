package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name= "ong_sowcfg_trx_engine_operations")
public class EngineOperations extends GenericEntity<Long>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SEQ_ENGINE_OPERATIONS", sequenceName="ong_sowcfg_trx_engine_operations_sequence_id")
	@GeneratedValue(generator="SEQ_ENGINE_OPERATIONS", strategy=GenerationType.SEQUENCE)
	@Column(name="operations_sequence_id")
	private Long id;
		
	@Column(name="OPERATIONS")
	private String operations;
	
	@Column(name="LABOR_HOURS")
	private float laborHours;
	
	@Column(name="LABOR_COST")
	private float laborCost;
	
	@Column(name="labor_price")
	private float laborPrice;
	
	@Column(name="labor_quote_price")
	private float laborQuotePrice;
	
	 @Column(name="operation_type")
	 private String operationType;
	 @Column(name="num_operation")
	 private Long numOperation;
	 
	 @Column(name="base_labor_hours")
	 private float baseLaborHours;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOperations() {
		return operations;
	}

	public void setOperations(String operations) {
		this.operations = operations;
	}

	public float getLaborPrice() {
		return laborPrice;
	}

	public void setLaborPrice(float laborPrice) {
		this.laborPrice = laborPrice;
	}

	public float getLaborQuotePrice() {
		return laborQuotePrice;
	}

	public void setLaborQuotePrice(float laborQuotePrice) {
		this.laborQuotePrice = laborQuotePrice;
	}

	public float getLaborHours() {
		return laborHours;
	}

	public void setLaborHours(float laborHours) {
		this.laborHours = laborHours;
	}

	public float getLaborCost() {
		return laborCost;
	}

	public void setLaborCost(float laborCost) {
		this.laborCost = laborCost;
	}

	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	public Long getNumOperation() {
		return numOperation;
	}

	public void setNumOperation(Long numOperation) {
		this.numOperation = numOperation;
	}

	public float getBaseLaborHours() {
		return baseLaborHours;
	}

	public void setBaseLaborHours(float baseLaborHours) {
		this.baseLaborHours = baseLaborHours;
	}
	
	
}
