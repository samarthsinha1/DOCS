package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

public class ProposalTypeLovDto extends AuditDataDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6211141425262864913L;
	private Long id;
	private String proposalTypeName;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getProposalTypeName() {
		return proposalTypeName;
	}
	public void setProposalTypeName(String proposalTypeName) {
		this.proposalTypeName = proposalTypeName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
