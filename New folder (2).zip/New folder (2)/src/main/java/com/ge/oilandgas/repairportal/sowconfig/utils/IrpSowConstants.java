package com.ge.oilandgas.repairportal.sowconfig.utils;

public interface IrpSowConstants {
	String STD_TEMPLATE = "STD Template";
	String SOW_CONFIG= "SOW Config";
}
