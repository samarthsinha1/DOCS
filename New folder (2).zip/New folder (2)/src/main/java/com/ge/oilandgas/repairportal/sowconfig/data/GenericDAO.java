/*
 * Copyright (c) 2014 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */
package com.ge.oilandgas.repairportal.sowconfig.data;

import org.springframework.data.domain.Pageable;
import java.io.Serializable;
import java.util.List;


/**
 * Generic dao used by all basic DAO
 */
 
public interface GenericDAO<T extends Serializable, ID extends Serializable> {
    T save(T entity);

    List<T> save(List<T> entities);

    T findOne(ID id);

    List<T> findAll();

    List<T> findAll(Pageable pageable);

    T delete(ID id);
    
    List<T> delete(List<T> entities);
    
    List<T> update(List<T> entities);

    T update(T entity);
}
