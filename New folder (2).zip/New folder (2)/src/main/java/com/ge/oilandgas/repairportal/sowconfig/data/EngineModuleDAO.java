package com.ge.oilandgas.repairportal.sowconfig.data;

import java.util.List;

import com.ge.oilandgas.repairportal.sowconfig.entity.EngineModule;


public interface EngineModuleDAO{
	
	// EngineInfo findByModel(String model);
	 List<EngineModule> findEngineModule(String product);

}
