package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

public class EngineModuleDto implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String engine;
	private String engineDisplayName;
	private String engineDiscription;
	private String moduleCode;
	private String moduleName;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getEngine() {
		return engine;
	}
	public void setEngine(String engine) {
		this.engine = engine;
	}

	public String getModuleCode() {
		return moduleCode;
	}
	public void setModuleCode(String moduleCode) {
		this.moduleCode = moduleCode;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getEngineDisplayName() {
		return engineDisplayName;
	}
	public void setEngineDisplayName(String engineDisplayName) {
		this.engineDisplayName = engineDisplayName;
	}
	public String getEngineDiscription() {
		return engineDiscription;
	}
	public void setEngineDiscription(String engineDiscription) {
		this.engineDiscription = engineDiscription;
	}
	
	
	
}
