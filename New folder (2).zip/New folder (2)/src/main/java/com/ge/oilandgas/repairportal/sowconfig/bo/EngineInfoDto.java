package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;


public class EngineInfoDto extends AuditDataDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	private Long id;
	private String docType;
	private String docName;
	private String stdDocName;
	private String scopeType;
	private Float stdDocRev;
	private Float sowDocRev;
	private String product;
	private String model;
	private Long componentSequenceId; 
	private String customerName;
	private Date engineDate;
	private String serialNumber;
	private String depotRepairShop;
	private float laborHourUnitCost;
	private float laborHourUnitPrice;
	private String status;
	private String sbFileName;
	private boolean isExisting;
	private String adminUploaded;
	private String sowDescription;
	private String opptyId;
	private float opptyRev;
	private String opptyType;
	private String proposalType;
	private Date proposalDate;
	private List<String> sowSelectionList;
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	private List<ServiceBulletinsDto> serviceBulletinList = new LinkedList<>();
	
	private List<ModelEngineDto> modelEngineList = new LinkedList<>();
	
	private List<String> depotRepairShopList = new ArrayList<>();
	
	private List<MasterMaterialLovTempDto> masterMaterialLovTempDtoList = new ArrayList<>();
	
   
	public List<ModelEngineDto> getModelEngineList() {
		return modelEngineList;
	}
	public void setModelEngineList(List<ModelEngineDto> modelEngineList) {
		this.modelEngineList = modelEngineList;
	}
	public List<ServiceBulletinsDto> getServiceBulletinList() {
		return serviceBulletinList;
	}
	public void setServiceBulletinList(List<ServiceBulletinsDto> serviceBulletinList) {
		this.serviceBulletinList = serviceBulletinList;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public String getScopeType() {
		return scopeType;
	}
	public void setScopeType(String scopeType) {
		this.scopeType = scopeType;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public Date getEngineDate() {
		return engineDate;
	}
	public void setEngineDate(Date engineDate) {
		this.engineDate = engineDate;
	}
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getDepotRepairShop() {
		return depotRepairShop;
	}
	public void setDepotRepairShop(String depotRepairShop) {
		this.depotRepairShop = depotRepairShop;
	}
	public float getLaborHourUnitCost() {
		return laborHourUnitCost;
	}
	public void setLaborHourUnitCost(float laborHourUnitCost) {
		this.laborHourUnitCost = laborHourUnitCost;
	}
	public float getLaborHourUnitPrice() {
		return laborHourUnitPrice;
	}
	public void setLaborHourUnitPrice(float laborHourUnitPrice) {
		this.laborHourUnitPrice = laborHourUnitPrice;
	}

	public Float getStdDocRev() {
		return stdDocRev;
	}
	public void setStdDocRev(Float stdDocRev) {
		this.stdDocRev = stdDocRev;
	}
	public Float getSowDocRev() {
		return sowDocRev;
	}
	public void setSowDocRev(Float sowDocRev) {
		this.sowDocRev = sowDocRev;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public Long getComponentSequenceId() {
		return componentSequenceId;
	}
	public void setComponentSequenceId(Long componentSequenceId) {
		this.componentSequenceId = componentSequenceId;
	}
	public List<String> getDepotRepairShopList() {
		return depotRepairShopList;
	}
	public void setDepotRepairShopList(List<String> depotRepairShopList) {
		this.depotRepairShopList = depotRepairShopList;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public boolean isExisting() {
		return isExisting;
	}
	public void setExisting(boolean isExisting) {
		this.isExisting = isExisting;
	}
	
	
	
	public String getSbFileName() {
		return sbFileName;
	}
	public void setSbFileName(String sbFileName) {
		this.sbFileName = sbFileName;
	}
	public String getStdDocName() {
		return stdDocName;
	}
	public void setStdDocName(String stdDocName) {
		this.stdDocName = stdDocName;
	}
	
	public String getAdminUploaded() {
		return adminUploaded;
	}
	public void setAdminUploaded(String adminUploaded) {
		this.adminUploaded = adminUploaded;
	}
	
	public String getSowDescription() {
		return sowDescription;
	}
	public void setSowDescription(String sowDescription) {
		this.sowDescription = sowDescription;
	}
	
	public String getOpptyId() {
		return opptyId;
	}
	public void setOpptyId(String opptyId) {
		this.opptyId = opptyId;
	}
	public float getOpptyRev() {
		return opptyRev;
	}
	public void setOpptyRev(float opptyRev) {
		this.opptyRev = opptyRev;
	}
	public String getOpptyType() {
		return opptyType;
	}
	public void setOpptyType(String opptyType) {
		this.opptyType = opptyType;
	}
	public String getProposalType() {
		return proposalType;
	}
	public void setProposalType(String proposalType) {
		this.proposalType = proposalType;
	}
	
	public Date getProposalDate() {
		return proposalDate;
	}
	public void setProposalDate(Date proposalDate) {
		this.proposalDate = proposalDate;
	}
	
	public List<String> getSowSelectionList() {
		return sowSelectionList;
	}
	public void setSowSelectionList(List<String> sowSelectionList) {
		this.sowSelectionList = sowSelectionList;
	}
	@Override
	public String toString() {
		return "EngineInfoDto [id=" + id + ", docType=" + docType + ", docName=" + docName + ", stdDocName="
				+ stdDocName + ", scopeType=" + scopeType + ", stdDocRev=" + stdDocRev + ", sowDocRev=" + sowDocRev
				+ ", product=" + product + ", model=" + model + ", componentSequenceId=" + componentSequenceId
				+ ", customerName=" + customerName + ", engineDate=" + engineDate + ", serialNumber=" + serialNumber
				+ ", depotRepairShop=" + depotRepairShop + ", laborHourUnitCost=" + laborHourUnitCost
				+ ", laborHourUnitPrice=" + laborHourUnitPrice + ", status=" + status + ", sbFileName=" + sbFileName
				+ ", isExisting=" + isExisting + ", serviceBulletinList=" + serviceBulletinList + ", modelEngineList="
				+ modelEngineList + ", depotRepairShopList=" + depotRepairShopList+ "]"; 
	}
	public List<MasterMaterialLovTempDto> getMasterMaterialLovTempDtoList() {
		return masterMaterialLovTempDtoList;
	}
	public void setMasterMaterialLovTempDtoList(List<MasterMaterialLovTempDto> masterMaterialLovTempDtoList) {
		this.masterMaterialLovTempDtoList = masterMaterialLovTempDtoList;
	}
	
	
	
}
