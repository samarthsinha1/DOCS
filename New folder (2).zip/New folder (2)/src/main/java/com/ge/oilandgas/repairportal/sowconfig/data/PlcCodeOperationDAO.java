package com.ge.oilandgas.repairportal.sowconfig.data;

import java.util.List;

import com.ge.oilandgas.repairportal.sowconfig.entity.EngineOperationList;
import com.ge.oilandgas.repairportal.sowconfig.entity.ModuleOperationList;
import com.ge.oilandgas.repairportal.sowconfig.entity.PlcCodeOperation;

public interface PlcCodeOperationDAO extends GenericDAO<PlcCodeOperation,Long> {
	List<EngineOperationList> getAllEngineOperationList(String product);
	List<ModuleOperationList> getAllModuleOperationList(String product);
	List<ModuleOperationList> getAllModuleOperationList(String module,String product);
}
