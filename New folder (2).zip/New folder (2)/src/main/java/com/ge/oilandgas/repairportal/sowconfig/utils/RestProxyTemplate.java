package com.ge.oilandgas.repairportal.sowconfig.utils;

import org.apache.http.HttpHost;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public final class RestProxyTemplate {

	@Value("${spring.profiles.active}")
	private String profile;

	public RestTemplate getRestTemplate() {

		HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
		if(profile.equalsIgnoreCase("local"))
		{
			HttpHost myProxy = new HttpHost("http-proxy.em.health.ge.com", 88);
			HttpClientBuilder clientBuilder = HttpClientBuilder.create();
			clientBuilder.setProxy(myProxy);
			HttpClient httpClient = clientBuilder.build();
			factory.setHttpClient(httpClient);

		}else
		{
			HttpClientBuilder clientBuilder = HttpClientBuilder.create();
			HttpClient httpClient = clientBuilder.build();
			factory.setHttpClient(httpClient);

		}
		RestTemplate restTemplate = new RestTemplate(factory);
		return restTemplate;
	}
}