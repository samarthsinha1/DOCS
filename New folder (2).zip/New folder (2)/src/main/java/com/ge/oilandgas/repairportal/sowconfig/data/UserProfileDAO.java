package com.ge.oilandgas.repairportal.sowconfig.data;

import java.util.List;

import com.ge.oilandgas.repairportal.sowconfig.bo.UserProfilesDto;
import com.ge.oilandgas.repairportal.sowconfig.bo.UserSubRoleDto;

public interface UserProfileDAO {
	public List<UserProfilesDto> getUserInfo(Integer sso);
	public List<UserSubRoleDto> getUserSubRole(Integer sso);
}
