package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.oilandgas.repairportal.sowconfig.data.CommercialViewDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.CommercialViewRepository;
import com.ge.oilandgas.repairportal.sowconfig.entity.CommercialView;

@Component
public class CommercialViewDAOImpl extends GenericCrudDAOImpl<CommercialView, Long> implements CommercialViewDAO {
	
	@Autowired
	private CommercialViewRepository commercialViewRepository;
	
	  public CommercialViewDAOImpl(CommercialViewRepository commercialViewRepository) {
	        this.commercialViewRepository = commercialViewRepository;
	    }
	  
	  public CommercialViewDAOImpl() {
		super();
	}

	  @SuppressWarnings("unchecked")
	 public CommercialViewRepository getRepository() {
        return commercialViewRepository;
    }

	@Override
	public List<CommercialView> findCommercialViewByEngineInfoId(Long engineInfoId) {
		
		return commercialViewRepository.findCommercialViewByEngineInfoId(engineInfoId);
	}
	
	public CommercialView update(CommercialView entity) {
		return super.update(entity);
	}
	
}
