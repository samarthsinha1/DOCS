/*
 * Copyright (c) 2014 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */
package com.ge.oilandgas.repairportal.sowconfig.entity;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by 212433176 on 10/18/14.
 */
@MappedSuperclass
public abstract class GenericEntity<ID extends Serializable> implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final Integer DEFAULT_SYSTEM_USER = 0;

    @Column(name = "CREATION_DATE", insertable = false, updatable = false)
    @Temporal(TemporalType.DATE)
    protected Date creationDate;

  
    @Column(name = "CREATED_BY")
    protected Integer createdBy = DEFAULT_SYSTEM_USER;

    @Column(name = "lAST_UPDATE_DATE", insertable = false, updatable = true)
    @Temporal(TemporalType.DATE)
    protected Date lastUpdateDate;

    public Date getLastUpdateDate() {
		return lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}

	@Column(name = "LAST_UPDATED_BY")
    protected Integer lastUpdatedBy= DEFAULT_SYSTEM_USER;

    public abstract ID getId();

    public Integer getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(Integer lastUpdatedBy) {
		if(lastUpdatedBy!=null){
			this.lastUpdatedBy = lastUpdatedBy;
		}
	}

	public abstract void setId(ID id);

    public Date getCreatedDate() {
        return creationDate;
    }

    public Integer getCreatedBy() {
        return createdBy;
    }

    public Date getModifiedDate() {
        return lastUpdateDate;
    }


    public void setCreatedBy(Integer createdBy){
        if (createdBy != null) {
            this.createdBy = createdBy;
        }
    }
    
    public void setCreatedDate(Date createdDate){
    	this.creationDate = createdDate;
    			
    }
    
    
    public void setModifiedDate(Date modifiedDate){
        if (modifiedDate != null) {
            this.lastUpdateDate = modifiedDate;
        }
    }
    
    @Override
    public String toString() {
        return "GenericEntity{" +
                "createdDate=" + creationDate +
                ", createdBy='" + createdBy + '\'' +
                ", modifiedDate=" + lastUpdateDate +
                ", modifiedBy='" + lastUpdatedBy + '\'' +
                '}';
    }
}
