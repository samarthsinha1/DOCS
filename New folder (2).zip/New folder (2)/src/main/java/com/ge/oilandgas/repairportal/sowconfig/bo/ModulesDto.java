package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ModulesDto extends AuditDataDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private Long modelEngineId;
	private String engine;
	private String module;
	private String moduleChecked="false";
	private String additionalComment;
	
	private List<ModuleOperationsDto> moduleOperationsList= new LinkedList<>();
	
	private List<ModuleMaterialsDto> moduleMaterialsList = new LinkedList<>();
	
	private List<ModuleMaterialRepairDto> moduleMaterialsRepairList = new LinkedList<>();
	
	private List<ModuleOperationListDto> moduleNonStdOperationsList = new LinkedList<>();
	
	private List<ModuleOperationListDto> moduleOperationOptions = new LinkedList<>();
	
	public List<ModuleMaterialRepairDto> getModuleMaterialsRepairList() {
		return moduleMaterialsRepairList;
	}
	public void setModuleMaterialsRepairList(List<ModuleMaterialRepairDto> moduleMaterialsRepairList) {
		this.moduleMaterialsRepairList = moduleMaterialsRepairList;
	}
	public List<ModuleMaterialsDto> getModuleMaterialsList() {
		return moduleMaterialsList;
	}
	public void setModuleMaterialsList(List<ModuleMaterialsDto> moduleMaterialsList) {
		this.moduleMaterialsList = moduleMaterialsList;
	}
	public List<ModuleOperationsDto> getModuleOperationsList() {
		return moduleOperationsList;
	}
	public void setModuleOperationsList(List<ModuleOperationsDto> moduleOperationsList) {
		this.moduleOperationsList = moduleOperationsList;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getModelEngineId() {
		return modelEngineId;
	}
	public void setModelEngineId(Long modelEngineId) {
		this.modelEngineId = modelEngineId;
	}
	public String getEngine() {
		return engine;
	}
	public void setEngine(String engine) {
		this.engine = engine;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getModuleChecked() {
		return moduleChecked;
	}
	public void setModuleChecked(String moduleChecked) {
		this.moduleChecked = moduleChecked;
	}
	
	public String getAdditionalComment() {
		return additionalComment;
	}
	public void setAdditionalComment(String additionalComment) {
		this.additionalComment = additionalComment;
	}
	
	public List<ModuleOperationListDto> getModuleOperationOptions() {
		return moduleOperationOptions;
	}
	public void setModuleOperationOptions(List<ModuleOperationListDto> moduleOperationOptions) {
		this.moduleOperationOptions = moduleOperationOptions;
	}
	@Override
	public String toString() {
		return "ModulesDto [id=" + id + ", modelEngineId=" + modelEngineId + ", engine=" + engine + ", module=" + module
				+ ", moduleChecked=" + moduleChecked + ", additionalComment=" + additionalComment
				+ ", moduleOperationsList=" + moduleOperationsList + ", moduleMaterialsList=" + moduleMaterialsList
				+ ", moduleMaterialsRepairList=" + moduleMaterialsRepairList + "]";
	}
	public List<ModuleOperationListDto> getModuleNonStdOperationsList() {
		return moduleNonStdOperationsList;
	}
	public void setModuleNonStdOperationsList(List<ModuleOperationListDto> moduleNonStdOperationsList) {
		this.moduleNonStdOperationsList = moduleNonStdOperationsList;
	}
	
}
