package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.ge.oilandgas.repairportal.sowconfig.data.SbNewMaterialsDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.SbNewMaterialsRepository;

@Component
public class SbNewMaterialsDAOImpl implements SbNewMaterialsDAO{

	private static final Logger logger = LoggerFactory.getLogger(SbNewMaterialsDAOImpl.class);
	
	@Autowired
	private SbNewMaterialsRepository sbNewMaterialsRepository;
	
	public SbNewMaterialsDAOImpl(SbNewMaterialsRepository sbNewMaterialsRepository){
		this.sbNewMaterialsRepository=sbNewMaterialsRepository;
	}
	
	public SbNewMaterialsDAOImpl(){
		super();
	}
	
	public SbNewMaterialsRepository getRepository(){
		return sbNewMaterialsRepository;
		
	}
	
}
