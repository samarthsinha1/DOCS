package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

public class ProductLovDto implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5707967424918236360L;
	private Long id;
	private String plcProductType;
	private String product;
	private String prefixCounter;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getPlcProductType() {
		return plcProductType;
	}
	public void setPlcProductType(String plcProductType) {
		this.plcProductType = plcProductType;
	}
	public String getProduct() {
		return product;
	}
	public void setProduct(String product) {
		this.product = product;
	}
	public String getPrefixCounter() {
		return prefixCounter;
	}
	public void setPrefixCounter(String prefixCounter) {
		this.prefixCounter = prefixCounter;
	}
	
	
}
