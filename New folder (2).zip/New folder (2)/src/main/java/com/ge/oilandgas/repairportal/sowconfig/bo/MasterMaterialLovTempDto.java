package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;

public class MasterMaterialLovTempDto extends AuditDataDto implements Serializable{
	
	private static final long serialVersionUID = 1927186963693727192L;

	private Long id;
	
	private String source;
	
	private String product;
	
	private String model;
	
	private String document;
	
	private Long change;
	
	private String engine;
	
	private String module; 
	
	private String moduleName;
	
	private Long pagina;
	
	private String sowIndex;
	
	private String partNumber;
	
	private String nomenclature;
	
	private String status;
	
	private Long bomQty;
	
	private String displayInSowMaterialSection;
	
	private String displayInSowMaterialAs;
	
	private String priceCategory; 
	
	private String newRepair;
	
	private String serviceRendered;
	
	private Float fallOut;
	
	private String priceFamily;
	
	private String docName;
	
	private String supplierType;
	
	private String supplier;
	
	private float unitCost;
	
	private float unitPrice;
	
	private String materialDeleted;
	  
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getDocument() {
		return document;
	}

	public void setDocument(String document) {
		this.document = document;
	}

	public Long getChange() {
		return change;
	}

	public void setChange(Long change) {
		this.change = change;
	}

	public String getEngine() {
		return engine;
	}

	public void setEngine(String engine) {
		this.engine = engine;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public Long getPagina() {
		return pagina;
	}

	public void setPagina(Long pagina) {
		this.pagina = pagina;
	}

    

	public String getSowIndex() {
		return sowIndex;
	}

	public void setSowIndex(String sowIndex) {
		this.sowIndex = sowIndex;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getNomenclature() {
		return nomenclature;
	}

	public void setNomenclature(String nomenclature) {
		this.nomenclature = nomenclature;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getBomQty() {
		return bomQty;
	}

	public void setBomQty(Long bomQty) {
		this.bomQty = bomQty;
	}

	public String getDisplayInSowMaterialSection() {
		return displayInSowMaterialSection;
	}

	public void setDisplayInSowMaterialSection(String displayInSowMaterialSection) {
		this.displayInSowMaterialSection = displayInSowMaterialSection;
	}

	public String getDisplayInSowMaterialAs() {
		return displayInSowMaterialAs;
	}

	public void setDisplayInSowMaterialAs(String displayInSowMaterialAs) {
		this.displayInSowMaterialAs = displayInSowMaterialAs;
	}

	public String getPriceCategory() {
		return priceCategory;
	}

	public void setPriceCategory(String priceCategory) {
		this.priceCategory = priceCategory;
	}

	public String getNewRepair() {
		return newRepair;
	}

	public void setNewRepair(String newRepair) {
		this.newRepair = newRepair;
	}

	public String getServiceRendered() {
		return serviceRendered;
	}

	public void setServiceRendered(String serviceRendered) {
		this.serviceRendered = serviceRendered;
	}

	public Float getFallOut() {
		return fallOut;
	}

	public void setFallOut(Float fallOut) {
		this.fallOut = fallOut;
	}

	public String getPriceFamily() {
		return priceFamily;
	}

	public void setPriceFamily(String priceFamily) {
		this.priceFamily = priceFamily;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public String getSupplierType() {
		return supplierType;
	}

	public void setSupplierType(String supplierType) {
		this.supplierType = supplierType;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public float getUnitCost() {
		return unitCost;
	}

	public void setUnitCost(float unitCost) {
		this.unitCost = unitCost;
	}

	public float getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(float unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getMaterialDeleted() {
		return materialDeleted;
	}

	public void setMaterialDeleted(String materialDeleted) {
		this.materialDeleted = materialDeleted;
	}
	
		
}
