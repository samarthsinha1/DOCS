package com.ge.oilandgas.repairportal.sowconfig.data.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.oilandgas.repairportal.sowconfig.data.ReportFieldsDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.ServiceBulletinsDAO;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.GenericCrudRepository;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.ReportFieldsRepository;
import com.ge.oilandgas.repairportal.sowconfig.data.repository.ServiceBulletinsRepository;
import com.ge.oilandgas.repairportal.sowconfig.entity.ReportFields;
import com.ge.oilandgas.repairportal.sowconfig.entity.ServiceBulletins;

@Component
public class ServiceBulletinsDAOImpl extends GenericCrudDAOImpl<ServiceBulletins, Long> implements ServiceBulletinsDAO{

	@Autowired
	private ServiceBulletinsRepository serviceBulletinsRepository;
	
	  public ServiceBulletinsDAOImpl(ServiceBulletinsRepository serviceBulletinsRepository) {
	        this.serviceBulletinsRepository = serviceBulletinsRepository;
	    }
	  
	  public ServiceBulletinsDAOImpl() {
		super();
	}

	 @SuppressWarnings("unchecked")
	 public ServiceBulletinsRepository getRepository() {
        return serviceBulletinsRepository;
    }

	@Override
	public List<ServiceBulletins> findServiceBulletinsById(Long id) {
		return serviceBulletinsRepository.findServiceBulletinsById(id);
	}

}
