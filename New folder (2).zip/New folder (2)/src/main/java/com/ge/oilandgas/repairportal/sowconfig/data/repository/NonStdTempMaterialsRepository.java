package com.ge.oilandgas.repairportal.sowconfig.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ge.oilandgas.repairportal.sowconfig.entity.MasterMaterialLovTemp;

@Repository
public interface NonStdTempMaterialsRepository extends GenericCrudRepository<MasterMaterialLovTemp, Long> {

	@Query("SELECT s FROM MasterMaterialLovTemp s where s.docName = ?1")
	List<MasterMaterialLovTemp> getAllUserCreatedMaterials(String docName);
	
	@Query("SELECT s FROM MasterMaterialLovTemp s where s.docName = ?1 and s.engine = ?2 and s.module is null")
	List<MasterMaterialLovTemp> getAllUserCreatedEngineMaterials(String docName, String engine);
	
	@Query("SELECT s FROM MasterMaterialLovTemp s where s.docName = ?1 and s.engine = ?2 and s.module = ?3")
	List<MasterMaterialLovTemp> getAllUserCreatedModuleMaterials(String docName, String engine,	String module);

}
