package com.ge.oilandgas.repairportal.sowconfig.bo;

import java.io.Serializable;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ServiceBulletinsDto extends AuditDataDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	private Long infoSequenceId;
	private Date sbImplementationDate;
	private String sbDescription;
	private float price;
	private String serviceBulletinChecked;
	private float cost;
	private float baseQuotePrice;
	private String category;
	private String newSBFlag;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	public Long getInfoSequenceId() {
		return infoSequenceId;
	}
	public void setInfoSequenceId(Long infoSequenceId) {
		this.infoSequenceId = infoSequenceId;
	}
	public Date getSbImplementationDate() {
		return sbImplementationDate;
	}
	public void setSbImplementationDate(Date sbImplementationDate) {
		this.sbImplementationDate = sbImplementationDate;
	}
	public String getSbDescription() {
		return sbDescription;
	}
	public void setSbDescription(String sbDescription) {
		this.sbDescription = sbDescription;
	}
	
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getServiceBulletinChecked() {
		return serviceBulletinChecked;
	}
	public void setServiceBulletinChecked(String serviceBulletinChecked) {
		this.serviceBulletinChecked = serviceBulletinChecked;
	}
	public float getCost() {
		return cost;
	}
	public void setCost(float cost) {
		this.cost = cost;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	public float getBaseQuotePrice() {
		return baseQuotePrice;
	}
	public void setBaseQuotePrice(float baseQuotePrice) {
		this.baseQuotePrice = baseQuotePrice;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	public String getNewSBFlag() {
		return newSBFlag;
	}
	public void setNewSBFlag(String newSBFlag) {
		this.newSBFlag = newSBFlag;
	}
	
	@Override
	public String toString() {
		return "ServiceBulletinsDto [id=" + id + ", infoSequenceId=" + infoSequenceId + ", sbImplementationDate="
				+ sbImplementationDate + ", sbDescription=" + sbDescription + ", price=" + price
				+ ", serviceBulletinChecked=" + serviceBulletinChecked + ", cost=" + cost + ", baseQuotePrice="
				+ baseQuotePrice + ", category=" + category + ", newSBFlag=" + newSBFlag + "]";
	}
	
}
