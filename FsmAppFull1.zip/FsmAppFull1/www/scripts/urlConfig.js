angular.module('hackathonApp').controller('urlconfigCtrlr', function($scope,$state,$http,$localstorage){
  document.getElementById("showSubmitMsg").style.display="none"
  $scope.initialize = function(){
    $scope.height=$(window).height()-55;
    $('.sub-view-section').slimScroll({ 
        size : '8px',
        distance: '3px', 
        height: $scope.height+'px',
        railVisible: true,
        railDraggable: true,
			  alwaysVisible: true
    });
    $('.loader').addClass('dispNone');
    var manualState=JSON.parse($localstorage.get('manual','false'));
    var backupState=JSON.parse($localstorage.get('backup','false'));
    $("[name='manual-override']").bootstrapSwitch('state',manualState, true);
    $("[name='manual-backup']").bootstrapSwitch('state',backupState,true);
    $('#backup').addClass('dispNone');
    if($("[name='manual-override']").is(':checked')){
      $('#backup').removeClass('dispNone');
    }
    $('.view-section,.dashboard').css('width','100%');
  };
  
console.log("in urlconfig")


  $(document).on('click',"#saveUrls",function (event) {
      var ip=$("#exampleInputIP").val();
      var url=$("#exampleInputURL").val();
      console.log("ip",ip)
      console.log("exampleInputURL",url)
      $localstorage.setObject('url',url)
      $localstorage.setObject('ip',ip)
      localStorage.setItem('url',url)
      localStorage.setItem('ip',ip)
      document.getElementById("showSubmitMsg").style.display="block"
  })

  
});