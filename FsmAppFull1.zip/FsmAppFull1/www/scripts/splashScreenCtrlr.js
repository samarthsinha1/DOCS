angular.module('hackathonApp').controller('splashScreenCtrlr', function($scope,$state,$http,$localstorage){
  
  $scope.initialize = function(){
    $scope.height=$(window).height()-55;
    $('.splashBg').css('height',$scope.height+'px');
    $('.loader').addClass('dispNone');
    $('.splashBg').css('width','100%');
  };
  
  $("div.animateloader").animate({width: '100%'}, 3500, function(){
      $state.go('dashboard');
    });
});