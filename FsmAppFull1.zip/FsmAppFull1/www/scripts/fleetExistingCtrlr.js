angular.module('fpmApp').controller('fleetExistingCtrlr', function($scope,$state){
  
  function initialize(){
    $scope.height=$(window).height()-55;
    $('.sub-view-section').slimScroll({ 
        size : '8px',
        distance: '3px', 
        height: $scope.height+'px',
        railVisible: true,
        railDraggable: true,
			  alwaysVisible: true
    });
    $('.navigation').removeClass('dispNone');
    $('.navigation li').removeClass('active-reference').removeClass('activated');
    $('.navigation li:eq(1)').addClass('active-reference').addClass('activated');
    $scope.defaultColumnSettings=[{"colIndex":2,"visible":false},{"colIndex":3,"visible":false},{"colIndex":4,"visible":true},{"colIndex":5,"visible":true},{"colIndex":6,"visible":true},{"colIndex":7,"visible":false}];
		$scope.columnStyles=[{"colIndex":1,"colClass":"text-center"},{"colIndex":2,"colClass":"ellipsis"},{"colIndex":3,"colClass":"ellipsis"},{"colIndex":4,"colClass":"ellipsis"},{"colIndex":5,"colClass":"text-center"},{"colIndex":6,"colClass":"text-center"},{"colIndex":7,"colClass":"text-center"}];
  }
  
  initialize();
  
  $scope.fetchUniqueValues = function(json,param){
  	var uniqueNames = [];
  	for(var i = 0; i< json.length; i++){    
  		if(uniqueNames.indexOf(json[i][param]) === -1){
  			uniqueNames.push(json[i][param]);        
  		}        
  	}
  	return uniqueNames;
  };
      
  $scope.filterJSON = function(json, key, value){
  	return json.filter(function(jsonObj){ 
  		return jsonObj[key] == value;
  		});
  };
      
  $scope.setTableScrolling = function(tableSection, height){
    $('#'+tableSection+' .dataTables_scrollBody').slimScroll({ 
      size : '8px',
      distance: '5px',
      height: height,
      railDraggable: true,
      alwaysVisible: true
    });
  };
  
  $scope.adjustTableColumns = function(tableSection, isNonBlank){
    $('#'+tableSection+' .no-data-section').removeClass('dispNone');
	  $('#'+tableSection+' .datatable-options .datatable-page-length').addClass('dispNone');
	  $('#'+tableSection+' .hideable-button').addClass('dispNone');
	  $('#'+tableSection+' .data-section').addClass('dispNone');
	  $('#'+tableSection+' .clear-btn').prop('disabled', true);
    if(isNonBlank){
      $('#'+tableSection+' .no-data-section').addClass('dispNone');
  	  $('#'+tableSection+' .datatable-options .datatable-page-length').removeClass('dispNone');
  	  $('#'+tableSection+' .hideable-button').removeClass('dispNone');
  	  $('#'+tableSection+' .data-section').removeClass('dispNone');
  	  $('#'+tableSection+' .clear-btn').prop('disabled', false);
    }
	  $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
  };
  
  $scope.toggleColumnVisiblity= function(tableSection){
    var tableId=$('#'+tableSection).find('.datatable-body:eq(1)').attr('id');
    $.each($scope.defaultColumnSettings, function(index){
      $('#'+tableSection+' .multiselect input[data-column="'+this.colIndex+'"]').prop('checked',this.visible).trigger('change');
    });
  };
  
  $scope.setColumnVisiblity= function(tableSection){
    var columns=[];
    $.each($('#'+tableSection+' .mutliSelect input'), function(index){
      columns.push({'colIndex':Number($(this).attr('data-column')),'visible':$(this).is(':checked')});
    });
    //$localstorage.setObject('columnVisibilty',columns);
  };
  
  $scope.setColumnStyles = function(tableSection){
    var tableId=$('#'+tableSection).find('.datatable-body:eq(1)').attr('id');
    $.each($scope.columnStyles, function(index){
      var colIndex=this.colIndex;
      var colClass=this.colClass;
      $.each($('#'+tableId).DataTable().column(colIndex).nodes(), function(index){
        $(this).attr('title',$(this).text());
        $(this).addClass(colClass);
      });
    });
  };
  
  $scope.initializeDataTable = function(table, settings){
    var tableSection=$(table).parents('.datatable-block').attr('id');
    var columnDefs=[{'targets': 0,'orderable':false}];
    if(settings.checkBoxes){
      columnDefs=[{'targets': 0,
                     'checkboxes': {'selectRow': true,'selectAllPages':false}
                   }];
      if(settings.isSingleSelect){
      
      }
    }
    
    if($.fn.DataTable.isDataTable($(table))){
      $(table).DataTable().column(0).checkboxes.deselect();
      $(table).dataTable().fnClearTable();
      if(settings.checkBoxes){
        $('#'+tableSection+' .datatable-filter th:eq(0)').html('(0)');
      }
      $('#'+tableSection+' .action-btn').prop('disabled', true);
      $(table).dataTable().fnAddData(settings.data);
    }else{
      $(table).dataTable({
        'data': settings.data,
        'bLengthChange':false,
        "iDisplayLength": settings.pageLength,
        'responsive':true,
        "scrollY": settings.scrollHeight,
        'columnDefs': columnDefs,
        'select': {
          'style': settings.isSingleSelect?'multi':'single'
        },
        order:[],
        columns: [
            { "data": settings.checkBoxes?"serial":"ID" },
            { "data": "ID" },
            { "data": "region" },
            { "data": "siteName" },
            { "data": "customerName"},                    
            { "data": "frame" },
            { "data": "tech" },
            { "data": "serial" }
        ]
      });
    }
    $scope.setTableScrolling(tableSection, settings.scrollHeight);
    $scope.adjustTableColumns(tableSection, true);
    $scope.setColumnStyles(tableSection);
    $scope.toggleColumnVisiblity(tableSection);
  };
  
  $scope.getFleetExistingData = function(){
    $.ajax({ 
  		type : "GET",
  		url: "data/fleet_data.json",
  		contentType: "application/json; charset=utf-8",
  		dataType : "json", 
  		success : function(response){
			  if(response.length!==0){
			    $.each(response, function(index){
	          this.ID=index+1;
	        });
			    $scope.searchResults=response;
			    var settings={
			      "scrollHeight":"355px",
			      "checkBoxes": true,
			      "isSingleSelect": false,
			      "pageLength":25,
			      "data": $scope.searchResults
			    };
			    $scope.initializeDataTable($("#result-table"), settings);
			  } 
  		},
  		error : function(exception){
  			alert('Error Occurred, Please try again by reloading page.');
  		}
	  });
  };
  
  $scope.getFleetPerformanceData = function(){
    $.ajax({ 
  		type : "GET",
  		url: "data/fleetperfData.json",
  		contentType: "application/json; charset=utf-8",
  		dataType : "json", 
  		success : function(response){
			  if(response.length!==0){
			    var uniqueSerials=$scope.fetchUniqueValues(response.period1,'serial');
			    $scope.perfData=[];
			    $.each(uniqueSerials, function(index){
			      var deltaObj=$scope.filterJSON(response.period1,'serial', this)[0];
			      $scope.perfData.push({
			        'serial': deltaObj.serial,
			        'frame': deltaObj.frame,
			        'tech': deltaObj.tech,
			        'deltaPwr': Number(deltaObj.deltaPwr),
			        'deltaHR': Number(deltaObj.deltaHR),
			        'deltaCapFactPerc': Number(deltaObj.deltaCapFactPerc),
			        'deltaLoadFactPerc': Number(deltaObj.deltaLoadFactPerc),
			        'deltaFiredHours': Number(deltaObj.deltaFiredHours),
			        'deltaBlHours': Number(deltaObj.deltaBlHours)
			      });
			    });
			    $scope.toggleChartVisibilty(true);
			    $scope.getScatterPoints();
			    $scope.getPlotPoints();
			    $('#graph-section .thubmail-tooltip:eq(0)').trigger('click');
			  } 
  		},
  		error : function(exception){
  			alert('Error Occurred, Please try again by reloading page.');
  		}
	  });
  };
  
  $scope.toggleChartVisibilty = function(isNonBlank){
    $('#graph-section .no-data-section').removeClass('dispNone');
    $('#graph-section .data-section').addClass('dispNone');
    if(isNonBlank){
      $('#graph-section .no-data-section').addClass('dispNone');
      $('#graph-section .data-section').removeClass('dispNone');
    }
  };
  
  $scope.getScatterPoints = function(){
    $scope.scatterXKey=$('#scatter-graph-container #x-axis').val();
    $scope.scatterYKey=$('#scatter-graph-container #y-axis').val();
    $scope.scatterXLabel=$('#scatter-graph-container #x-axis option:selected').text();
    $scope.scatterYLabel=$('#scatter-graph-container #y-axis option:selected').text();
    var scatterPoints={"Assets":[],"HighLights":[]};
    var isIDVisible=!$scope.filterJSON($scope.defaultColumnSettings,'colIndex',7)[0].visible;
    $.each($scope.perfData, function(index){
      var xPoint=this[$scope.scatterXKey];
      var yPoint=this[$scope.scatterYKey];
      if(xPoint!="Infinity" && yPoint!="Infinity"  && xPoint!="NaN"  && yPoint!="NaN"){
        xPoint=Number(Number(xPoint).toFixed(3))||0;
        yPoint=Number(Number(yPoint).toFixed(3))||0;
        var serial=isIDVisible?$scope.filterJSON($scope.selectedData,'serial', this.serial)[0].ID: this.serial;
        if($scope.highlightSerials.indexOf(this.serial)!==-1){
          scatterPoints["HighLights"].push({"x":xPoint,"y":yPoint,"serial":serial});
        }else{
          scatterPoints["Assets"].push({"x":xPoint,"y":yPoint,"serial":serial});
        }
      }
    });
    $scope.scatterPoints=scatterPoints;
    $scope.renderScatterGraph();
    $('.sub-view-section').slimScroll({scrollTo: '520px'});
  };
  
  $scope.getPlotPoints = function(){
    $scope.colors=['purple','green','crimson','#5F83FF','orange'];
    $scope.plotXKey=$('#plot-graph-container #x-axis').val();
    $scope.plotXLabel=$('#plot-graph-container #x-axis option:selected').text();
    $scope.deltaCategories=[null];
    $scope.deltaPlotLines=[];
    var plotPoints={"HighLights":[],"Assets":[]};
    var uniqueTech=$scope.fetchUniqueValues($scope.perfData,'tech');
    var isIDVisible=!$scope.filterJSON($scope.defaultColumnSettings,'colIndex',7)[0].visible;
    $.each(uniqueTech, function(index){
  	  $scope.deltaCategories.push(uniqueTech[index]);
  	  $scope.deltaPlotLines.push({color: $scope.colors[index],width: 1.5,value: index+1});
  	});
  	$.each($scope.perfData, function(index){
      var yPoint=this[$scope.plotXKey];
      var xPoint=uniqueTech.indexOf(this.tech)+0.12;
      if(yPoint!="Infinity" && yPoint!="NaN"){
        yPoint=Number(Number(yPoint).toFixed(3))||0;
        var serial=isIDVisible?$scope.filterJSON($scope.selectedData,'serial', this.serial)[0].ID: this.serial;
        if($scope.highlightSerials.indexOf(this.serial)!==-1){
          plotPoints["HighLights"].push({"x":xPoint,"y":yPoint,"serial":serial,"tech":this.tech});
        }else{
          plotPoints["Assets"].push({"x":xPoint,"y":yPoint,"serial":serial,"tech":this.tech});
        }
      }
    });
    $scope.plotPoints=plotPoints;
    $scope.renderPlotGraph();
    $('.sub-view-section').slimScroll({scrollTo: '520px'});
  };
  
  $scope.renderScatterGraph = function(){
    var graphWidth=$('.graph-container .graph:visible').width();
    var graphObject={};
    var chart={
      renderTo: 'scatter-graph',
      height: 400,
      width: graphWidth,
      type: 'scatter',
      zoomType: 'x',
      panning: true,
      panKey: 'shift',
      backgroundColor:"transparent",
      style: {fontFamily: "GE_Inspira"}
    };
    var title= {text: $scope.scatterXLabel+' vs '+$scope.scatterYLabel,
      y: 20,
      style: {
        color: '#3693f8',
        fontWeight: 'bold',
        fontSize: '14px'
      }
    };
    var xAxis= {
      title: {
        enabled: true,
        text: $scope.scatterXLabel+ '(%)',
        style: {
          color: '#FFFFFF',
          fontWeight: 'bold'
        }
      },
      gridLineWidth: 0.5,
      labels: {
        style: {
          color: '#FFFFFF'
        },
        formatter: function () {
            return  this.axis.defaultLabelFormatter.call(this)+''+'%';
        }            
      },
      lineWidth:1,
      showLastLabel: true,
      plotLines: [{
        color: 'white',
        dashStyle: 'ShortDash',
        width: 1,
        value: 0
      }]
    };
    var yAxis= {
      title: {
        text: $scope.scatterYLabel+ '(%)',
        style: {
          color: '#FFFFFF',
          fontWeight: 'bold'
        }
      },
      gridLineWidth: 0.5,
      lineWidth:1,
      labels: {
        style: {
          color: '#FFFFFF'
        },
        formatter: function () {
            return  this.axis.defaultLabelFormatter.call(this)+''+'%';
        }            
      },
      plotLines: [{
        color: 'white',
        dashStyle: 'ShortDash',
        width: 1,
        value: 0
      }]
    };
    var plotOptions= {
      scatter: {
        marker: {
          radius: 5,
          states: {
            hover: {
                enabled: true
            }
          }
        }
      }
    };
    var legend={
    	itemStyle: {
        color: '#ffffff',
      },
      itemHoverStyle: {
        color: '#ffffff',
      },
    	layout: 'horizontal',
    	verticalAlign: 'top',
    	align:'right',
    	x: -50
    };
    var series= [
      {
        name: 'Assets',
        data: $scope.scatterPoints["Assets"],
        marker: {
        	enabled: true,
        	symbol: 'circle',
        	radius: 5,
        	fillColor:'rgba(144, 237, 125, .8)'
        }
      },
      {
        name: 'HighLight',
        data: $scope.scatterPoints["HighLights"],
        marker: {
        	enabled: true,
        	symbol: 'circle',
        	radius: 7,
        	fillColor:'rgba(54,148,247, .8)'
        }
      }
    ];
    var tooltip= {
      formatter: function () {
        return '<b>Serial: </b>' + this.point.serial + 
               '<br/><b>'+$scope.scatterXLabel+': </b>'+this.point.x+
               ' %<br/><b>'+$scope.scatterYLabel+': </b>'
               + this.point.y+' %';
      }
    };
    var credits= {enabled: false};
    var exporting= {
      chartOptions: {
        plotOptions: {
          series: {
            dataLabels: {
              enabled: true
            }
          }
        }
      },
      scale: 1.5,
      fallbackToExportServer: false
    };
    
    graphObject.chart=chart;
    graphObject.title=title;
    graphObject.xAxis=xAxis;
    graphObject.yAxis=yAxis;
    graphObject.legend=legend;
    graphObject.series=series;
    graphObject.tooltip=tooltip;
    graphObject.credits=credits;
    graphObject.exporting=exporting;
    var chartData = new Highcharts.Chart(graphObject);
  };
  
  $scope.renderPlotGraph = function(){
    var graphWidth=$('.graph-container .graph:visible').width();
    var graphObject={};
    var chart={
      renderTo: 'plot-graph',
      height: 400,
      width: graphWidth,
      type: 'scatter',
      inverted: true,
      zoomType: 'y',
      panning: true,
      panKey: 'shift',
      backgroundColor:"transparent",
      style: {fontFamily: "GE_Inspira"}
    };
    var title= {text: $scope.plotXLabel,
      y: 20,
      style: {
        color: '#3693f8',
        fontWeight: 'bold',
        fontSize: '14px'
      }
    };
    var xAxis= {
    	title: {
    		text: "Tech Type",
    		style: {
          color: '#FFFFFF',
          fontWeight: 'bold'
        }
    	},
    	lineWidth: 1,
      lineColor: 'white',
			gridLineWidth: 0,
			endOnTick: true,
			categories: $scope.deltaCategories,
			plotLines: $scope.deltaPlotLines,
			labels: {
			  style: {
          color: '#FFFFFF'
        },
				enabled:true
			}
		};
		var yAxis= {
		  title: {
        text: $scope.plotXLabel+' (%)',
        style: {
          color: '#FFFFFF',
          fontWeight: 'bold'
        }
		  },
      lineWidth: 1,
      lineColor: 'grey',
      gridLineWidth: 0,
      labels: {
        style: {
          color: '#FFFFFF'
        },
        formatter: function () {
            return  this.axis.defaultLabelFormatter.call(this)+''+'%';
        }            
      }
		};
		var legend={
    	itemStyle: {
        color: '#ffffff',
      },
      itemHoverStyle: {
        color: '#ffffff',
      },
    	layout: 'horizontal',
    	verticalAlign: 'top',
    	align:'right',
    	x: -50
    };
		var series= [
      {
        name: "Assets",
        data: $scope.plotPoints["Assets"],
        marker: {
        	enabled: true,
        	symbol: 'triangle',
        	radius: 5,
        	fillColor:'#FFC151'
        }
      },
      {
        name: "HighLights",
        data: $scope.plotPoints["HighLights"],
        marker: {
        	enabled: true,
        	symbol: 'triangle',
        	radius: 8,
        	fillColor:'#FF0000'
        }
      }
		];
		var tooltip= {
      formatter: function () {
        return '<b>Serial: </b>' + this.point.serial + '<br/><b>Tech: </b>'+this.point.tech+
               '<br/><b>'+$scope.plotXLabel+': </b>'+ this.point.y;
      }
		};
		var credits= {enabled: false};
		var exporting= {
      chartOptions: {
        plotOptions: {
          series: {
            dataLabels: {enabled: true}
          }
        }
      },
      scale: 1.5,
      fallbackToExportServer: false
    };
    graphObject.chart=chart;
    graphObject.title=title;
    graphObject.xAxis=xAxis;
    graphObject.yAxis=yAxis;
    graphObject.legend=legend;
    graphObject.series=series;
    graphObject.tooltip=tooltip;
    graphObject.credits=credits;
    graphObject.exporting=exporting;
    var chartData = new Highcharts.Chart(graphObject);
  };
			    
  /*document.querySelector('ge-dropdown').addEventListener('button-clicked', function (e) {
    $scope.getFleetExistingData();
  });*/
  
  $('#fleet-existing').on('calendar-apply-clicked','#date-range1', function(e){
    $scope.period1=e.originalEvent.detail;
    $scope.interval1=$scope.period1.duration.asDays();
    $('#search-button').prop('disabled',true).addClass('btn-disabled');
    if($scope.interval2){
      if($scope.interval2.toFixed(0)==$scope.interval1.toFixed(0)){
        $('#search-button').prop('disabled',false).removeClass('btn-disabled');
      }
    }
  });
  
  $('#fleet-existing').on('calendar-apply-clicked','#date-range2', function(e){
    $scope.period2=e.originalEvent.detail;
    $scope.interval2=$scope.period2.duration.asDays();
    $('#search-button').prop('disabled',true).addClass('btn-disabled');
    if($scope.interval1){
      if($scope.interval2.toFixed(0)==$scope.interval1.toFixed(0)){
        $('#search-button').prop('disabled',false).removeClass('btn-disabled');
      }
    }
  });
  
  $('#fleet-existing').on('click', '#search-button',function(){
    $scope.getFleetExistingData();
  });
  
  $('#fleet-existing').on('before-calendar-opened', 'polymer-date-rangepicker',function(){
    $('.date-range-container').addClass('dispNone');
  });
  
  $('#fleet-existing').on('calendar-cancel-clicked','#date-range1', function(e){
    $scope.period1=null;
    $scope.interval1=null;
    $('#search-button').prop('disabled',true).addClass('btn-disabled');
  });
  
  $('#fleet-existing').on('calendar-cancel-clicked','#date-range2', function(e){
    $scope.period2=null;
    $scope.interval2=null;
    $('#search-button').prop('disabled',true).addClass('btn-disabled');
  });
  
  $scope.toggleActionButtonStates = function(tableSection){
    var tableId=$('#'+tableSection).find('.datatable-body:eq(1)').attr('id');
    var count=$('#'+tableId).DataTable().rows('.selected').data().length;
    $('#'+tableSection+' .action-btn').prop('disabled', true);
    $('#'+tableSection+' .datatable-filter th:eq(0)').html('('+count+')');
    if(count>0){
      $('#'+tableSection+' .action-btn').prop('disabled', false);
    }
  };
  
  $("#result-table .datatable-filter th input").on( 'keyup change', function () {
    $("#result-table").DataTable()
        .column($(this).parent().attr('data-column'))
        .search( this.value )
        .draw();
  });
  
  $('#result-section').on('change','tbody input,thead input[type="checkbox"]', function(){
    var tableSection=$(this).parents('.datatable-block').attr('id');
    $scope.toggleActionButtonStates(tableSection);
  });
  
  $('#result-section').on('click','tbody tr', function(){
    var tableSection=$(this).parents('.datatable-block').attr('id');
    $scope.toggleActionButtonStates(tableSection);
  });
  
  
  $('#fleet-existing').on('change','#result-section .datatable-length', function(){
    var pageLength=Number($(this).val());
    if($.fn.DataTable.isDataTable($('#result-table'))){
      $('#result-table').DataTable().page.len(pageLength).draw();
    }
  });
  
  $('#fleet-existing').on('click', '.multiselect .hideable-button', function(){
    var checkboxes=$(this).parents('.multiselect').find('#checkboxes');
    if ($(checkboxes).hasClass('expanded')) {
      $(checkboxes).removeClass('expanded');
      $(checkboxes).slideToggle('fast');
    } else {
      $(checkboxes).addClass('expanded');
      $(checkboxes).slideToggle('fast');
    }
  });
  
  $('#fleet-existing').on('click','#result-section .action-btn', function(){
    $scope.selectedData=$('#result-table').DataTable().rows('.selected').data();
    var selectedData=[];
    $scope.selectedSerials=[];
    $.each($scope.selectedData, function(index){
      selectedData.push(this);
      $scope.selectedSerials.push(this.serial);
    });
    $scope.selectedData=selectedData;
    if($scope.selectedData.length!==0){
      var settings={
	      "scrollHeight":"90px",
	      "checkBoxes": true,
	      "isSingleSelect": false,
	      "data": $scope.selectedData
	    };
      $scope.initializeDataTable($('#asset-table'), settings);
    }else{
      var tableSection=$('#asset-table').parents('.datatable-block').attr('id');
      $scope.adjustTableColumns(tableSection,true);
    }
  });
  
  $('#fleet-existing').on('change','#asset-section .datatable-length', function(){
    var pageLength=Number($(this).val());
    if($.fn.DataTable.isDataTable($('#asset-table'))){
      $('#asset-table').DataTable().page.len(pageLength).draw();
    }
  });
  
  $("#asset-table .datatable-filter th input").on( 'keyup change', function () {
    $("#asset-table").DataTable()
        .column($(this).parent().attr('data-column'))
        .search( this.value )
        .draw();
  });
  
  $('#asset-section').on('change','tbody input,thead input[type="checkbox"]', function(){
    var tableSection=$(this).parents('.datatable-block').attr('id');
    $scope.toggleActionButtonStates(tableSection);
  });
  
  $('#asset-section').on('click','tbody tr', function(){
    var tableSection=$(this).parents('.datatable-block').attr('id');
    $scope.toggleActionButtonStates(tableSection);
  });
  
  $('#asset-section').on('click',' #baseline-block .clear-btn', function(){
    $('#asset-table').DataTable().column(0).checkboxes.deselect();
    $('#asset-table').dataTable().fnClearTable();
    $('#baseline-block .datatable-filter th:eq(0)').html('(0)');
    $('#baseline-block .action-btn').prop('disabled', true);
    $scope.adjustTableColumns('baseline-block', false);
  });
  
  $('#asset-section').on('click',' #highlight-block .clear-btn', function(){
    $('#highlight-table').DataTable().column(0).checkboxes.deselect();
    $('#highlight-table').dataTable().fnClearTable();
    $('#highlight-block .datatable-filter th:eq(0)').html('(0)');
    $('#highlight-block .action-btn').prop('disabled', true);
    $scope.adjustTableColumns('highlight-block', false);
  });
  
  $('.multiselect').on('change','#checkboxes input', function(){
    var tableSection=$(this).parents('.datatable-block').attr('id');
    var colIndex=Number($(this).attr('data-column'));
    var tableId=$('#'+tableSection).find('.datatable-body:eq(1)').attr('id');
    var column = $('#'+tableId).DataTable().column( $(this).attr('data-column') );
    if($(this).is(':checked')){
      $('#'+tableSection+' .datatable-filter th[data-column="'+colIndex+'"]').show();
      if(colIndex==7){
        $('#'+tableSection+' .datatable-filter th[data-column="1"]').hide();
        $('#'+tableId).DataTable().column(1).visible(false);
      }
    }else{
      $('#'+tableSection+' .datatable-filter th[data-column="'+colIndex+'"]').hide();
      if(colIndex==7){
        $('#'+tableSection+' .datatable-filter th[data-column="1"]').show();
        $('#'+tableId).DataTable().column(1).visible(true);
      }
    }
    column.visible($(this).is(':checked'));
  });
  
  $('#fleet-existing').on('click','#baseline-block .action-btn', function(){
    $scope.highlightData=$('#asset-table').DataTable().rows('.selected').data();
    var tableSection=$('#highlight-table').parents('.datatable-block').attr('id');
    var selectedData=[];
    $scope.highlightSerials=[];
    $.each($scope.highlightData, function(index){
      selectedData.push(this);
      $scope.highlightSerials.push(this.serial);
    });
    $scope.highlightData=selectedData;
    if($scope.highlightData.length!==0){
      var settings={
	      "scrollHeight":"90px",
	      "checkBoxes": false,
	      "isSingleSelect": false,
	      "data": $scope.highlightData
	    };
      $scope.initializeDataTable($('#highlight-table'), settings);
      $($('#highlight-table').DataTable().column(0).nodes()).html('');
      $('#'+tableSection).find('.action-btn').prop('disabled',false);
    }else{
      $('#'+tableSection).find('.action-btn').prop('disabled',true);
      $scope.adjustTableColumns(tableSection,true);
    }
  });
  
  $('#fleet-existing').on('click','#highlight-block .action-btn', function(){
    $scope.getFleetPerformanceData();
  });
  
  $('#scatter-graph-container').on('change','#x-axis, #y-axis', function(){
    var xAxisValue=$('#scatter-graph-container #x-axis').val();
    var yAxisValue=$('#scatter-graph-container #y-axis').val();
    $('#scatter-graph-container .graph-operations button').prop('disabled',false);
    if(xAxisValue===yAxisValue){
      $('#scatter-graph-container .graph-operations button').prop('disabled',true);
    }
  });
  
  $('#scatter-graph-container').on('click','.graph-operations button', function(){
    $scope.getScatterPoints();
  });
  
  $('#plot-graph-container').on('click','.graph-operations button', function(){
    $scope.getPlotPoints();
  });
  
  $('#graph-section').on('click','.thubmail-tooltip', function(){
    var graphId=$(this).find('img').attr('graph-attr');
    $('.graph-container').addClass('dispNone');
    $('#graph-section .thumnail-wrapper').removeClass('active-thumbnail');
    $(this).parents('.thumnail-wrapper').addClass('active-thumbnail');
    $('#'+graphId).removeClass('dispNone');
  });
});