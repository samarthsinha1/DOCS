angular.module('hackathonApp').controller('incidentDetailCtrlr', function($scope,$state,$http,$localstorage){
  $scope.resolveData=[];
    $scope.reasons = [];
    var urlLS = localStorage.getItem("url");
    var ipLS = localStorage.getItem("ip");
    console.log("url",urlLS,"ip",ipLS)
  $scope.initialize = function(){
      
               $http.get('https://incident-microservice.run.aws-usw02-pr.ice.predix.io/fetchFailureReason?machineId=001').then(function (reasonData){
    console.log('garima',data);
                   setTimeout(function(){
                       $scope.reasons = reasonData.data;
                   },100)
        console.log('kiran', $scope.reasons);
    });
    $scope.height=$(window).height()-55;
    $('.sub-view-section').slimScroll({ 
        size : '8px',
        distance: '3px', 
        height: $scope.height+'px',
        railVisible: true,
        railDraggable: true,
			  alwaysVisible: true
    });
    $('.loader').addClass('dispNone');
    $scope.getIncidentDetail();
    $('.view-section,.incident-detail').css('width','100%');
  };
  
//  $scope.getALLReason = function(){
//          console.log('kkkk',data);
//   
//    }
    
  jQuery.fn.center = function() {
		this.css({top: ($(window).height() - $(this).outerHeight()) / 2,left: ($(window).width() - $(this).outerWidth()) / 2});
		return this;
	};
	var incidentDetail=$localstorage.getObject('incidentData',null);
  $scope.getIncidentDetail = function(){
    
    if(incidentDetail){
       
      $.each($('#ticket-status tbody td'), function(index){
        $(this).text(incidentDetail[$(this).attr('attr')]);
      });
      
//      $('#ticket-status tbody td[attr="status"]:eq(0)').text(incidentDetail['status']=="Y"?"Running":"Stopped");
//      $('#ticket-status tbody td[attr="status"]:eq(1)').text(incidentDetail['status']=="Y"?"Resolved":"Pending");
        var date=new moment(incidentDetail.createdDate,"YYYY-MM-DD HH:mm:ss a").format('Do MMM YYYY hh:mm:ss a');
        $('#ticket-status tbody td[attr="status"]:eq(0)').text(incidentDetail['incidentStatus']=="Completed"?"Running":"Stopped");
      $('#ticket-status tbody td[attr="status"]:eq(1)').text(incidentDetail['incidentStatus']=="Completed"?"Resolved":"Pending");
        $('#ticket-status tbody td[attr="createdDate"]:eq(1)').text(incidentDetail['createdDate']==date);
      $('#ticket-status tbody td[attr="image_url"]').html('<img class="img img-responsive" src="https://cg-blobstore-heckathone.run.aws-usw02-pr.ice.predix.io/getImage?bucket=cg-dgm&fileName=image2.png&contentType=image/jpeg""/><span>Click Image to Zoom');
      
      if(incidentDetail['incidentStatus']=="Completed"){
        $('.table-section .btn').addClass('dispNone');
          // changes
           $('#textarea').hide();
           $('#tabhead').hide();
        
          
      }else{
        $('.table-section .btn').removeClass('dispNone');
          //changes
           $('#textarea').show();
           $('#tabhead').show();
           
          
      }
      $scope.incidentId=incidentDetail.machine_id;
    }
    
  };
  
  $('.incident-detail').on('click','td .img',function(){
    $('.popup img').attr('src',$(this).attr('src'));
    $('.popup-overlay').removeClass('dispNone');
    $('.popup').removeClass('dispNone').center();
  });
  
  $('.popup').on('click', '.btn',function(){
    $('.popup,.popup-overlay').addClass('dispNone');
  });
  
  $('.table-section').on('click','#resolve-ticket', function(){
    var observationIds=[];
    var answer=[];
    var ansId=""
        for (var i=0;i<$scope.resolveData.length;i++){
                if(ansId==""){
                   ansId="["+$scope.resolveData[i].radioVal
                    
                }
                else{
                    ansId=ansId+","+$scope.resolveData[i].radioVal
                }
                observationIds.push(parseInt($scope.resolveData[i].checkboxVal))

            
        }
        var finalans=ansId+"]"
        var finalans=ansId+"]"
        console.log(incidentDetail)
        var dataToResolve={
            "incidentId": incidentDetail.id,
            "Impact": "Medium",
            "observationIds":JSON.stringify(observationIds) ,
            "answer" :finalans
          }
        console.log("dataToResolve",dataToResolve)
//    var req = {
//      method: 'POST',
//      url: "https://cg-predix-postgres-microservice.run.aws-usw02-pr.ice.predix.io/saveData?machine_id="+$scope.incidentId+
//      "&status=Y"
//    };
    $('.loading').removeClass('dispNone');
//    $http.post('https://incident-microservice.run.aws-usw02-pr.ice.predix.io/saveObservation',dataToResolve).then(function (data){
    $http.post('https://'+urlLS+'.run.aws-usw02-pr.ice.predix.io/saveObservation',dataToResolve).then(function (data){ //TODO
    if(data.data.status=="Success"){
      $('.loading').addClass('dispNone');
      $state.go('incidents');
    $http.post('https://predix-postgres-microservice.run.aws-usw02-pr.ice.predix.io/saveData?machine_id='+incidentDetail.id+'&status=Y').then(function(data){
        
    })
    }
        else{
             $('.loading').addClass('dispNone');
             
        }
    }, function(response){
      $('.loading').addClass('dispNone');
      $state.go('incidents');
    });
  });
    
    
    //Code for Check Box------------------------------------------------------------------------------------
//    $http.get('https://incident-microservice.run.aws-usw02-pr.ice.predix.io/getAllChecklist').then(function (data){
    $http.get('https://'+urlLS+'.run.aws-usw02-pr.ice.predix.io/getAllChecklist').then(function (data){   //TODO
    console.log("data.data",data.data)
	$scope.chec
    $scope.checkBoxdata=data.data
    
    $.each($scope.checkBoxdata,function(index,value){
	var checkbox="<label for="+value.checklistId+">"+value.description+"</label><input type='checkbox' id="+value.checklistId+" value="+value.checklistId+" name='servis[]' class='dinamik'/><br>"
    var radio="<input type='radio' id="+value.checklistId+" value='yes' name='"+value.checklistId+"' onclick='radioClick("+value.checklistId+",event)'/><label>Yes</label><input type='radio' id="+value.checklistId+" value='no' name='"+value.checklistId+"' checked onclick='radioClick("+value.checklistId+")'/><label>No</label>"
	$(".checkBoxContainer").append($(checkbox));
    $(".checkBoxContainer").append($(radio));
    })
	    angular.forEach($scope.checkBoxdata, function(value, key) {
		$scope.checkBoxdata[key].checked=false;
		 $scope.checkBoxdata[key]["radioStatus"]="no"
	    })
    });

    $scope.radioClickAng= function(checkListId,event){
        var radioVal=event.target.value
        console.log("radioVal",radioVal)
         console.log("checkListId",checkListId)
         if($scope.resolveData.length>0){
             for(var i=0;i<$scope.resolveData.length;i++){
                 if(checkListId==$scope.resolveData[i].checkboxVal){
                    $scope.resolveData[i].radioVal=radioVal
                 }
             }
         }
        console.log("$scope.resolveData",$scope.resolveData)
    }
    
    var favorite = new Array();
         $(document).on('click',".dinamik",function (event) {  
            var valueDeger = $(this).find('input').attr('value');
             var isChecked=event.target.checked;
             var checkboxVal=event.target.value
            console.log("isChecked",isChecked,"checkboxVal",checkboxVal)
            var tempObj={};
            if(isChecked){
                tempObj={"checkboxVal":checkboxVal,
                        "radioVal":"no"}
                $scope.resolveData.push(tempObj);
            }
            else{
                for(var i=0;i<$scope.resolveData.length;i++){
                    if(checkboxVal==$scope.resolveData[i].checkboxVal){
                        $scope.resolveData.splice(i,1)
                    }
                }
            }
             console.log("$scope.resolveData",$scope.resolveData)
        });

    

    
    $http.get("https://sensor-retrieve-ms.run.aws-usw02-pr.ice.predix.io/fetchAverageViaSensor").then(function(data){
       console.log("avgSensor",data) 
       var sensorAvg=data.data
       var temp=sensorAvg["Temp_Hack_Predix:TAE"];
       var humidity=sensorAvg["Humidity_Hack_Predix:TAE"];
        console.log("temp",temp)
               var gaugeOptions = {

    chart: {
        type: 'solidgauge'
    },

    title: null,

    pane: {
        center: ['50%', '85%'],
        size: '140%',
        startAngle: -90,
        endAngle: 90,
        background: {
            backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || '#EEE',
            innerRadius: '60%',
            outerRadius: '100%',
            shape: 'arc'
        }
    },

    tooltip: {
        enabled: false
    },

    // the value axis
    yAxis: {
        stops: [
//            [0.1, '#55BF3B'], // green
            [0.5, '#DDDF0D'] // yellow
//            [0.9, '#DF5353'] // red
        ],
        lineWidth: 0,
        minorTickInterval: null,
        tickAmount: 2,
        title: {
            y: -70
        },
        labels: {
            y: 16
        }
    },

    plotOptions: {
        solidgauge: {
            dataLabels: {
                y: 5,
                borderWidth: 0,
                useHTML: true
            }
        }
    }
};

// The speed gauge
var chartTemp = Highcharts.chart('container-temp', Highcharts.merge(gaugeOptions, {   
    yAxis: {
        min: 0,
        max: 200,
        title: {
            text: 'Temperature'
        }
    },

    credits: {
        enabled: false
    },

    series: [{
        name: 'Temperature',
        data: [temp],
        dataLabels: {
            format: '<div style="text-align:center"><span style="font-size:25px;color:' +
                ((Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black') + '">{y}</span><br/>' +
                   '<span style="font-size:12px;color:silver">°C</span></div>'
        },
        tooltip: {
            valueSuffix: '°C'
        }
    }]

}));

// The RPM gauge
var chartHumidity = Highcharts.chart('container-humidity', Highcharts.merge(gaugeOptions, {
    yAxis: {
        min: 0,
        max: 5,
        title: {
            text: 'Humidity'
        }
    },

    series: [{
        name: 'Humidity',
        data: [humidity],
        dataLabels: {
            format: '<div style="text-align:center"><span style="font-size:25px;color:' +
                ((Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black') + '">{y:.1f}</span><br/>' +
                   '<span style="font-size:12px;color:silver">%</span></div>'
        },
        tooltip: {
            valueSuffix: '%'
        }
    }]

}));
    });
    
    
//    ------------------------------------------------------------------
    

  
});

