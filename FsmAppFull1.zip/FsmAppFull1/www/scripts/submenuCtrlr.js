angular.module('fpmApp').controller('submenuCtrlr', function($scope,$state){
  
  $scope.initialize = function(menuIndex, submenuIndex){
    var height=$(window).height()-55;
    $('.navigation').removeClass('dispNone');
    $('.navigation ul').css('height',height+'px');
    $('.submenu').css('height',(height)+'px');
    $('.submenu span li').removeClass('activated');
    $('.submenu span:eq('+menuIndex+') li:eq('+submenuIndex+')').addClass('activated');
  };
  
  /*$('body').on('click','.navigation .menu li:not(.disabled)', function(){
    var index=$(this).index()-2;
  	$('.navigation .menu li').removeClass('activated');
  	$(this).addClass('activated');
  	if($('.submenu').is(':visible')){
  		$('.submenu span').addClass('dispNone');
  		$('.submenu span:eq('+index+')').removeClass('dispNone');
  	}else if(index>=0){
  		$('.submenu span').addClass('dispNone');
  		$('.submenu-div').removeClass('dispNone');
  		$('.submenu span:eq('+index+')').removeClass('dispNone');
  		$('.sub-view-section').removeClass('col-md-12').addClass('col-md-10');
  	}
  });
  
  $('body').on('click','.heading .fa-close', function(){
    $('.submenu-div').addClass('dispNone');
  	$('.sub-view-section').removeClass('col-md-10').addClass('col-md-12');
  	$('.navigation .menu li').removeClass('activated');
  	$('.navigation .menu .active-reference').addClass('activated');
  });*/
  
  $('body').on('click', '.navigation .menu li', function() {
    var stateRef = $(this).attr('sref-attr');
    if(stateRef){
      $state.go(stateRef);
    }
  });
  
});