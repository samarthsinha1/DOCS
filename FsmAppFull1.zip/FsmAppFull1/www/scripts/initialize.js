var hackathonApp = angular.module('hackathonApp', ['ui.router','hackathonApp.utils']);
hackathonApp.config(function($stateProvider, $urlRouterProvider){
    

  $urlRouterProvider.otherwise("/");
  
  $stateProvider
    .state('hackathon', {
      url: '/',
      templateUrl: 'views/splashScreen.html'
    }).state('dashboard', {
      url: '/dashboard',
      templateUrl: 'views/dashboard.html'
    }).state('incidents', {
      url: '/incidents',
      templateUrl: 'views/incidents.html'
    }).state('incidentDetail', {
      url: '/incidentDetail',
      templateUrl: 'views/incidentdetail.html'
    }).state('urlConfig', {
      url: '/urlConfig',
      templateUrl: 'views/urlConfig.html'
    });
});

hackathonApp.run(function($http){
    console.log('localStorage',localStorage.getItem("url"));
        $http.get("scripts/config.json").then(function(data){
        console.log('sdfakjsfdkj',data)
        
    });
});