angular.module('fpmApp').controller('wwEcoExistingCtrlr', function($scope,$state){
  
  function initialize(){
    $scope.height=$(window).height()-55;
    $('.sub-view-section').slimScroll({ 
        size : '8px',
        distance: '3px', 
        height: $scope.height+'px',
        railVisible: true,
        railDraggable: true,
			  alwaysVisible: true
    });
    $('.sub-view-section').css('width','100%');
    $('.navigation').removeClass('dispNone');
    $('.navigation li').removeClass('active-reference').removeClass('activated');
    $('.navigation li:eq(3)').addClass('active-reference').addClass('activated');
    $scope.defaultColumnSettings=[{"colIndex":2,"visible":false},{"colIndex":3,"visible":false},{"colIndex":4,"visible":true},{"colIndex":5,"visible":true},{"colIndex":6,"visible":true},{"colIndex":7,"visible":false}];
		$scope.columnStyles=[{"colIndex":1,"colClass":"text-center"},{"colIndex":2,"colClass":"ellipsis"},{"colIndex":3,"colClass":"ellipsis"},{"colIndex":4,"colClass":"ellipsis"},{"colIndex":5,"colClass":"text-center"},{"colIndex":6,"colClass":"text-center"},{"colIndex":7,"colClass":"text-center"}];
		$scope.datapoints=[];
		$scope.maxAssetSelection=2;
  }
  initialize();
  
  $scope.resetScopeModels = function(){
    $('#ww-cost1,#ww-cost2').val(20000);
    $('#ww-electricity1,#ww-electricity2').val(50);
    $('#ww-fuel-cost1,#ww-fuel-cost2').val(4.5);
    $('#ww-downtime1,#ww-downtime2').val(24);
  };
  
  $scope.fetchUniqueValues = function(json,param){
  	var uniqueNames = [];
  	for(var i = 0; i< json.length; i++){    
  		if(uniqueNames.indexOf(json[i][param]) === -1){
  			uniqueNames.push(json[i][param]);        
  		}        
  	}
  	return uniqueNames;
  };
      
  $scope.filterJSON = function(json, key, value){
  	return json.filter(function(jsonObj){ 
  		return jsonObj[key] == value;
  		});
  };
      
  $scope.setTableScrolling = function(tableSection, height){
    $('#'+tableSection+' .dataTables_scrollBody').slimScroll({ 
      size : '8px',
      distance: '5px',
      height: height,
      railDraggable: true,
      alwaysVisible: true
    });
  };
  
  $scope.adjustTableColumns = function(tableSection, isNonBlank){
    $('#'+tableSection+' .no-data-section').removeClass('dispNone');
	  $('#'+tableSection+' .datatable-options .datatable-page-length').addClass('dispNone');
	  $('#'+tableSection+' .hideable-button').addClass('dispNone');
	  $('#'+tableSection+' .data-section').addClass('dispNone');
	  $('#'+tableSection+' .clear-btn').prop('disabled', true);
    if(isNonBlank){
      $('#'+tableSection+' .no-data-section').addClass('dispNone');
  	  $('#'+tableSection+' .datatable-options .datatable-page-length').removeClass('dispNone');
  	  $('#'+tableSection+' .hideable-button').removeClass('dispNone');
  	  $('#'+tableSection+' .data-section').removeClass('dispNone');
  	  $('#'+tableSection+' .clear-btn').prop('disabled', false);
    }
	  $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
  };
  
  $scope.toggleColumnVisiblity= function(tableSection){
    var tableId=$('#'+tableSection).find('.datatable-body:eq(1)').attr('id');
    $.each($scope.defaultColumnSettings, function(index){
      $('#'+tableSection+' .multiselect input[data-column="'+this.colIndex+'"]').prop('checked',this.visible).trigger('change');
    });
  };
  
  $scope.setColumnVisiblity= function(tableSection){
    var columns=[];
    $.each($('#'+tableSection+' .mutliSelect input'), function(index){
      columns.push({'colIndex':Number($(this).attr('data-column')),'visible':$(this).is(':checked')});
    });
    //$localstorage.setObject('columnVisibilty',columns);
  };
  
  $scope.setColumnStyles = function(tableSection){
    var tableId=$('#'+tableSection).find('.datatable-body:eq(1)').attr('id');
    $.each($scope.columnStyles, function(index){
      var colIndex=this.colIndex;
      var colClass=this.colClass;
      $.each($('#'+tableId).DataTable().column(colIndex).nodes(), function(index){
        $(this).attr('title',$(this).text());
        $(this).addClass(colClass);
      });
    });
  };
  
  $scope.toggleChartVisibilty = function(isNonBlank){
    $('#graph-section .no-data-section').removeClass('dispNone');
    $('#graph-section .data-section').addClass('dispNone');
    if(isNonBlank){
      $('#graph-section .no-data-section').addClass('dispNone');
      $('#graph-section .data-section').removeClass('dispNone');
    }
  };
  
  $scope.initializeDataTable = function(table, settings){
    var tableSection=$(table).parents('.datatable-block').attr('id');
    var columnDefs=[{'targets': 0,'orderable':false}];
    if(settings.checkBoxes){
      columnDefs=[{ 'targets': 0,
                    'checkboxes': {'selectRow': true,'selectAllPages':false}
                 }];
      if(settings.isSingleSelect){
      columnDefs=[{ 'targets': 0,
                    'checkboxes': {'selectRow': true,'selectAll':false}
                 }];
      }
    }
    
    if($.fn.DataTable.isDataTable($(table))){
      $(table).DataTable().column(0).checkboxes.deselect();
      $(table).dataTable().fnClearTable();
      if(settings.checkBoxes){
        $('#'+tableSection+' .datatable-filter th:eq(0)').html('(0)');
      }
      $('#'+tableSection+' .action-btn').prop('disabled', true);
      $(table).dataTable().fnAddData(settings.data);
    }else{
      $(table).dataTable({
        'data': settings.data,
        'bLengthChange':false,
        "iDisplayLength": settings.pageLength,
        'bDestroy':true,
        'responsive':true,
        "scrollY": settings.scrollHeight,
        'columnDefs': columnDefs,
        'select': {
          'style': settings.isSingleSelect?'multi':'single'
        },
        order:[],
        columns: [
            { "data": settings.checkBoxes?"serial":"ID" },
            { "data": "ID" },
            { "data": "region" },
            { "data": "siteName" },
            { "data": "customerName"},                    
            { "data": "frame" },
            { "data": "tech" },
            { "data": "serial" }
        ]
      });
    }
    $scope.setTableScrolling(tableSection, settings.scrollHeight);
    $scope.adjustTableColumns(tableSection, true);
    $scope.setColumnStyles(tableSection);
    $scope.toggleColumnVisiblity(tableSection);
  };
  
  $scope.getWWEffectivenessData = function(){
    $.ajax({ 
  		type : "GET",
  		url: "data/effectiveness_data.json",
  		contentType: "application/json; charset=utf-8",
  		dataType : "json", 
  		success : function(response){
			  if(response.length!==0){
			    $.each(response, function(index){
	          this.ID=index+1;
	        });
			    $scope.searchResults=response;
			    var settings={
			      "scrollHeight":"160px",
			      "checkBoxes": true,
			      "isSingleSelect": true,
			      "pageLength":10,
			      "data": $scope.searchResults
			    };
			    $scope.initializeDataTable($("#result-table"), settings);
			  } 
  		},
  		error : function(exception){
  			alert('Error Occurred, Please try again by reloading page.');
  		}
	  });
  };
  
  $scope.getWWPerformanceData = function(serialCount){
    $.ajax({ 
  		type : "GET",
  		url: "data/economicsData"+serialCount+".json",
  		contentType: "application/json; charset=utf-8",
  		dataType : "json", 
  		success : function(response){
			  if(response!==null && response.error===undefined){
			    $scope.datapoints.push(response);
			    serialCount--;
			    if(serialCount!==0){
			      $scope.getWWPerformanceData(serialCount);
			    }else{
			      $scope.processData();
			    }
			  }else{
			    alert(response.error);
			  } 
  		},
  		error : function(exception){
  			alert('Error Occurred, Please try again by reloading page.');
  		}
	  });
  };
  
  $scope.processData = function(){
    $scope.toggleChartVisibilty(true);
    $.each($scope.datapoints, function(pointindex){
      var wweconomics = this;
      var firingHours = wweconomics["Offline Water Wash Economics"]["Firing Hours"];
      $scope.optimalTimeWW = wweconomics["Offline Water Wash Economics"]["Optimal Time for Water Wash"];
      var profitableWW = wweconomics["Offline Water Wash Economics"]["Profitable Water Wash"];
      $scope.seriesData = [];
      $.each(firingHours, function(index) {
          $scope.seriesData.push([firingHours[index], profitableWW[index]]);
      });
      $scope.renderCostBenefitGraph('cost-benefit-graph'+(pointindex+1), $scope.selectedSerials[pointindex]);
    });
  };
  
  /*document.querySelector('ge-dropdown').addEventListener('button-clicked', function (e) {
    $scope.getWWEffectivenessData();
    $scope.resetScopeModels();
    $scope.toggleParameterVisiblity(0);
  });*/
  
  $('#ww-eco-existing').on('calendar-apply-clicked','#date-range1', function(e){
    $scope.period1=e.originalEvent.detail;
    $scope.interval1=$scope.period1.duration.asDays();
    $('#search-button').prop('disabled',false).removeClass('btn-disabled');
  });
  
  $('#ww-eco-existing').on('calendar-cancel-clicked','#date-range1', function(e){
    $scope.period1=null;
    $scope.interval1=null;
    $('#search-button').prop('disabled',true).addClass('btn-disabled');
  });
  
  $('#ww-eco-existing').on('click', '#search-button',function(){
    $scope.getWWEffectivenessData();
    $scope.resetScopeModels();
    $scope.toggleParameterVisiblity(0);
  });
  
  $scope.formatNumber = function(nStr) {
    nStr += '';
    var x = nStr.split('.');
    var x1 = x[0];
    var x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    return x1 + x2;
  };
        
  $scope.renderCostBenefitGraph = function(renderTo, serial){
    var graphWidth=$('.graph-container .graph:visible').width();
    var graphObject={};
    var chart={
      renderTo: renderTo,
      height: 400,
      width: graphWidth,
      type: 'line',
      zoomType: 'x',
      panning: true,
      panKey: 'shift',
      backgroundColor:"transparent",
      style: {fontFamily: "GE_Inspira"}
    };
    var title= {text: 'OFWW cost benefit analytic for Serial '+serial,
      y: 20,
      style: {
        color: '#3693f8',
        fontWeight: 'bold',
        fontSize: '14px'
      }
    };
    var xPlotLines= [
      {
        color: '#ffffff',
        width: 3,
        value: $scope.optimalTimeWW,
        dashStyle: 'Dot',
        label: {
            text: '<div style="text-align: left; color:white;"><i style="color:green;font-size: 25px;" class="fa fa-long-arrow-right" aria-hidden="true"></i><br/>WW Overdue</div>',
            verticalAlign: 'top',
            textAlign: 'left',
            rotation: '0',
            x: 15,
            y: 30,
            useHTML: true,
            style: {
                fontWeight: 'bold'
            }
        }
      }, 
      {
        color: 'transparent',
        width: 3,
        value: $scope.optimalTimeWW - 50,
        dashStyle: 'Dot',
        label: {
            text: '<div style="text-align: right; color:white;"><i style="color:green;font-size: 25px;" class="fa fa-long-arrow-left" aria-hidden="true"></i><br/>WW Too early</div>',
            verticalAlign: 'top',
            align: "right",
            textAlign: 'right',
            rotation: '0',
            x: -10,
            y: 30,
            useHTML: true,
            style: {
                fontWeight: 'bold'
            }
        }
    }];
    var xAxis= {
    	lineWidth: 1,
      lineColor: 'white',
			gridLineWidth: 0.5,
			title: {
        text: 'Fired Hours',
        style: {
          color: '#FFFFFF',
          fontWeight: 'bold'
        }
      },
			labels: {
			  style: {
          color: '#FFFFFF'
        },
        formatter: function() {
          return Number(this.value);
        },
				enabled:true
			},
			plotLines: xPlotLines
		};
		var yAxis= {
		  title: {
        text: 'Money Lost by not Water washing',
        style: {
          color: '#FFFFFF',
          fontWeight: 'bold'
        }
		  },
      lineWidth: 1,
      lineColor: 'grey',
      gridLineWidth: 0.5,
      labels: {
        style: {
          color: '#FFFFFF'
        },
        formatter: function() {
          return this.value < 0 ? '$(' + $scope.formatNumber(Math.abs(this.value)) + ')' : 
                 '$' + $scope.formatNumber(Math.abs(this.value));
        }
      }
		};
		var legend={
    	itemStyle: {
        color: '#ffffff',
      },
      itemHoverStyle: {
        color: '#ffffff',
      },
    	layout: 'horizontal',
    	align:'center',
    };
    var tooltip= {
      formatter: function(){
        return '<b>Fired Hour:</b> ' + this.point.x + 
               '<br/><b>Value:</b> $' + (this.point.y < 0 ? '(' + Math.abs(this.point.y) + ')' : this.point.y);
      }
    };
    var series= [
      {
        color: '#3694f7',
        data: $scope.seriesData,
        marker: {enabled: false}
      }
    ];
    var credits= {enabled: false};
		var exporting= {
      chartOptions: {
        plotOptions: {
          series: {
            dataLabels: {enabled: true}
          }
        }
      },
      scale: 1.5,
      fallbackToExportServer: false
    };
    graphObject.chart=chart;
    graphObject.title=title;
    graphObject.xAxis=xAxis;
    graphObject.yAxis=yAxis;
    graphObject.tooltip=tooltip;
    graphObject.legend=legend;
    graphObject.series=series;
    graphObject.credits=credits;
    graphObject.exporting=exporting;
    $scope[renderTo] = new Highcharts.Chart(graphObject);
  };
  
    
  
  $scope.toggleActionButtonStates = function(tableSection){
    var tableId=$('#'+tableSection).find('.datatable-body:eq(1)').attr('id');
    var count=$('#'+tableId).DataTable().rows('.selected').data().length;
    $('#'+tableSection+' .action-btn').prop('disabled', true);
    $('#'+tableSection+' .datatable-filter th:eq(0)').html('('+count+')');
    if(count>0){
      $('#'+tableSection+' .action-btn').prop('disabled', false);
    }
  };
  
  $scope.toggleParameterVisiblity = function(count){
    $('#parameter-block .no-data-section').removeClass('dispNone');
    $('#parameter-block .data-section').addClass('dispNone');
    if(count>0){
      $.each($('#parameter-block .data-section .parameter-form'), function(index){
        $(this).find('.form-head span').text($scope.selectedSerials[index]);
      });
      $('#parameter-block .no-data-section').addClass('dispNone');
      $('#parameter-block .data-section').removeClass('dispNone');
      $('#parameter-block .data-section #parameter-form2').addClass('dispNone');
      if(count>1){
        $('#parameter-block .data-section #parameter-form2').removeClass('dispNone');
      }
    }
  };
  
  $("#result-table .datatable-filter th input").on( 'keyup change', function () {
    $("#result-table").DataTable()
        .column($(this).parent().attr('data-column'))
        .search( this.value )
        .draw();
  });
  
  $('#search-result-section').on('change','tbody input', function(){
    var tableSection=$(this).parents('.datatable-section').attr('id');
    var tableId=$(this).parents('table').attr('id');
    var count=$('#'+tableId).DataTable().rows('.selected').data().length;
    var checked=$(this).is(':checked');
    if(count>$scope.maxAssetSelection && checked){
      alert('Maximum '+$scope.maxAssetSelection+' Serials can only be selected');
      var rowIndex=$('#'+tableId).DataTable().row($(this).parents('tr')[0]).index();
      $('#'+tableId).DataTable().cells(rowIndex,0).checkboxes.deselect();
      
    }
    $scope.selectedData=$('#'+tableId).DataTable().rows('.selected').data();
    var selectedData=[];
    $scope.selectedSerials=[];
    $.each($scope.selectedData, function(index){
      selectedData.push(this);
      $scope.selectedSerials.push(this.serial);
    });
    $scope.selectedData=selectedData;
    $scope.toggleActionButtonStates(tableSection);
    $scope.toggleParameterVisiblity(count);
  });
  
  $('#search-result-section').on('click','tbody tr', function(){
    $(this).find('input').trigger('change');
  });
  
  
  $('#ww-eco-existing').on('change','#search-result-section .datatable-length', function(){
    var pageLength=Number($(this).val());
    if($.fn.DataTable.isDataTable($('#result-table'))){
      $('#result-table').DataTable().page.len(pageLength).draw();
    }
  });
  
  $('#ww-eco-existing').on('click', '.multiselect .hideable-button', function(){
    var checkboxes=$(this).parents('.multiselect').find('#checkboxes');
    if ($(checkboxes).hasClass('expanded')) {
      $(checkboxes).removeClass('expanded');
      $(checkboxes).slideToggle('fast');
    } else {
      $(checkboxes).addClass('expanded');
      $(checkboxes).slideToggle('fast');
    }
  });
  
  $('.multiselect').on('change','#checkboxes input', function(){
    var tableSection=$(this).parents('.datatable-block').attr('id');
    var colIndex=Number($(this).attr('data-column'));
    var tableId=$('#'+tableSection).find('.datatable-body:eq(1)').attr('id');
    var column = $('#'+tableId).DataTable().column( $(this).attr('data-column') );
    if($(this).is(':checked')){
      $('#'+tableSection+' .datatable-filter th[data-column="'+colIndex+'"]').show();
      if(colIndex==7){
        $('#'+tableSection+' .datatable-filter th[data-column="1"]').hide();
        $('#'+tableId).DataTable().column(1).visible(false);
      }
    }else{
      $('#'+tableSection+' .datatable-filter th[data-column="'+colIndex+'"]').hide();
      if(colIndex==7){
        $('#'+tableSection+' .datatable-filter th[data-column="1"]').show();
        $('#'+tableId).DataTable().column(1).visible(true);
      }
    }
    column.visible($(this).is(':checked'));
  });
  
  $('#graph-section').on('click','.thubmail-tooltip', function(){
    var graphId=$(this).find('img').attr('graph-attr');
    $('.graph-container').addClass('dispNone');
    $('#graph-section .thumnail-wrapper').removeClass('active-thumbnail');
    $(this).parents('.thumnail-wrapper').addClass('active-thumbnail');
    $('#'+graphId).removeClass('dispNone');
  });
  
  $('#ww-eco-existing').on('click','#parameter-block .action-btn', function(){
    $scope.datapoints=[];
    $('#graph-section .expand-btn').attr('graph-data','1').html('<i class="fa fa-expand"></i> Expand Graph');
    if($scope.selectedSerials.length>1){
      $('#graph-section .expand-btn').prop('disabled',false);
      $('.graph:nth-of-type(2)').removeClass('full-width');
      $('.graph:nth-of-type(3)').removeClass('dispNone');
    }else{
      $('#graph-section .expand-btn').prop('disabled',true);
      $('.graph:nth-of-type(2)').addClass('full-width');
      $('.graph:nth-of-type(3)').addClass('dispNone');
    }
    $scope.getWWPerformanceData($scope.selectedSerials.length);
  });
  
  $('#graph-section').on('click','.expand-btn', function(){
    var btnValue=Number($(this).attr('graph-data'));
    if(btnValue==1){
      $(this).parents('.graph-container').find('.graph').addClass('full-width');
      $(this).html('<i class="fa fa-compress"></i> Compress Graph');
      $(this).attr('graph-data',2);
    }else{
      $(this).parents('.graph-container').find('.graph').removeClass('full-width');
      $(this).html('<i class="fa fa-expand"></i> Expand Graph');
      $(this).attr('graph-data',1);
    }
    $.each($(this).parents('.graph-container').find('.graph'), function(index){
      var graphId=$(this).attr('id');
      var width=$(this).width();
      $scope[graphId].setSize(width,400,true);
    });
  });
  
  $('#ww-eco-existing').on('click','.parameter-form .parameter-head', function(){
    var isContentVisible=$(this).siblings('.parameter-content').is(':visible');
    if(isContentVisible){
      $(this).siblings('.parameter-content').slideUp(250).addClass('dispNone');
      $(this).find('i').addClass('fa-angle-down').removeClass('fa-angle-up');
    }else{
      $.each($('.parameter-content:visible'), function(index){
        $(this).slideUp(250);
        $(this).siblings('.parameter-head').find('i').addClass('fa-angle-down').removeClass('fa-angle-up');
      });
      $(this).siblings('.parameter-content').slideDown(250).removeClass('dispNone');
      $(this).find('i').addClass('fa-angle-up').removeClass('fa-angle-down');
    }
  });
  
});