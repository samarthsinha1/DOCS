angular.module('hackathonApp').controller('dashboardCtrlr', function($scope,$state,$http,$localstorage){
  //    LOCAL Storage Data-----------------------------------------------------------
  var urlLS = localStorage.getItem("url");
  var ipLS = localStorage.getItem("ip");
    console.log("url",urlLS,"ip",ipLS)
  $scope.initialize = function(){
    $scope.height=$(window).height()-55;
    $('.sub-view-section').slimScroll({ 
        size : '8px',
        distance: '3px', 
        height: $scope.height+'px',
        railVisible: true,
        railDraggable: true,
			  alwaysVisible: true
    });
    $('.loader').addClass('dispNone');
    var manualState=JSON.parse($localstorage.get('manual','false'));
    var backupState=JSON.parse($localstorage.get('backup','false'));
    $("[name='manual-override']").bootstrapSwitch('state',manualState, true);
    $("[name='manual-backup']").bootstrapSwitch('state',backupState,true);
    $('#backup').addClass('dispNone');
    if($("[name='manual-override']").is(':checked')){
      $('#backup').removeClass('dispNone');
    }
    $('.view-section,.dashboard').css('width','100%');
  };
    

  $scope.getConfigurations = function(){
    $.ajax({ 
  		type : "GET",
  		url: "data/configurations.json",
  		contentType: "application/json; charset=utf-8",
  		dataType : "json", 
  		success : function(response){
			  if(response.length!==0){
			    $('.configuration').remove();
			    $.each(response, function(index){
			      $('.dashboard').append('<configuration-card class="config" config-id="'+this.id+
			      '"icon="fa fa-file-text-o" config-head="Configuration" config-title="'+this.configName+
			      '" actionable></configuration-card>');
			    });
			  } 
  		},
  		error : function(exception){
  			alert('Error Occurred, Please try again by reloading page.');
  		}
	  });
  };
  
  $('#dashboard').on('mouseenter', '.table-section', function(){
    $(this).addClass('card-highlight');
  });
  
  $('#dashboard').on('mouseleave', '.table-section', function(){
    $(this).removeClass('card-highlight');
  });
  
  $('#dashboard').on('click','#view-ticket', function(e){
    $state.go('incidents');
  });
    
    $(document).on('click',"#config",function (event) {
        $state.go('urlConfig');
    })
  
  $("[name='manual-override']").on('switchChange.bootstrapSwitch', function (event, state){
    var req = {
        method: 'GET',
//        url: "http://10.10.10.188:8888/home?name=manualmode&action=off"
        url: "http://"+ipLS+"/home?name=manualmode&action=off"           //TODO
      };
    if($(this).is(':checked')){
      req = {
        method: 'GET',
//        url: "http://10.10.10.188:8888/home?name=manualmode&action=on"
        url: "http://"+ipLS+"/home?name=manualmode&action=on"  //TODO
      };
    }
    if(state){
        $('input[name="manual-backup"]').bootstrapSwitch('state', false, true);
        $('#backup').removeClass('dispNone');
      }else{
        $('input[name="manual-backup"]').bootstrapSwitch('state', false, true);
        $localstorage.set('backup','false');
        $('#backup').addClass('dispNone');
      }
      $localstorage.set('manual',state);
    $http(req).then(function(response){}, function(response){});
  });
  
  $("[name='manual-backup']").on('switchChange.bootstrapSwitch', function (event, state){
    var req = {
        method: 'GET',
//        url: "http://10.10.10.188:8888/home?name=fan1&action=off"
        url: "http://"+ipLS+"/home?name=fan1&action=off"     //TODO
      };
    if(state){
      req = {
        method: 'GET',
//        url: "http://10.10.10.188:8888/home?name=fan1&action=on"
        url: "http://"+ipLS+"/home?name=fan1&action=on"     //TODO
      };
    }
    $localstorage.set('backup',state);
      $http(req).then(function(response){}, function(response){});
  });
  
});