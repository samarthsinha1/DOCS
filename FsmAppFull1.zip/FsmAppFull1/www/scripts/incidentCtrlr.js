angular.module('hackathonApp').controller('incidentCtrlr', function($scope,$state,$http,$localstorage){
    var urlLS = localStorage.getItem("url");
    var ipLS = localStorage.getItem("ip");
    console.log("url",urlLS,"ip",ipLS)
  $scope.initialize = function(){
    $scope.height=$(window).height()-55;
    $('.sub-view-section').slimScroll({ 
        size : '8px',
        distance: '3px', 
        height: ($scope.height)+'px',
        railVisible: true,
        railDraggable: true,
			  alwaysVisible: true
    });
    $('.loader').addClass('dispNone');
    $scope.getIncidentsList();
    $('.view-section,.incidents').css('width','100%');
  };
  $scope.getIncidentsList = function(){
    var req = {
      method: 'GET',
//        url: "https://incident-microservice.run.aws-usw02-pr.ice.predix.io/service/incident/list?ssoId=502437175"
        url: "https://"+urlLS+".run.aws-usw02-pr.ice.predix.io/service/incident/list?ssoId=502437175"     //TODO
    };
    $('.loading').removeClass('dispNone');
    $http(req).then(function(response){
      $scope.incidents=response.data;
      $('.inclident-lists').empty();
      $.each($scope.incidents, function(index){
        var date=new moment(this.modifiedDate,"YYYY-MM-DD HH:mm:ss a").format('Do MMM YYYY hh:mm:ss a');
        var classes=this.incidentStatus=="Completed"?"resolved":"high-priority";
        var htmlData='<li class="'+classes+'" url=""https://cg-blobstore-heckathone.run.aws-usw02-pr.ice.predix.io/getImage?bucket=cg-dgm&fileName=image1.jpg&contentType=image/jpeg" incident-id="'+this.ticket_no+
        '" machine-id="'+this.incidentDescription+'" machine-name="'+this.incidentName+'">'+
        '<span class="incident-number">'+this.id+'</span>'+
        '<span class="time-stamp">Last Updated: '+date+'</span>'+
        '<span class="icon-view"><i class="fa fa-angle-right"></i></span></li>';
      
        $('.inclident-lists').append(htmlData);
        $('.inclident-lists li:eq('+index+')').attr('data',JSON.stringify(this));
        $('.loading').addClass('dispNone');
      
      });
    }, function(response){
      console.log(response);
      $('.loading').addClass('dispNone');
    });
      
  };
  
  $('.incidents').on('click', 'li',function(){
    $localstorage.setObject('incidentData',JSON.parse($(this).attr('data')));
    $state.go('incidentDetail');
    
  });
  
  $('.incidents').on('click','.refresh-btn', function(){
    $scope.getIncidentsList();
  });
  
  $('.incidents').on('click','.back-btn', function(){
    $state.go('dashboard');
  });
  
   $('.incidents').on('mouseenter', 'li', function(){
    $(this).addClass('card-highlight');
  });
  
  $('.incidents').on('mouseleave', 'li', function(){
    $(this).removeClass('card-highlight');
  });
  
});
