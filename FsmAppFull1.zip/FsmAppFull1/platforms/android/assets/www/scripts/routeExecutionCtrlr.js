angular.module('transportApp').controller('routeExecutionCtrlr', function($scope,$state){
  
  $scope.initialize = function(){
    $scope.height=$(window).height();
    $('.page').css('height',$scope.height+'px');
  };
  
  $('.floating-menu').on('click', function(){
    $(this).toggleClass('menu-active');
  });
  
  $('.back-btn').on('click', function(){
    $state.go('routes');
  });
  
  
  
});