var fpmApp = angular.module('transportApp', ['ui.router']);
fpmApp.config(function($stateProvider, $urlRouterProvider){
  $urlRouterProvider.otherwise("/");
  
  $stateProvider
    .state('default', {
      url: '/',
      templateUrl: 'views/login.html'
    }).state('login', {
      url: '/login',
      templateUrl: 'views/login.html'
    }).state('routes', {
      url: '/routes',
      templateUrl: 'views/routes.html'
    }).state('routeDetail', {
      url: '/routeDetail',
      templateUrl: 'views/routeDetail.html'
    }).state('routeTimeline', {
      url: '/routeTimeline',
      templateUrl: 'views/routeTimeLine.html'
    }).state('routeExecution', {
      url: '/routeExecution',
      templateUrl: 'views/routeExecution.html'
    });
});