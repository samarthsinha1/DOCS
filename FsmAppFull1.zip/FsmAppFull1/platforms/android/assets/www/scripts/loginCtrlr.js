angular.module('transportApp').controller('loginCtrlr', function($scope,$state){
  
  $scope.initialize = function(){
    $scope.height=$(window).height();
    $('.page').css('height',$scope.height+'px');
  };
  
  $('.login-btn').on('click', function(){
    var email=$('#email').val()||"";
    var password=$('#password').val()||"";
    if(email.trim() && password.trim()){
      $state.go('routes');
    }else{
      if(!email){
        $('#email').parent().addClass('error');
      }
      if(!password){
        $('#password').parent().addClass('error');
      }
    }
  });
  
});