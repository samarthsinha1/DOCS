angular.module('transportApp').controller('routeTimeLineCtrlr', function($scope,$state){
  
  $scope.initialize = function(){
    $scope.height=$(window).height();
    $('.page').css('height',$scope.height+'px');
  };
  
  $('.floating-menu').on('click', function(){
    $(this).toggleClass('menu-active');
  });
  
  $('.back-btn').on('click', function(){
    $state.go('routes');
  });
  
  $('.poi-time-list').on('click', 'li', function(){
    $state.go('routeExecution');
  });
  
  $('.floating-menu .button').on('click', function(){
    $state.go('routeDetail');
  });
});