angular.module('transportApp').controller('routeDetailCtrlr', function($scope,$state){
  
  $scope.initialize = function(){
    $scope.height=$(window).height();
    $scope.applyScroll($('#docs'));
    $scope.map=null;
  };
  
  $scope.applyScroll = function(section){
    $(section).slimScroll({ 
        size : '8px',
        distance: '3px', 
        height: ($(window).height()-60)+'px',
        railVisible: false,
        railDraggable: true,
  		  alwaysVisible: false
    });
    $(section).css('width','100%');
    $('.slimScrollDiv').css('width','100%');
  };
  
  $scope.destroyScroll = function(section){
    //$(section).slimScroll({destroy: true});
    $(section).parents('.slimScrollDiv').replaceWith($(section)); 
  };
  
  $scope.initMap = function(){
    var mapOptions = { 
      center:new google.maps.LatLng(47.6397, 6.8638),
      zoom:8,
      mapTypeId:google.maps.MapTypeId.ROADMAP,
      disableDefaultUI:false,
      panControl: true,
      zoomControl: true,
      zoomControlOptions: {
          position: google.maps.ControlPosition.LEFT_BOTTOM
      },
      streetViewControl: false
    };
    $scope.map = new google.maps.Map(document.getElementById("google-map"),mapOptions);
  };
  
  $('.floating-menu').on('click', function(){
    $(this).toggleClass('menu-active');
  });
  
  $('.floating-menu .button').on('click', function(){
    var stateRef=$(this).attr('sref-attr');
    $('.route-panel').addClass('dispNone');
    $('#'+stateRef).removeClass('dispNone');
    $scope.destroyScroll($('.scrollable'));
    if($('#'+stateRef).hasClass('scrollable')){
      $scope.applyScroll($('#'+stateRef));
    }
    if(stateRef=="map"){
      $scope.initMap();
    }
  });
  
  $('.back-btn').on('click', function(){
    $state.go('routeTimeline');
  });
  
});