angular.module('transportApp').controller('routesCtrlr', function($scope,$state){
  
  $scope.initialize = function(){
    $scope.height=$(window).height();
    $('.page').css('height',$scope.height+'px');
    $('.content-section').slimScroll({ 
        size : '8px',
        distance: '3px', 
        height: ($scope.height-60)+'px',
        railVisible: false,
        railDraggable: true,
			  alwaysVisible: true
    });
    $('.content-section').css('width','100%');
    $('.slimScrollDiv').css('width','100%');
  };
  
  $('.route-list').on('click', 'li', function(){
    $state.go('routeTimeline');
  });
  
});