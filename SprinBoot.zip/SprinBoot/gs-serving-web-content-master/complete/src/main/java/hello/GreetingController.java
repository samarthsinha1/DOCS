package hello;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class GreetingController {
    
    @RequestMapping("/add")
    public String greeting(@RequestParam(value="num1") int number1,@RequestParam(value="num2") int number2 ,Model model) {
        model.addAttribute("result", number1+number2);
        return "result";
    }
}
